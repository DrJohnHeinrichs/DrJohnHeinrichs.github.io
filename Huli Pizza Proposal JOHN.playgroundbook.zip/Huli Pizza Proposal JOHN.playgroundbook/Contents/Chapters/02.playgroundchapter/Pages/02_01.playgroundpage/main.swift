//:# The Dessert Menu
//:## Version 2
//: The version of the desserts page adds some pizzaz.
//:- A background  *blue-green* color
//:- Rounds the corners of the images for **a better look**
//#-hidden-code
import UIKit
import PlaygroundSupport


let menuTVC = MenuTableViewControllerV2()
//#-end-hidden-code
//#-editable-code
menuTVC.resourceName = "dessert"
menuTVC.titleImageName = "surfGuy1_250w.jpg"
//#-end-editable-code
//#-hidden-code
let navVC = UINavigationController(rootViewController: menuTVC)
PlaygroundPage.current.liveView = navVC
//#-end-hidden-code
//: [Next](@next) or [Back](@previous)
