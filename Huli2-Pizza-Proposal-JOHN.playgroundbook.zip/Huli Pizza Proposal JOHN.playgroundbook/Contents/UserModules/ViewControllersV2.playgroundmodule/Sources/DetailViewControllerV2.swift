import UIKit

public class DetailViewControllerV2:UIViewController{
    public var item = MenuItem(id:0)
    func label(_ text:String, style:UIFont.TextStyle,color:UIColor = .label, background:UIColor = .clear)->UILabel{
        let l = UILabel()
        l.text = text
        l.font = UIFont.preferredFont(forTextStyle: style)
        l.textColor = color
        l.backgroundColor = background
        l.numberOfLines = 0
        return l
    }
    func image(named:String, contentMode:UIView.ContentMode)-> UIImageView{
        let img = UIImage(named:named) ?? UIImage(systemName:"x.square")!
        let imgView = UIImageView(image: img)
        imgView.contentMode = contentMode
        imgView.layer.cornerRadius = 30.0
        imgView.layer.masksToBounds = true
        return imgView
    }
    
    func vstack(views:[UIView], alignment:UIStackView.Alignment)->UIStackView{
        let stack = UIStackView(arrangedSubviews: views)
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = alignment
        return stack
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        let stack = vstack(views: [
            label("Huli Pizza Company", style: .largeTitle,color: #colorLiteral(red: 0.17647058823529413, green: 0.4980392156862745, blue: 0.7568627450980392, alpha: 1.0)),
            image(named: "\(item.id)_250w.jpg", contentMode: .scaleAspectFit),
            label(item.name, style: .title1),
            label(item.description + "     " + dollarFormat(value: item.price), style: .headline),
            UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 100))
        ], alignment: .center)
        view.addSubview(stack)
        stack.translatesAutoresizingMaskIntoConstraints = false
        var constraints = [NSLayoutConstraint]()
        constraints += [NSLayoutConstraint(item: stack, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .leading, relatedBy: .equal, toItem: view, attribute: .leading, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: stack, attribute: .trailing, relatedBy: .equal, toItem: view, attribute: .trailing, multiplier: 1.0, constant: 0.0)]
        view.addConstraints(constraints)
    }
    public override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(red: 0.25, green: 0.85, blue: 0.95, alpha: 1.0)
        self.view = view
    }
    
}

