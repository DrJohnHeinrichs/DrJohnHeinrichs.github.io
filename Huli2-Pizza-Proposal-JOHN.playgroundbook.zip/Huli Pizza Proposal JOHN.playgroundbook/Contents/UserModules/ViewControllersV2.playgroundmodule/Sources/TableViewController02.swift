import UIKit
public class MenuTableViewControllerV2:UITableViewController{
    public var resourceName = "pizza"
    public var titleImageName = "surfGirl1_250w.jpg"
    var menuItems = [MenuItem]()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        menuItems = MenuItems(resource: resourceName).menuItems
    }
    
    public override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    public override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    public override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if cell == nil{
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        let item = menuItems[indexPath.row]
        cell?.imageView?.image = UIImage(named: "\(item.id)_100w.jpg") ?? UIImage(systemName: "\(item.id).circle")
        cell?.imageView?.layer.cornerRadius = 25.0
        cell?.textLabel?.text = item.name
        let price = NumberFormatter.localizedString(from: NSNumber(value: item.price), number: .currency)
        cell?.detailTextLabel?.text = item.description + " " + price
        cell?.detailTextLabel?.numberOfLines = 0
        cell?.imageView?.layer.cornerRadius = 30.0
        cell?.imageView?.layer.masksToBounds = true
        cell?.backgroundColor = UIColor(red: 0.25, green: 0.85, blue: 0.95, alpha: 1.0)
        cell?.textLabel?.font = UIFont.preferredFont(forTextStyle: .title2)
        
        return cell!
        
    }
    
    public override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        // Has fall back to global and a SFSymbol.
        let titleImage = UIImage(named:titleImageName) ?? UIImage(named:"surfGirl1_250w.jpg") ?? badImage
        return UIImageView(image:titleImage)
    }
    
    public override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //:TODO - Navigation goes here
        let detailVC = DetailViewControllerV2()
        detailVC.item = menuItems[indexPath.row]
        navigationController?.pushViewController(detailVC, animated: true)
        console(message: "You ordered *\(detailVC.item.name)* for **\(detailVC.item.price)**")
    }
    
}

public class MenuViewController:UIViewController{
    public  var titleLabel = UILabel()
    public var item = MenuItem(id: 0)
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        //        titleLabel.frame = CGRect(x: 0, y: 0, width: view.bounds.width,height: view.bounds.height / 10.0)
        titleLabel.backgroundColor = .systemYellow
        titleLabel.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        titleLabel.textColor = .label
        titleLabel.text = item.description
        view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        var constraints = [NSLayoutConstraint]()
        constraints += [NSLayoutConstraint(item: titleLabel, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0)]
        constraints += [NSLayoutConstraint(item: titleLabel, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0)]
        view.addConstraints(constraints)
    }
}




