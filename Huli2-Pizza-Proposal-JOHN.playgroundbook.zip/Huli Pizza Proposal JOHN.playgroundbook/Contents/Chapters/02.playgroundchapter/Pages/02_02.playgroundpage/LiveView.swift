import UIKit
import PlaygroundSupport
import ViewControllers

let menuTVC = MenuTableViewController()
menuTVC.resourceName = "dessert"
menuTVC.titleImageName = "surfGirl2_250w.jpg"
let navVC = UINavigationController(rootViewController: menuTVC)
PlaygroundPage.current.liveView = navVC
//: [Next](@next) or [Back](@previous)
//:
//:
//: [Beginning](Pizza)

