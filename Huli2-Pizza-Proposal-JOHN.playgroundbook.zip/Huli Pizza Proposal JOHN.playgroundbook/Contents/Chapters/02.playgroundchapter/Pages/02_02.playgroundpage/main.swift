//:# Huli Pizza Co's Menu App
//:The pizza version of an interactive menu app
/*:
The *Huli Pizza Company* app has two versions: **pizzas** and **desserts**.
## Introduction
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac est enim. Nulla quis dolor at velit finibus ultrices. Mauris consectetur id mauris sed consectetur. Pellentesque convallis mauris eros, vel sagittis neque faucibus sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris pretium orci non neque tempor, vitae congue sem efficitur. Proin vehicula quis nunc eu ornare. Nullam in posuere risus. Donec blandit non dolor sit amet finibus.

## Features
In this version, you’ll find:
- An image of a pizza.
- An adaptable layout which sizes to the display
    - Description text detailing pizza ingredients
- Easily changeable prices and menu items through a `.json` file.

Curabitur et tincidunt risus, eu porttitor erat. Vestibulum molestie, tortor quis vehicula interdum, dui lorem laoreet ipsum, eget feugiat dui turpis id enim. Praesent quis nisl quis velit suscipit pretium. Sed varius ut erat porttitor lobortis. Integer ipsum augue, commodo et sapien nec, facilisis blandit mauris. Etiam sit amet bibendum elit. Phasellus lorem justo, vestibulum vel efficitur id, efficitur in neque. Nulla quis tortor purus. Praesent in semper lacus.
*/
//: [Next](@next)
//:
//: A proposal of [MakeAppPie.com](https://makeapppie.com).import UIKit
import PlaygroundSupport
import ViewControllers

let menuTVC = MenuTableViewController()
menuTVC.resourceName = "dessert"
menuTVC.titleImageName = "surfGirl2_250w.jpg"
let navVC = UINavigationController(rootViewController: menuTVC)
PlaygroundPage.current.liveView = navVC
//: [Next](@next) or [Back](@previous)
//:
//:
//: [Beginning](Pizza)
