import SwiftUI
import PlaygroundSupport

//:# Advanced Features
//: A example of a liveView playground. I'll show you everything this time.

struct ContentView:View{
    var body: some View{
        VStack{
            Text("Huli Pizza Company")
                .font(.largeTitle)
                .fontWeight(.heavy)
            Image(uiImage: UIImage(named: "SG1.png") ?? UIImage(systemName:"x.circle")!)
                .resizable()
                .scaledToFit()
            Text("Part 2: Dessert")
                .font(.title)
        }
    }
}
//: Here's the code to start the live view.
let view = ContentView()
let vc = UIHostingController(rootView: view)
PlaygroundPage.current.liveView = vc
//: [Next](@Next)

