

//:# Huli Pizza Co's Menu App
//:The pizza version of an interactive menu app
//:Now in SwiftUI!
/*:
 The Huli Pizza Company app has two versions: pizzas and desserts.
## Introduction
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac est enim. Nulla quis dolor at velit finibus ultrices. Mauris consectetur id mauris sed consectetur. Pellentesque convallis mauris eros, vel sagittis neque faucibus sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris pretium orci non neque tempor, vitae congue sem efficitur. Proin vehicula quis nunc eu ornare. Nullam in posuere risus. Donec blandit non dolor sit amet finibus.
 
## Features
- In this version, you’ll find:
- An image of a pizza.
- An adaptable layout which sizes to the display
- Description text detailing pizza ingredients
- Easily changeable background colors
- Easily changeable prices and menu items through a .json file.
*/
//#-hidden-code
import SwiftUI
import PlaygroundSupport
struct PizzaMenuView:View {
    var menuItemsList = MenuItems(resource:"pizza")
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color)
//#-code-completion(identifier, show, ., cyan, green, white, gray, body, title, headline, largeTitle)
//#-end-hidden-code
//#-editable-code
//: You can change these values!
    
    var backgroundColor = Color(red: 0.25, green: 0.85, blue: 0.95)
    var imageName = "surfGirl1_400w.jpg"
//#-end-editable-code
//#-hidden-code
    var body: some View{
        VStack{
            HStack{
                VStack{
                Image(uiImage: UIImage(named:imageName) ?? UIImage(systemName:"questionmark.circle")!)
                    .resizable()
                    .frame(width: 250, height: 167, alignment: .topLeading)
                    .cornerRadius(20)
                    .shadow(radius: 3)
                    
                    
                    Text("Huli Pizza Company")
                        .lineLimit(0)
                        .font(.largeTitle)
                }
                .padding()
                
                Spacer()
            }
            .background(backgroundColor)
        
            MenuListView(menuItems:menuItemsList,backgroundColor: backgroundColor)
        }
//#-end-hidden-code
            
//: You can change the font here
            
            .font(/*#-editable-code */.headline/*#-end-editable-code */)
//#-hidden-code
    }
}

let view = PizzaMenuView()
let vc = UIHostingController(rootView: view)
PlaygroundPage.current.liveView = vc
//#-end-hidden-code
