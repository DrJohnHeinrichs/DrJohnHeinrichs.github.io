//:# Huli Pizza Co's Menu App
//:The pizza version of an interactive menu app
/*:
The *Huli Pizza Company* app has two versions: **pizzas** and **desserts**.
## Introduction
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac est enim. Nulla quis dolor at velit finibus ultrices. Mauris consectetur id mauris sed consectetur. Pellentesque convallis mauris eros, vel sagittis neque faucibus sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris pretium orci non neque tempor, vitae congue sem efficitur. Proin vehicula quis nunc eu ornare. Nullam in posuere risus. Donec blandit non dolor sit amet finibus.

## Features
In this version, you’ll find:
- An image of a pizza.
- An adaptable layout which sizes to the display
    - Description text detailing pizza ingredients
- Easily changeable prices and menu items through a `.json` file.

Curabitur et tincidunt risus, eu porttitor erat. Vestibulum molestie, tortor quis vehicula interdum, dui lorem laoreet ipsum, eget feugiat dui turpis id enim. Praesent quis nisl quis velit suscipit pretium. Sed varius ut erat porttitor lobortis. Integer ipsum augue, commodo et sapien nec, facilisis blandit mauris. Etiam sit amet bibendum elit. Phasellus lorem justo, vestibulum vel efficitur id, efficitur in neque. Nulla quis tortor purus. Praesent in semper lacus.
*/
//: [Next](@next)
//:
//: A proposal of [MakeAppPie.com](https://makeapppie.com).
//  #  -  hidden-code
import UIKit
import PlaygroundSupport






class MenuViewController:UIViewController{
    var titleLabel = UILabel()
    var item = MenuItem(id: 0)
    func Label(text:String)->UILabel{
        let label = UILabel()
//        label.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height / 10.0)
        view.bounds
        label.backgroundColor = .systemYellow
        label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        label.textColor = .label
        label.text = text
        return label
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel = Label(text: item.description)
        view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        var constraints = [NSLayoutConstraint]()
        constraints += [NSLayoutConstraint(item: titleLabel, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: titleLabel, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0.0)]
        view.addConstraints(constraints)
        
    }
    override func loadView() {
        UIDevice.current.model
        let view = UIView()
//        view.frame = CGRect(x: 0, y: 0, width: 375, height: 667)
        view.backgroundColor = .systemBackground
        self.view = view
    }
}

class MenuTableViewController:UITableViewController{
    /// An array of menu items. Read them through the `MenuItems` class by a`.json` resources found in **Resources**
    var menuItems = MenuItems(resource: "pizza").menuItems
   func Label(text:String)->UILabel{
           let label = UILabel()
   //        label.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height / 10.0)
           view.bounds
           label.backgroundColor = .systemYellow
           label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
           label.textColor = .label
           label.text = text
           return label
       }
    public override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    public override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    public override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        
        let row = indexPath.row
        let item = menuItems[row]
        let badImage = UIImage(systemName:"\(item.id).circle")
        cell?.imageView?.image = UIImage(named: "\(item.id)_100w.jpg") ?? badImage
        cell?.textLabel?.text = item.name
        cell?.detailTextLabel?.text = item.description
        cell?.frame
        cell?.textLabel?.text
        cell?.imageView?.image
//#-code-completion(everything, hide)
//#-code-completion(literal, show, color)
//#-code-completion(identifier, show, ., blue, black, red, gray, cyan, green, white)
//  #  -  end  -hidden-code
//:
//: Change the colors here
        /*#-editable-code Color */cell?.backgroundColor = .white/*#-end-editable-code*/
        cell?.textLabel?.textColor = /*#-editable-code Color */#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)/*#-end-editable-code*/
//#-hidden-code
        
        return cell!
    }
    
    public override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let titleImage = UIImage(named:"surfGirl1_250w.jpg")
        return UIImageView(image: titleImage ?? badImage)
        //return Label(text: "Huli Pizza Company")
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = DetailViewController()
        detailVC.item = menuItems[indexPath.row]
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
}
let menutableVC = MenuTableViewController()
let menuVC = MenuViewController()
let navVC = UINavigationController(rootViewController: menutableVC)
PlaygroundPage.current.liveView = navVC
//#-end-hidden-code
