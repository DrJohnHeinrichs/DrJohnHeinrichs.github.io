import Foundation
import PlaygroundSupport

public func console(message:String){
    #if (arch(arm)||arch(arm64))
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
    #endif
}
public func console(hints:[String]){
     #if (arch(arm)||arch(arm64))
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
    #endif
}

public class MenuItems{
    
    struct MenuList:Codable{
        var items:[MenuItem] = []
    }
    
    var menu = MenuList()
    
    /// An array of menu items
    public  var menuItems:[MenuItem]{
        menu.items
    }
    
    /// Returns menu items from a specified `.json` file
    /// - Parameter resource: A `String` specifying the file name. Leave off the extension.
    public func menuFromJson(resource:String) -> [MenuItem]{
        var menu = MenuList()
        guard let url = Bundle.main.url(forResource: resource, withExtension: "json")
            else{
                //console(message:"Did not find resource \(resource).json")
                console(hints: [
                    "**Error:** Did not find resource `\(resource).json`, Did you add it to the resources?",
                    "**Error:** Did not find resource `\(resource).json`, Did You misspell the name?"
                ])
                print("Did not find resource \(resource).json")
                return []
        }
        
        guard let jsonModel = try? Data(contentsOf: url) else {
            print("Could not read json file")
            return []
        }
        
        do{
            try menu = JSONDecoder().decode(MenuList.self, from: jsonModel)
        } catch let error as NSError{
            print("Error reading JSON file: \(error.localizedDescription)")
        }
        return menu.items
    }
    
    /// Create a  blank `MenuItem` array.
    public init(){
        menu.items = []
    }
    
    /// Create a `MenuItem` array with data from a `.json` file.
    /** - Leave off the `.json` extension in `resource` */
/** - The `resource` file should be in the *local* bundle. (**Resources**)*/
    /// - Parameter resource: `String` with name of resource without an extension.
    public init(resource:String){
        menu.items = menuFromJson(resource: resource)
    }
    
    /// Returns dummy data for early testing
    public class func testMenuItems()-> [MenuItem] {
        var items:[MenuItem] = []
        for i in 0 ... 9 {
            items += [MenuItem(id: i)]
        }
        return items
    }
    
}
