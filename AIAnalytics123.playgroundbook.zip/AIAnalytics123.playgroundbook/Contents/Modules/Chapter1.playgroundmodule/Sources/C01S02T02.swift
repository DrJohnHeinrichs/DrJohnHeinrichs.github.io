//
//  C01S02T02.swift
//  Book_Sources
//  Chapter 01: Section 02: Topic 02: Trends Favoring Business Analytics
//
//  Created by SBAMBP on 4/01/20.
//
import SwiftUI

public struct C01S02T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ----------------------
        // SECTION 2: Start
        // ----------------------
        NavigationView {
            List {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "folder.circle")
                        Text("Rationale for Business Analytics")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("The application of analytics to business problems is the ultimate goal of business analytics.  Business analytics has been applied to enhance revenue, reduce costs, and mange risks resulting in competitive advantage for the firm.\n")
                        .font(.system(size: 18))
                    Text("The term business analytics refers to a broad category of applications, technologies, and processes used for creating new insights and knowledge for better business decisions.  Business intelligence is used by the information technology community for similar applications, technologies and processes.  Business analytics focus on making business decisions based on large and complex data sets and providing solutions for analyzing big data with advanced statistical models, databases, and software tools.  With the increased growth of structured and especially unstructured data, firms need to develop business analytics competence to remain competitive in global markets.  Business analytics provide the ability to handle unstructured data such as voice, text, images, and video as well as structured data.\n")
                        .font(.system(size: 18))
                    Text("The rationale for utilizing and adopting business analytics include many varied and different reasons.  The rationale for business analytics may vary by firms.  First, firms are utilizing business analytics to achieve a competitive advantage by supporting a firm’s strategic and tactical goals.  Firms are utilizing business analytics for better organizational performance, better business outcomes, and a more informed decision process.  Firms are pursuing superb knowledge production by obtaining value and generating insights from data.\n")
                        .font(.system(size: 18))
                    Text("The ultimate goal of business analytics is generating value from big data in the sense of supporting knowledge acquisition, insight generation, problem finding, and problem solving to help decision-making.  Firms use data and related insights to drive fact-based planning, decisions, and execution, as well as the management, measurement, and learning for data-driven decision-making.  With business analytics, evidence-based problem recognition and solving can happen within the context of a marketing situation.\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                } // Section 1
                    .padding(.bottom, 30)
            } // List -- text
                .padding(30)
            .font(.system(size: 22))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("2.2 Rationale for Business Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // SECTION 2: End
        // ----------------------
    } // body
} // struct
