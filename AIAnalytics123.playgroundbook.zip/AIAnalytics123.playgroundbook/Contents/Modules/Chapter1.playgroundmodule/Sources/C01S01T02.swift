//
//  C01S01T01.swift
//  Book_Sources
//  Chapter 01: Section 01: Topic 01: Business Analytics Definition
//
//  Created by SBAMBP on 3/29/20.
//
import SwiftUI

public struct C01S01T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ----------------------
        //
        // TOPIC 2: Start
        // ----------------------
        NavigationView {
            List {
                Section {
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "lightbulb")
                            Text("Competitive Advantage")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                        Text("It has been established in previous research studies that the firm can gain competitive advantage through improved problem-solving and decision-making performance.  Increasing the competitive advantage for the firm can be achieved by effectively using the various skills and competencies of the firm’s analysts performing the insight generation tasks.  Firms can gain advantage by generating insights and intelligence that can answer a variety of important business questions.  So, exploiting the vast quantity of data becomes both a monumental challenge and a tremendous opportunity for the firm’s analysts tasked with providing useful, action-oriented support to the firm’s management team.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "lightbulb")
                            Text("High Quality Information")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                        Text("Firms can cultivate and maintain various types of competitive advantage supported by business analytics.  Effective planning and decision-making require good, high quality information.  Thus, valuable information can provide the firm with the ability to perform at a higher level, make better decisions, and participate effectively in the competitive marketplace.  Five key focus areas for competitive advantage pursued by firms and how business analytics can help achieve competitive advantage include pricing, service, operational efficiencies, risk reduction, and performance monitoring strategies.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "dollarsign.square")
                            Text("First Focus Area: Pricing Strategies")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                        Text("In the first focus area, business analytics can support effective pricing strategies to increase customer profitability.  Business analytics can provide detailed information on competitor products and allow firms to maintain price leadership.  Firms can identify main competitors and then monitor, report, and accurately forecast competitive prices.  This information can be used to keep the lowest cost profile while maintaining and measuring profit margins.  This information can also be used to set prices to keep profit margins at a profit-maximizing level by balancing sales volume with lower prices and margins or increase prices to increase margins depending on competitor pricing.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "rectangle.stack.person.crop")
                            Text("Second Focus Area: Effective Service Strategy")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                        Text("In the second focus area, business analytics can support an effective service strategy.  This strategy entails making customer transactions easier or more pleasant by improving the service characteristics of the firm such as decreasing service time and enhancing customer value.  Business analytics provides information about customer opinions on problem service areas, possible solutions, and methods to improve the service operations.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "gauge.badge.plus")
                            Text("Third Focus Area: Operational Efficiency and Optimization")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                            {
                        Text("In the third focus area, business analytics can help firms achieve operational efficiency and optimization.  This strategy focuses on improving the internal business operations and activities over competitors and reducing cost.  Business analytics can identify operational areas needing correction or modification and suggest optimal solutions to maximize business performance.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "lock.rotation")
                            Text("Fourth Focus Area: Risk Reduction and Firm Sustainability")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                            {
                        Text("In the fourth area, business analytics can help firms achieve risk reduction and firm sustainability.  This strategy focuses on identifying areas needing resource reallocations and reducing the risk of poor judgments.  Business analytics can offer information about the probabilistically computed likelihood of certainty on sales, budgets, and the best optimal balance.\n")
//                            .font(.system(size: 18))
                        }
                    // ----------------------
                    Section (header: HStack {
                            Image(systemName: "hare")
                            Text("Fifth Focus Area: Business Performance")
                                .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                        Text("Finally, the fifth focus area examines how business analytics can provide information about business performance by tracking specific business performance parameters continually.  A real time performance achievement index can be provided by business analytics so that managers can compare performance over time and set planning and performance goals to guide operations based on forecasts of expected performance.\n")
//                            .font(.system(size: 18))
                        }
                        // ----------------------
                } // Section 1
                    .padding(.bottom, 30)
            } // List -- text
//                .padding(30)
            .font(.system(size: 18))
//            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1.2 Business Analytics as a Firm Strategy", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // TOPIC 2: End
        // ----------------------
    } // body
} // struct
