//
//  C01S01T01.swift
//  Book_Sources
//  Chapter 01: Section 01: Topic 01: Business Analytics Definition
//
//  Created by SBAMBP on 3/29/20.
//
import SwiftUI

public struct C01S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ----------------------
        // SECTION 1: Start
        // ----------------------
        NavigationView {
            List {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "folder.circle")
                        Text("Business Analytics Definition")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("The use of various business analytics by the firm is of paramount importance as business analytics are used to create knowledge and generate meaningful insights thus leading to more informed, fact-based conclusions.  Since the terms “business analytics”, “business intelligence”, and “big data” are used somewhat interchangeably, it is important to define, describe, and differentiate the term “business analytics” and its use by the firm.\n\nThe term “business analytics” is created and defined as “the focus on the extensive use of data, statistical and quantitative analysis, explanatory and predictive models, and (a culture of) fact-based management to drive actions” for the firm.  Thus, business analytics can be viewed as “a broad category of applications, technologies, and processes for gathering, storing, accessing, and analyzing data to help analysts”.\n\nBusiness analytics can be used by the analysts to answer a variety of probing questions such as, “Why is this pattern occurring for this product line?”, “What if specific performance trends continue?”, “What is expected to happen in future time periods?”, and “Given various options, what is the best possible outcome that can occur?”.  More recently, various “big data” terminology concepts have been incorporated into the business analytics definition by expanding the definition to include “a combination of skills, technologies, applications, and processes that enable firms to analyze an immense volume, variety, and velocity of data across a wide range of networks to support informed decision-making and action-taking”.\n\nBy simplifying this discussion, business analytics can be further explicated by defining it as “a set of methods that transform data into action by generating insights used for decision-making by the firm”.  Yet, its focus is more than just “decision-making”.  Business analytics is also concerned with evidence-based problem recognition and problem-solving within the context of business situations as not every situation requires decision-making.  While the definition and use of the term, business analytics, is still evolving, business analytics has become the art and science of discovering insights by using artificial intelligence methods and machine learning as well as the sophisticated mathematical, statistical, and network science methodologies on the volumes of available structured and unstructured data as well as expert business domain knowledge to support decision-making.  Therefore, business analytics can be viewed as an enabler for decision-making and creative problem-solving.  As firms are increasingly being managed through the use of advanced information technology, it is more important than ever for managers to use available analytical methods and gain business analytical competence.\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "tray.full")
                        Text("Integrate Big Data into Business Analytics")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("In defining, describing, and differentiating business analytics, it is important to recognize the integration of business intelligence and big data concepts into business analytics along with the strong focus on data, models, analysis, and an evidenced-based culture.  “Big data” adds massive amounts of data and data types from various sources which can be used to support a varriety of actions over varying time-frames for the analyst.  The strong focus on the creation of models by the analyst focuses primarily in the explanatory context for business orientation tasks.  Further, an important, but often overlooked aspect of the definitions for business analytics involves the analytic culture of the firm.  Firms also need to ensure that the business analytics from using data for fact-based decision-making and problem-solving and the generated insights from the various explanatory, predictive, and prescriptive models need to be actionable.  To become actionable, the generated insights need to be connected to all aspects of the process used to enhance problem-solving and decision-making in the firm.\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                } // Section 1
                    .padding(.bottom, 30)
            } // List -- text
                .padding(30)
            .font(.system(size: 22))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1.1 Business Analytics Definition", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // SECTION 1: End
        // ----------------------
    } // body
} // struct
