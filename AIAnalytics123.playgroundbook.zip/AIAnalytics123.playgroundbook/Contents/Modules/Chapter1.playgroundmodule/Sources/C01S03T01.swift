//
//  C01S03T01.swift
//  Book_Sources
//  Chapter 01: Section 03: Topic 01: Business AnalyticsTypes
//
//  Created by SBAMBP on 3/29/20.
//
import SwiftUI

public struct C01S03T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingDescriptiveSheet = false
    @State private var showingDiagnosticSheet = false
    @State private var showingPredictiveSheet = false
    @State private var showingPrescriptiveSheet = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------------------
        // SECTION 1: Start
        // ------------------------------------------
        NavigationView {
            ScrollView {
                VStack (alignment: .leading) {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Business Analytics Types: Overview")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                        } )
                        {
                    Text("There are four types of business analytics -- Descriptive, Diagnostic, Predictive, and Prescriptive.\n\n")
                    } // Section -- HEADER
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "1.circle")
                        Text("Business Analytics Types: Descriptive Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                            Button("Click to begin ... Descriptive Analytics Discussion") {
                            self.showingDescriptiveSheet.toggle()
                        }
                        .sheet(isPresented: $showingDescriptiveSheet) {
                            DescriptiveAnalyticsView()
                        }
                    } // Section -- DESCRIPTIVE
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "2.circle")
                        Text("Business Analytics Types: Diagnostic Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ... Diagnostic Analytics Discussion") {
                            self.showingDiagnosticSheet.toggle()
                        }
                        .sheet(isPresented: $showingDiagnosticSheet) {
                            DiagnosticAnalyticsView()
                        }
                    } // Section -- DIAGNOSTIC
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "3.circle")
                        Text("Business Analytics Types: Predictive Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ... Predictive Analytics Discussion") {
                            self.showingPredictiveSheet.toggle()
                        }
                        .sheet(isPresented: $showingPredictiveSheet) {
                            PredictiveAnalyticsView()
                        }
                    } // Section -- PREDICTIVE
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "4.circle")
                        Text("Business Analytics Types: Prescriptive Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ... Prescriptive Analytics Discussion") {
                            self.showingPrescriptiveSheet.toggle()
                        }
                        .sheet(isPresented: $showingPrescriptiveSheet) {
                            PrescriptiveAnalyticsView()
                        }
                    } // Section -- PRESCRIPTIVE
                    // ----------------------
                } // Section Main
                .padding(.bottom, 30)
            } // List -- text
            .padding(30)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3.1 Business Analytics Types", displayMode: .inline)
        } // NavigationView
       .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------------------
        // SECTION 1: End
        // ------------------------------------------
    } // body
} // struct
// ------------------------------------------
// DESCRIPTIVE VIEW
// ------------------------------------------
struct DescriptiveAnalyticsView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Descriptive Analytics: Overview")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Descriptive analytics focus on answering what happened in the past, what is happening now, and what will likely to happen based upon the past.  These analytics apply simple statistical techniques that explore data and describe what is contained in a data set or database.  For example, descriptive analytics can be used to identify possible trends in large data sets or databases to get a rough picture of what the data looks like.  Descriptive analytics, based on historical and current data, is a signiﬁcant source of insights about what happened in the past and the correlations among various determinants identifying patterns using statistical measures such as mean, median, range, and standard deviation.  Descriptive analytics using techniques like online analytical processing exploit knowledge from the past experience to provide answers to what’s happening in the firm.  Descriptive analytics can identify a problem by analyzing historical data.  Descriptive analytics employ data visualization by using simple reports, dashboards, and scorecards as well as commonly provide information to marketing managers using business intelligence tools.  Descriptive analytics can pinpoint and introduce the problem areas and can lead to more advanced solutions with data exploration.\n\n").padding(10)
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Data Exploration")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Data exploration focuses on data summaries, visualization, partitioning, and dimension reduction.  Managers need to become familiar with the data and can therefore explore the nature of data through summaries, tables, and graphs.  Data summaries are presented with descriptive statistics such as average, standard deviation, minimum, maximum, median, counts, differences, and pairwise correlations.  Data visualization can be quite useful in exploring data.  Managers can explore graphs and tables as well as box plots and histograms to understand data distribution and relationships between numerical variables and detect patterns and outliers.  Dimension reduction allows managers to reduce the number of categories or predictors.  Principal components analysis and correspondence analysis are useful procedures for reducing the number of variables.  Principal components analysis is used for continuous variables and the correspondence analysis is used for categorical variables.  Common examples of descriptive analytics include data visualization, dashboards, reports, charts, and graphs presenting key performance metrics including, for example, sales, orders, customers, and ﬁnancial information.  Descriptive analytics provide basic expository information in the form of canned reports such as canned sales reports or ad-hoc reports for specific issues.\n\n").padding(10)
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Descriptive Solutions")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Descriptive analytics focuses on analytics of the past and the present.  Descriptive solutions are used to identify trends in large data sets or databases.  The goal is to get an overall picture of what the data looks like and understand trends or future business behavior.  Simple statistical techniques are applied to describe what is contained in a data set or database.  Descriptive statistics such as measures of central tendency (mean, median, and mode), measures of dispersion (standard deviation), and visualization tools (charts, graphs, frequency tables, and probability distributions) are typically used to derive descriptive analytic solutions.  Descriptive analytics provide managers with alerts (information regarding what actions are needed), query/drill down (information regarding what the problem exactly is), ad-hoc reports or scorecards (information regarding how many, how often, where problems or events are happening), and standard reports (information regarding what happened).\n\n").padding(10)
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Performance Analytics")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Often called performance analytics or effective analytics, descriptive analytics solutions are designed to provide analysts with a complete description and view of the firm’s strategic and tactical activities, performances, customer history, and behavior patterns up to the present moment.  These analytics can track the firm’s (as well as competitor’s) performance against the firm metrics set for managing strategy and tactical behavior.  With these analytics solutions, firms can have a complete view of their customers, market comparison information, success and failure of tactical decisions, and customer and organizational performance.  These solutions provide insights regarding how the firm reached the present situation and what behavior patterns it followed so far.  Pure descriptive analytics solutions cannot offer answers to future events and strategies.  However, descriptive analytics are the foundation for predictive analytics.\n\n").padding(10)
            }
            .padding(15)
            Button("Finished: Descriptive Analytics") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// DIAGNOSTIC VIEW
// ------------------------------------------
struct DiagnosticAnalyticsView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Diagnostic Analytics: Overview")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Diagnostic analytics provide answers to questions such as how and why did it happen in the past and why is it happening now.  Diagnostic analytics based in historical data also provide insights about the root-cause of some outcomes of the past.  Diagnostic analytics search for cause and effect to illustrate why something occurred and compare past occurrences to determine causes.  Diagnostic analytics help managers by identifying outliers that need additional examination, isolating patterns that exists outside of the existing dataset, and uncover relationships by isolating unique relations.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Diagnostic Analytics: Uses")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Thus, firms can make better decisions by avoiding errors and negative results of the past.  Diagnostic analytics try to find why the problem occurs.  Diagnostic analytics are typically generated after managers conduct descriptive analyses.  To find the cause of a problem, data mining and drill-into analytics are needed to find patterns, trends, and relationships.  Diagnostic analytics can provide context to a business problem using data models and more complex analysis.  Diagnostic analytics requires managers’ accurate interpretation of patterns to evaluate the cause of the problem in addition to accurate and complex analyses.  Queries and drill-downs allow managers to generate more detailed reports.\n\n")
            }
            .padding(15)
            Button("Finished: Diagnostic Analytics") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// PREDICTIVE VIEW
// ------------------------------------------
struct PredictiveAnalyticsView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Predictive Analytics: Overview")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Predictive analytics can answer questions related to what possible trends or changes in markets and customers exist that can provide information about possible course of actions to be taken and likelihood of possible outcomes.  Predictive analytics provides calculated predictions and is very complex.  Predictive analytics are more likely to use advanced techniques such as data mining, machine learning, and predictive modeling to generate actionable insights and intelligence.  These analytics can generate predictions from algorithms that can help managers to avoid mistakes and wrong decisions based on big data.  Predictive analytics apply advanced statistical or operational research methods to identify predictive variables or build predictive models to identify trends and relationships.  For example, predictive analytics can build a model that explains why a set of variables influence market performance in a given market.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Prediction Techniques")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Prediction techniques include multiple linear regression, regression trees, time series analysis, and neural networks.  Classification techniques include logistic regression, naïve Bayes, classification trees, neural networks, and discriminant analysis.  Logistic regression extends linear regression to the categorical dependent variable case.  Logistical regression can be used for classification (e.g. classifying customers into one of the two classes, loyal and non-loyal customers, based on the values of its predictors) and profiling (i.e. finding factors that differentiate among pre-defined groups).  Neural networks can capture very complex relationships between predictors and a response providing high predictive performance.  This technique combines the input information in a very flexible way in order to capture complicated relations among these input variables.  This technique tries to find relationships from learning the patterns existing within the data.  Discriminant analysis can also be used for classification and profiling.  For example, this technique uses continuous variables to classify new items into one of the classes identified (classifying customers into non-users, light users, and heavy users).  Clustering can be done using cluster analysis.  Cluster analysis identifies groups or clusters of similar characteristics or records based on several measurements.  The goal is to identify and characterize the clusters that can provide meaningful insights to managers.  This technique is commonly used for market segmentation where customers are segmented based on predetermined variables such as demographics, behavioral measures, and transaction records.  Affinity analysis utilize association rules and is also called market basket analysis.  This technique is looking for associations between items that are stored in the database.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Predictive Analytics")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Predictive analytics is about forecasting and providing an estimation for the probability of a future result as well as evaluating opportunities or risks in the future.  Using various techniques including data mining, data modeling, and machine learning, the implementation of predictive analytics can be applied to various decision tasks of the firm.  One of the most known applications of that type of analytics is the prediction of customer behavior, determining operations, marketing, and preventing risk.  Using historical and other available data, predictive analytics are able to uncover patterns and identify relationships in data that can be used for forecasting.  Predictive analytics in the digital era is a critical weapon for firms in the competitive race.  Therefore, firms exploiting predictive analytics can identify future trends and patterns, presenting innovative products/services and innovations in their business models.  Prescriptive analytics provide a forecasting of the impact of future actions before they are taken, answering “what might happen” as outcome of the firm’s actions.  Therefore, the decision-making is improved taking under consideration the prediction of future outcomes.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Predictive Analytics: Metrics and Models")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Predictive analytics offers metrics and models that are predictive of future events, outcomes, or occurrences.  Predictive analytics provide predictive models designed to identify future trends.  In developing predictive analytic solutions, advanced statistical techniques (e.g., multiple regression and ANOVA), information software (e.g., data mining and sorting), or operations research methods (e.g., forecasting methods) are used to develop predictive models with identified predictive variables.  Predictive analytics provide managers predictive modeling/forecasting (information regarding what will happen next) and statistical modeling results (information regarding what is happening).  These analytics solutions get both interesting and challenging but, if successful, are most rewarding.  Most of the strategic, customer-related, and tactical decisions are made with some form of predictions or estimations in mind.  Traditionally, analysts rely more on their intuition, experience, or limited marketing research results to make these decisions.  With the development of data-mining tools based on integrated multidimensional databases, more sophisticated analytical solutions can be easily developed and are accessible by marketing managers through web-based visualization and reporting tools.  Additionally, the sophistication of these analytics models can reduce predictive errors significantly and render more rational decisions in the dynamic and fast changing decision environment.\n\n")
            }
            .padding(15)
            Button("Finished: Predictive Analytics") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// PRESCRIPTIVE VIEW
// ------------------------------------------
struct PrescriptiveAnalyticsView: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        ScrollView {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Prescriptive Analytics: Overview")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Prescriptive analytics provide answers to questions regarding how best to leverage what is known from the trends and forecasts as well as how firms can optimally allocate resources to maximize the business performance outcomes in the future.  Prescriptive analytics apply decision science, management science, and operations research methodologies and techniques to provide the optimal solutions or alternatives for business problems.  Prescriptive analytics generate prescriptive models and new rules based on historical and external information using machine learning techniques.  This type of analytics requires extensive sophisticated analytical tools and analytical capability.  For example, prescriptive analytics help firms allocate resources optimally to take advantage of predicted trends or emerging opportunities.  Prescriptive analytics offer value to firms through recommendations and specific suggestions built on the big data analysis.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Descriptive Analytics: Outcomes")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Prescriptive analytics using high level modeling tools is able to contribute to the performance enhancement and efficient operation of firms through smarter and faster decisions with lower costs and risk thus identifying optimal solutions for resource allocation.  The advanced predictive and prescriptive analytics can play a crucial role in efficient strategic decision-making dealing with critical and important problems faced by firms such as the design and development of products/services and supply chain formation.  Prescriptive analytics predict outcomes based on numerous variables using machine learning with big data.  Predictive analytics also use artificial intelligence to generate probable answers to what-if questions and suggest courses of action.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Descriptive Analytics: Goal")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("Prescriptive analytics solutions focus on future directions and best solutions.  The goal of prescriptive analytic solutions is to allocate the firm’s limited resources optimally to enhance firm performance by utilizing predicted trends or future opportunities.  Operational research methodologies (e.g., linear programming), decision science (e.g., decision analysis), and management science techniques (e.g., simulation and randomized testing) are typically used to generate prescriptive analytic solutions such as how to allocate the adverting budget to various advertising media or target customers.  Prescriptive analytics provide managers optimization solutions (information regarding what is the best that can happen) and randomized test outcomes (information regarding what if we try this).  Prescriptive analytics utilize mathematically based methodologies, algorithms, and approaches to generate an optimal or best sub-optimal solution to complex problems.  Using the prescriptive analytic solutions, firms can best plan future actions and directions based on the scientifically derived models and predictions.  This is the final step in analytics-driven decision-making.\n\n")
            }
            .padding(15)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Summary")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("From problem identification to predictions and actionable alternative solutions, the four type of analytics provides value and competitive advantage for firms.  These four types of analytics can help manager in different decision stages and contexts.  These analytic types can provide solutions at the strategic, customer, and tactical decision areas of the firm.\n\n")
            }
            .padding(15)
            Button("Finished: Prescriptive Analytics") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
