//
//  C01S03T02.swift
//  Book_Sources
//  Chapter 01: Section 03: Topic 02: Business Analytics Categories
//
//  Created by SBAMBP on 3/29/20.
//
import SwiftUI
// ----------------------
// ----------------------
public struct C01S03T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingStrategicAnalyticsSheet1 = false
    @State private var showingScanningAnalyticsSheet1 = false
    @State private var showingTacticalAnalyticsSheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Business Analytics Categories: Overview")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    Text("Another way of categorizing analytics solutions is to classify the analytics solution by the nature of problems and the impact on a firm’s marketing decision-making process.  The ever-growing sources of information and the availability of sophisticated data-mining tools make various analytical solutions available to almost all firms.  In the past, these sources and tools were beyond the reach of most firms due to cost, analytical sophistication, technical, and information technology infrastructure requirements.  Thus, the analytics generated from both the internal and external perspectives can be classified into three major categories.  These categories are labeled strategic analytics, scanning / customer-related analytics, and tactical analytics.\n")
                    } // Section -- HEADER
                        .padding(15)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Business Analytics Categories: Strategic Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ...  Strategic Analytics Discussion") {
                            self.showingStrategicAnalyticsSheet1.toggle()
                        }
                        .sheet(isPresented: $showingStrategicAnalyticsSheet1) {
                            StrategicAnalyticsView1()
                        }
                    } // Section -- STRATEGIC
                        .padding(15)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Business Analytics Categories: Scanning Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ...  Scanning Analytics Discussion") {
                            self.showingScanningAnalyticsSheet1.toggle()
                        }
                        .sheet(isPresented: $showingScanningAnalyticsSheet1) {
                            ScanningAnalyticsView1()
                        }
                    } // Section -- SCANNING
                        .padding(15)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Business Analytics Categories: Tactical Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                        Button("Click to begin ...  Tactical Analytics Discussion") {
                            self.showingTacticalAnalyticsSheet1.toggle()
                        }
                        .sheet(isPresented: $showingTacticalAnalyticsSheet1) {
                            TacticalAnalyticsView1()
                        }
                    } // Section -- TACTICAL
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3.2 Business Analytics Categories", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// STRATEGIC ANALYTICS VIEW
// ------------------------------
struct StrategicAnalyticsView1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Strategic Analytics Solution: Interface Information")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("The strategic analytics solution provides the senior management of the firm with the interface information between the firm and the environment in which that firm chooses to operate.  In the past, senior executives and management teams used their personal experience to assess the firm’s capabilities and to define the strategic directions that they felt were best suited for the firm.  In the current dynamic and rapidly changing environment, the traditional assumptions and experience-based decision-making used by these individuals may be becoming faulty and inappropriate.  The new decision-making paradigm requires significant reliance on competitive intelligence and analytics support.  This competitive intelligence and analytics support provides strategic solutions built on the vast array of information sources, data-mining tools, and user interface tools.  These solutions are conveniently stored in the analytics warehouse for easy retrieval, access, and further analysis.\n\n")
            }
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Strategic Analytics Solution: Support Mission")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("The strategic solutions are primarily used to support the strategic missions of the firm and are inclusive of various categories and forms.  The strategic solutions may be fast answers to management ad-hoc queries, they may be identified patterns, and/or they may be models used for long-range planning in each of the specialization, latest news, or specialized information topic areas.  These strategic solutions view the firm as a whole and as comprising various markets and operating in many market segments.  As a result, the information needs of the firm are quite varied and diverse.  The strategic solution should particularly focus on important trends that can be used to discover and create new opportunities and avoid risks in light of the firm’s strengths and weaknesses.  The strategic solution should also support the firm’s plans and strategic goals.  The strategic solutions can include industry-specific developments, competitor information, government policy and position changes, economic and financial data, and technological trends.  Thus, the strategic solution is relevant and timely, and it is applied to a long-term planning horizon.\n\n")
            }
            Button("Finished: Strategic Analytics View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// SCANNING / CUSTOMER-RELATED ANALYTICS VIEW
// ------------------------------------------
struct ScanningAnalyticsView1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Scanning Analytics Solution: External Developments")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("The scanning / customer-related analytic solutions are used to monitor or scan for various external developments relevant to the firm and to gain a better understanding of customer needs and requirements.  The external developments that the knowledge worker can scan for include competitor actions, industry developments, financial conditions of customers, competitors and suppliers, and government regulatory issues that may have an impact of the products and services offered by the firm.  The environment can be extended to market and buyer behaviors and include buyer purchasing trends.\n\n")
            }
            Button("Finished: Scanning / Customer-related Analytics View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// TACTICAL ANALYTICS VIEW
// ------------------------------------------
struct TacticalAnalyticsView1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Tactical Analytics Solution: Specific Problem")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
                Text("The tactical analytics solutions are used to solve a specific analytic problem at hand.  Managers are taking specific tactical solutions by implicitly or explicitly estimating the results of their tactical decisions.  These solutions provide analytical patterns and models that can help reduce uncertainty and error in their tactical decision-making.\n\n")
            }
            Button("Finished: Tactical Analytics View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
