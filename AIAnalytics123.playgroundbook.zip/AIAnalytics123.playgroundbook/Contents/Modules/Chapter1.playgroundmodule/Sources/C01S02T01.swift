//
//  C01S02T01.swift
//  Book_Sources
//  Chapter 01: Section 02: Topic 01: Trends Favoring Business Analytics
//
//  Created by SBAMBP on 4/01/20.
//
import SwiftUI

public struct C01S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ----------------------
        // SECTION 1: Start
        // ----------------------
        NavigationView {
            List {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "folder.circle")
                        Text("Trends Favoring Business Analytics")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("The trends that facilitate or support the use of business analytics are emerging.  These include the following trends.  First, there exists availability of large amounts of data.  The amount of information created in a day is huge and the pace of information creation is increasing.  The current amount of data created every day exceeds 2.5 quintillion (2.5 million trillion) bytes of data.  A second trend is the increasing realization that data is a valuable resource and should be managed as an asset.  A third trend is the well-established linkage of business strategy, data, and business performance.  High level strategy is translated into a concrete set of performance metrics allowing the implementation of the firm’s strategy based on metrics.  Cultural change towards evidence-based management is becoming common in many firms as is the realization of the importance of fact-based decisions at every level of firm.  Access to large databases and user-friendly tools provided analysts and managers with self-service analytics and sophisticated algorithms.  Yet, there exists the need for better business decisions.\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                } // Section 1
                    .padding(.bottom, 30)
            } // List -- text
            .padding(30)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("2.1 Trends Favoring Business Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // SECTION 1: End
        // ----------------------
    } // body
} // struct
