//
//  C02S03T01.swift
//  Book_Sources
//  Chapter 02 Section 03: Topic 01: Analytics Tools and Software
//
//  Created by SBAMBP on 4/03/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ----------------------
// ----------------------
public struct C02S03T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable23Sheet1 = false
    @State private var showingScanningAnalyticsSheet1 = false
    @State private var showingTacticalAnalyticsSheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Tools - Task Orientation")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Firms acquire or develop appropriate business analytic tool capabilities considering the adopted business analytics task orientation.  There is a strong connection between the business analytic tool sophistication and the quality of insights and decision achieved by the firm.  The effective use of business analytic tools indirectly influences problem-solving and decision-making efficiency and effectiveness.  Therefore, it is important to build the right capabilities of the business analytic tools that can facilitate the business analytics task orientation.\n\n  The various business analytic tool capabilities include three distinct categories of analytic, decision, and information capabilities.  The business tools analytic capabilities contain a portfolio of various analysis methods, tools, and data transformations.  Examples of these analytic capabilities include content analytics, speech analytics, and/or text analytics as well as ad-hoc query, dashboards, and visualizations.  The decision capabilities of the tool platform contain applications to help analysts learn, share, and understand the data.  Examples of decision capabilities include scenario modeling and simulation allowing the analysts to communicate simulation or scenario modeling results that could optimally balance required trade-offs.  The information capabilities focus on the technology infrastructure that ensures proper interfaces with other parts of the firm permitting the exchange of data, documents and other content.  The level of capabilities achieved by firms must support firms’ business analytics task orientations and be consistent to their business analytics needs and goals.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Trade-off")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        Text("Firms must also combine these tool capabilities by establishing proactive use of an information environment in which insight generation is based on rationality.  Managers with analytical styles will adopt and use the firm’s business analytics tools to a greater extent than managers with conceptual styles.  Hence, a firm’s business analytics task orientation with the right analytics culture can help with overcoming the trade-off between reach and richness of the various business analytic tools.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Relationship Between Task and Tool")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Table 2 3 shows the chi-square test for the relationship between business analytics task orientation and business analytics tools used by firms.  In performing this test, the business analytics tools that were mentioned in less than 10 firm postings were combined into the ‘other’ category.  The chi-square test indicates a non-significant relationship between business analytics task orientation and tools used.  The selected firms reported a total of 62 analytics tools in their job posts.  Twenty-two analytic tools show reported frequency of 10 or higher.  These business analytic software tools are listed in the table.  The results show that firms are using a diverse set of business analytics tools.\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Table 2-3: Cross-tabulation of Business Analytics Tools with Task Orientation & Firm Size") {
                            self.showingTable23Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable23Sheet1) {
                            Table23View1()
                        }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Variety of Procedures and Technique")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("There exists a wide variety of data mining and analysis procedures and techniques.  The decision to select which type of data mining and analysis procedures and techniques depends on the nature of the problem, nature of data, type of variables, and level of analytical sophistication.  Various techniques are utilized to analyze big data.  These techniques are commonly applied to both structured and unstructured big data.  The most commonly adopted data mining techniques by firms include clustering, association rule, classification, regression, machine learning, and statistical methods.  These techniques are used to visualize, describe, and predict customer and market behaviors.  The other technique is web mining.  Web mining techniques perform web content mining and web structure mining.  Web content mining assess contents of web and social media sites by analyzing audio, video, text, and images posted by firms and users of those sites.  The web contents are characterized by heterogeneity and lack of structure.  Web structure mining evaluates the node and connection structure of website through graph theory.  In web structure mining, patterns are extracted from hyperlinks within a website and a tree-like structure is analyzed to describe HTML or XML tags.  With social media sites, social network analysis is performed to assess the engage patterns and interactions among users of various social media sites.  Visualization techniques are used to visualize big data for easy and quick evaluation and interpretation of meaning and pattern of data.  Machine learning and artificial intelligence techniques are utilized to generate trends and patterns from big data.  Supervised and unsupervised machine learning and neural network analysis are performed on big data.  Optimization methods are applied to big data to understand and generate optimal solutions.\n").padding(10)
                    } // Section
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3. Analytics Tools and Software", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 2-3 VIEW
// ------------------------------
struct Table23View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 2-3: Cross-tabulation of Business Analytics Tools with Task Orientation & Firm Size")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Table-2-3")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 2-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
