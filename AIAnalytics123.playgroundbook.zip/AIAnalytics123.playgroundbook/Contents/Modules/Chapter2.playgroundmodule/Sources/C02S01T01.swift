//
//  C02S01T01.swift
//  Chapter 02 Section 01: Topic 01: Business Analytics Tasks
//
//  Created by SBAMBP on 4/03/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C02S01T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable21Sheet1 = false
    @State private var showingTable22Sheet1 = false
    @State private var showingFigure21Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Adoption Models")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The conceptual framework presented in Figure 2 1 involves the use of big data to perform business analytics tasks using business analytics tools and technology.  There are a variety of business analytic adoption models proposed for integrating business analytics into the firm’s problem-solving / decision-making processes.  For example, these models could include the “Healthcare Analytic Adoption Model,” the PAIR model, the simplified taxonomy of big data analytics, and/or the SPED model.  The SPED (Sensing, Predictions, Evaluation, Decisions) model acknowledges the movement and use of insights from one task orientation level to the next and focuses on what is provided by the analyst’s effort at insight generation at that particular task orientation level.  In performing business analytics, firms can apply and use the four different task orientations that include situation sensing, making predictions, making evaluations, and making decisions.  While firms can utilize any permutation of these task orientations separately or in combination, it is expected that the firm will primarily focus on a certain task orientation while performing business analytics tasks.  The chosen business analytics task orientation is influenced by a firm’s big data and analytic capability.  In addition, the primary business analytics task orientation utilized by the firm will have an impact on the specific business analytics tools utilized by the firm.\n").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 2-1: Conceptual Framework of Big Data Analytics") {
                        self.showingFigure21Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure21Sheet1) {
                        Figure21View1()
                    }
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Directions of Thought")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        Text("Business analytics tasks performed by firms may have different task orientations or directions of thought to generate insights or solve problems.  The particular task orientation focuses on the analytics in terms of what is to be accomplished by the business analytics effort.  To further understand business analytics task orientation, various taxonomies have been proposed and developed.\n").padding(10)
                            // ----------------------
                            Button("Click to highlight ... Table 2-1: Cluster Analysis Results") {
                                self.showingTable21Sheet1.toggle()
                            }
                            .sheet(isPresented: $showingTable21Sheet1) {
                                Table21View1()
                            }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("SPED Model")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("One example of a task orientation taxonomy includes various orientations labeled visualization, exploration, explanatory, and predictive.  The chosen task orientation taxonomy, the SPED model, is used in performing business analytics tasks where the firm can take one of four discrete orientations includes situation sensing, making predictions, making evaluations, and making decisions.  While firms can take any combination of these orientations, it is expected that they will primarily focus on a certain orientation while performing business analytics tasks.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Word Concept Terms")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        Text("As seen in Table 2 1, various word concepts were captured from firm job ads for data analytic personnel.  Using the SPED taxonomy of business analytics task orientation, text-mining and cluster analyses were utilized to validate the four types of business analytics task orientations firms were focused on.  As this particular study identified four types of business analytics orientation tasks, the k-means clustering procedure was chosen for analysis.  Table 2 1 shows the k-means clustering output of the four predicted clusters.  The clustering analysis generated four unique clusters.  In generating the four clusters, a total of 27 relevant word concept terms were used.  These 27 word concept terms are related to the four business analytics task orientations.  In Table 2 1, the 27 word concept terms grouped by the four resulting cluster are listed and their centroids for each of the four business analytics task orientation clusters are identified.  To characterize the resulting clusters, the cluster centroids were examined.  Examining the centroids allows interpretation of what each cluster grouping represents.  The largest centroid of each term concept that is equal to or greater than .20 are highlighted by bold type in Table 2 1.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Clusters")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        Text("Cluster 1 represents the decision orientation cluster with 39 firms.  The word concept term list showing values greater than or equal to .20 for cluster 1 are the following nineteen terms: decide, effect, improve, insight, revenue, communicate, translate, monitor, action, analyze, strategy, solution, analytics, problem, report, inform, visualize, understand, and define.  This cluster shows large centroid values for concepts relevant for the decision task orientation as well as the prediction, evaluation, and sensing task orientations.  This suggests that decision orientation task is a more advanced and sophisticated task orientation driven by the combination of all four task orientations.  Cluster 2 contains 99 firms representing the prediction task orientation cluster.  The word concept term list showing values greater than or equal to .20 for cluster 2 are the following fourteen term concepts: predict solution, performance, analytics, problem, decide, insight, improve, action, analyze, strategy, report, inform, and understand.  These concepts are relevant primarily for the prediction task orientation with some decision and evaluation task orientations.  Cluster 3 contains 58 firms and refers to the evaluation orientation cluster.  The word concept term list showing values greater than or equal to .20 for cluster 3 are the following ten term concepts: intelligence, determine, report, inform, visualize, decide, analyze, solution, performance, and analytics.  These concepts are primarily related to the evaluation task orientation with some decision task and evaluation task orientations.  Cluster 4 represents the situation sensing task orientation cluster and contains 291 firms.  The word concept term list showing values greater than or equal to .20 for this cluster include the following eight terms: understand, improve, insight, analyze, strategy, performance, report, and analytics.  These concepts are related to sensing task orientation along with the other three task orientations in a very superficial way.  This cluster is characterized by relatively small centroid values for most of the term concepts.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Results")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        Text("These results show that the largest number of firms (about 60 percent) are classified into the situation sensing task orientation in business analytics.  Approximately 20 percent of firms focus on the prediction orientation task in business analytics.  The remaining 20 percent of firms are taking either the decision or evaluation task orientation in business analytics.  This study evaluated the relationship between business analytics task orientation and firm characteristics.  Chi-square statistics for cross-tabulations were used to test these relationships.  Table 2 2 shows the cross-tabulation analysis results.\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Table 2-2: Cross-tabulation of Business Analytics Task Orientation with Firm Size and Industry Type") {
                            self.showingTable22Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable22Sheet1) {
                            Table22View1()
                        }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Industry Type")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The adoption of business analytics task orientation is related to an industry type.  The consumer product, industrial product, and financial services firms tend to belong to cluster 2 and cluster 4 which focuses on the make prediction and situation sensing business analytics orientation tasks.  Retail firms and healthcare service firms tend to focus on the situation sensing business analytics orientation task.\n").padding(10)
                    } // Section
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1. Business Analytics Tasks", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 2-1 VIEW
// ------------------------------
struct Table21View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 2-1: Cluster Analysis Results")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Table-2-1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 2-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 2-2 VIEW
// ------------------------------
struct Table22View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 2-2: Cross-tabulation of Business Analytics Task Orientation with Firm Size and Industry Type")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Table-2-2")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 2-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 2-1 VIEW
// ------------------------------
struct Figure21View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 2-1: Conceptual Framework of Big Data Analytics")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-2-1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 2-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
