//
//  C02S04T01.swift
//  Chapter 02 Section 04: Topic 01: Insight Generation
//
//  Created by SBAMBP on 4/03/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C02S04T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure22Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Insights")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Business analytics should lead to the generation of valuable insights.  Business analytics allow managers to discover patterns in data and understand why issues and problems occurred.  Insight generation is the ultimate goal of big data business analytics.  Insights can be generated from the big data and business analytics to solve business problems, make decisions, and take the appropriate actions, thus creating intangible and tangible business value.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Reassess Problem")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        Text("After obtaining analytic results and reports, managers should generate insights.  With the insights generated, managers may need to reassess the problem and may want to generate additional analytical solutions to gain further insights and greater understanding.  These insights would lead to valuable strategic and tactical directions for the firm.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Knowledge")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                                {
                                // ----------------------
                        Text("The utilization of the generated analytics can lead to further insights and knowledge.  Whereas “information” is understood as “purposeful and relevant data”, “insight” and “knowledge” exist within individuals as a function of their values, framed experience, contextual information, and expert insight.  Famed systems theorist, Charles West Churchman, made this point many years ago, when he stated that to conceive of knowledge as a collection of information seems to rob the concept of all of its life.  Knowledge resides in the individual and not in the collection of knowledge.  It is how the individual reacts to a collection of information that matters.  Thus, “knowledge” can be seen as information that matters to individuals, given their values, frame of reference, experiences, context, and expertise.\n").padding(10)
                            } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Interpretation")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                                {
                                // ----------------------
                        Text("When information is interpreted by an individual, who assimilates that information using his or her current knowledge, emotions, and values, then new knowledge results.  This is not to say that in a firm, knowledge exists only in its individuals.  Firm knowledge can exist in the managers in different forms ranging from “tacit” and difficult to control and communicate, to “explicit / codified” and easy to control and communicate.\n").padding(10)
                            } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Tacit to Explicit")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                                {
                                // ----------------------
                        Text("Explicit/codified knowledge is formal and systematic while tacit knowledge is highly personal and rooted in action and in an individual’s commitment to a specific context or skill.  Tacit knowledge consists of mental models, beliefs, and perspectives so ingrained that it is taken for granted.  Indeed, it is in the process of moving from tacit knowledge to explicit knowledge that conscious and articulated understanding of something is accomplished.  One important requirement of managers in generating insights and creating knowledge is the ability to make sense out of the analytical solutions.\n").padding(10)
                            } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Starting Point")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Figure 2.2 illustrates the factors and processes associated with generating insights.  The decision problem is the starting point of the process.  Considering the available metrics and analytical tools, managers select the appropriate analytic solutions that are consistent to their existing knowledge base.  These analytic solutions are generated by applying various modules of analytical tools to the problem at hand.  The analytical solutions are typically in the form of charts, graphs, tables, and statistical values.  They are interpreted to gain insights.\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 2-2: Insight Generation Processes and Factors") {
                            self.showingFigure22Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure22Sheet1) {
                            Figure22View1()
                        }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Mental Models")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The ability to sense is related to the mental models of the managers interpreting the analytic solutions.  The mental models of the managers contain decision rules for filtering data and information and useful heuristics for deciding how to act on the information in light of anticipated outcomes.  Managers are to assign meaning to the data uncovered and to translate it from data through information and, ultimately, to insights and intelligence that can be used by the firm for competitive advantage.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Banding")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The analytic reports and modules generated by managers have to be linked to either the current user interface or linked to a new interface for easy access.  To enable easy and real-time access to analytic solutions, various techniques have been developed and used.  The assessment of the merit of the metric or key performance indicator can involve the use of ‘banding’.  Banding is a visual technique used to help represent the progress the firm is making in the achievement toward the desired objective.  When applying analytic solutions to decision-making, the analytics are given meaning and provide actionable insights.  When firms have the analytics solutions with meaning and placed them in context, competitive advantage can be achieved.  The real value of big data and business analytics is providing managers with rich insights.  The insights can be used by managers to take immediate action that an improve the firm’s performance.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Insight-driven Critical Thinking")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Managers need to progress from the traditional critical thinking responses of observations and identification of the various components of the analytic problem to insight-driven critical thinking based upon analysis and integrated lines of questioning.  Managers continue to verify and expand the analytic problem, and then, move to develop potential analytic solutions.  These analytic solutions are the result of the insights that are generated.  Managers narrow the various insights and translate those solutions into a comprehensive, thorough management solution.  This insight generation process highlights the importance of business analytics application to decision areas by managers.  The ultimate goal is to create insight-driven decision-making by moving from traditional critical thinking to insight-driven critical thinking and data-driven decision-making.  The emerging role of business analytics in firms is to find the “structure within the data.”  Creating easy-to-use and powerful insight generation tools must be coupled with the development and education of the managers who ultimately can position the business analytics to generate insights using proven business models and to develop critical lines of questioning that result in competitive advantage for the firm.\n").padding(10)
                        } // Section
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4. Insights and Intelligence", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 2-2 VIEW
// ------------------------------
struct Figure22View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 2 2: Insight Generation Processes and Factors")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-2-2")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 2-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
