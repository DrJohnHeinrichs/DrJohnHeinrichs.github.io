//
//  C02S02T01.swift
//  Chapter 02 Section 02: Topic 01: Nature and Properties of Big Data
//
//  Created by SBAMBP on 4/03/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C02S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Big Data: Dimension - Volume")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Big data is identified by four primary dimensions that include volume, variety, velocity, and veracity.  Some additional dimensions are also added to the four primary dimensions.  The dimension labeled volume refers to the amount of data available for analysis which has been growing enormously.  Firms need to process massive amounts of data generated from both internal and external data sources.  With the large and complex datasets, it is increasingly difficult to identify relevant information and generate meaningful insights from the data.  The large volume of data also creates challenges to managers regarding how to acquire, store, organize, verify, and analyze the data.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Big Data: Dimension - Variety/Velocity/Veracity")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                        Text("The dimension labeled variety refers to the many different types of data.  With the development of information technology tools and expansion of electronic commerce, firms are accumulating and gaining access to many different types of data especially unstructured data.  These new types of data include transactions, log data, social media, sensors, RFID scans, text, audio, images, and video.  The dimension labeled velocity is defined as the rate at which data are generated as well as the speed at which the collected data need to be analyzed and acted upon.  Managers need to understand which type of data require their attention in a quick and timely manner.  Velocity requires firms to parse data in real-time and identify a trend or opportunity quickly so that marketing managers can respond to markets and competitors’ actions.  The dimension of veracity refers to data uncertainty.  Data uncertainty is caused by biases, noise, and abnormality in the data as a result of data inconsistency, incompleteness, ambiguity, deception, and model approximation.  Other additional dimensions defining big data are variability and volatility.  The variability dimension is related to the changes over time and different contexts.  The dimension of volatility is defined as the length of retention required for future useful usage.  \n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Structured / Unstructured")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                        Text("While big data can be characterized by these various dimensions, they are fundamentally classified into either structured or unstructured data for the purpose of business analytics application.  Structured and unstructured data can be understood in the perspective of a database.  Structured data is any data that can be placed in databases and logically filed, accessed, referenced, used, and analyzed with statistical tools.  Unstructured data is any data or information that is either digital or non-digital and cannot be put into a database or has no predefined structure.  The most common unstructured data such as texts and videos cannot be placed in a logically searchable structured database that can be usefully retrieved by logical models or sorting process.  Big data includes such unstructured data with increasing proportion of those types of data.  Big data analytics covers the process and techniques of extracting valuable insights and intelligence from both structured and unstructured data.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Big Data Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                        Text("Big data analytics utilize various types of data to support the marketing decision-making process.  Big data can take many different forms and exists in the following types.  One type of data that has been utilized by firms in the past is transaction or operation data.  This type of data contain the majority of structural data that firms have been analyzing with statistical software.  Another type of data are data derived from digital media that includes social media data, click stream files, system log files, internet data, and streaming data.  Another type of data include text, XML, image, audio, video, rich media, and graphs that constitutes the unstructured data firms have been generating and accumulating in their big data storage.  Yet another type are data generated from Internet of Things (IoT) and other technology equipment and tools.  This type includes sensor data, mobile/GPS data, satellite data, and geospatial data.  These new types of data provide firms significant opportunities and challenges in generating insights and intelligence from the new type of big data for marketing decision-making.  Thus, marketing analytics is emerging as one of the most critical competences firms must have to remain competitive in global markets.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Marketing Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Marketing analytics, the application of big data to marketing problems and decision-making, has a significant impact on the way firms plan and implement marketing strategy and tactics.  For example, marketing analytics can be used to identify customers who are more likely to respond positively to marketing and promotion campaigns.  Marketing analytics can help firms develop dashboard and interactive reports providing trends and relevant KPI information and customer feedback about brands and products.  The impacts of marketing analytics using big data are many folds.  Marketing analytics provides opportunities for firms in creating new businesses, developing new products and services, and improve marketing operations.  Marketing analytics allow firms to develop and implement personalized marketing.  Marketing managers can deliver personalized product and service recommendations, coupons, and other promotional offers by analyzing customers’ preferences and sentiments.  Firms can improve shopping experiences and increase revenue and customer retention through the integration of data from online and offline sources.  Marketing analytics can help the firm price appropriately and increase revenue.  Firms can provide customized coupons, adjust product availability, and optimize price based on insights generated.  Marketing analytics can help marketing managers understand the context of customer problems holistically and provide solutions to customer problems.  Marketing analytics can reduce marketing costs by making marketing operation more efficient and effective and can provide better demand forecasts, real-time tracking and optimized distribution network management.\n").padding(10)
                    } // Section
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("2. Nature and Properties of Big Data", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
