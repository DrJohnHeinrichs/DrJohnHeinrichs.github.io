//
//  C02S04T02.swift
//  Chapter 02 Section 04: Topic 02: Quality of Generated Insights
//
//  Created by SBAMBP on 4/03/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C02S04T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Actionable Insights")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Firms need to generate and use actionable insights for successful business outcomes.  Data, information, and insights are not the same.  To become data-driven, firms must generate insights that are valuable and actionable from business analytics solutions.  Data is the raw and unprocessed facts in the form of structured and unstructured types.  Information is the results of processing, aggregating, and organizing data delivered in the form of data visualization, reports, analytical outputs, and dashboards.  Insights can be defined as a new way of viewing the world that causes us to reexamine existing conventions and challenge the status quo.  Insights therefore can result in discovering underlying motivations and allow managers look at decision problems from a fresh perspective.  Turning information into insights requires creativity, persistence and deep thinking along with rigorous analysis translating large amounts of data into concise and compelling findings.  Insights allow managers to see the decision problem in a new way or in a bigger coherent context, connect the problem to another relevant problem and related solution, and remove the biases or thoughts inhibiting insight generation.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Marketing Insights")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        Text("Insights that can influence decisions and drive change can be discovered by analyzing information and drawing conclusions.  Managers can identify a potential insight that can be valuable and actionable.  Managers need to ask the following questions for recognizing marketing insights.  These questions focus on whether 1) the insight reveals something about the consumer, 2) the insight captures how consumers want to feel, 3) the insight relates to the drivers of the category, 4) the insight speaks to an enduring value and not just what is new, and 5) the insight challenges the firm or brand to act in new ways rather than just maintain the status quo.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Value of Insights")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                                {
                            // ----------------------
                        Text("While many insights can be generated from big data, not all insights are valuable and actionable.  The value of insights can be determined if that insight can drive actions, makes managers rethink the course of action, and leads to a new direction.  Managers need to understand the attributes of valuable and actionable insights.  An insight that is closely linked to the firm’s goals, strategic initiatives, and key performance indicators, is more likely to drive action and can be converted to strategic and tactical responses.  An insight must be identified with accompanying context.  An insight with supporting details and background results in action and not objections.  Managers can truly appreciate the value of insights when they understand why that particular insight is important and unique.  The insight must be considered relevant by marketing managers.  The relevant insight is an insight that is delivered to the right managers at the right time in the right setting.  For an insight to be actionable, the insight must be specific and complete.  An insight that lacks sufficient details can show interesting anomalies but may not lead to immediate action.  An insight needs to adequately explain why something occurred to become actionable.  An insight that is unique will be more likely to attract managers’ attention leading to action.  Thus, for an insight to be actionable, it must be easily understood and correctly interpreted.\n").padding(10)
                            } // Section
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4. Insights and Intelligence", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
