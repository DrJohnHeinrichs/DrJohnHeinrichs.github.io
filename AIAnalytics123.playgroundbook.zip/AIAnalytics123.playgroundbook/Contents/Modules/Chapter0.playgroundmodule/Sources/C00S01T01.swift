//
//  C00S01T01.swift
//  Book_Sources
//  Chapter 00: Preface
//
//  Created by SBAMBP on 05/18/2020.
//
import SwiftUI

public struct C00S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ----------------------
        // SECTION 1: Start
        // ----------------------
        NavigationView {
            List {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "folder.circle")
                        Text("Preface")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("This book is written to provide the readers (marketing professionals) with a pathway to follow on their journey toward marketing analytics generation and application.  For the reader who has an uncertain understanding of the various tools and techniques used in the marketing analytics process, this pathway toward big data and artificial intelligence (AI) driven marketing analytics has various milestones to recognize and to follow.  As the reader progresses along their individual journey toward marketing analytics generation and application, the concepts of big data, AI application, machine learning algorithms, marketing analytics toolbox, marketing analytics tasks, marketing analytics generation, and marketing analytics interpretation and application will become illuminated.  \n\nThis book juxtaposes the various marketing decisions leading to marketing analytics task, big data, and marketing analytics toolbox for marketing professionals to obtain marketing analytics solutions. \n\nThis book enables the reader to clearly understand the big data and AI driven marketing analytics process and to get to know how to use both user-driven and AI driven analytic tools and techniques.  This book also provides practical knowledge of how marketing professionals can generate and apply user-generated marketing analytics to various marketing decision problems in analyzing big data.  This book also shows how AI driven marketing analytics can be generated and utilized by marketing professionals for marketing performance enhancement and better customer relationship management.\n\nModern marketing professionals need to attain data and analytics driven marketing competencies.  With this book, they will have the chance to deeply understand the detailed step-by-step process of generating, applying, and utilizing marketing analytics, as well as become more confident in making data and analytics driven marketing decisions.  \n\nYou will learn the marketing analytics steps in such extensive detail that you will be fully prepared to utilize big data and AI driven marketing analytics for daily marketing decision tasks.  This book provides an overarching guidance on how you can generate, interpret, and apply big data and AI driven marketing analytics to marketing decisions.  \n\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "tray.full")
                        Text("Three Main Parts")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("This book is organized into three main parts for practical application of marketing analytics.  The first part provides an introduction to business analytics, big data, and application of big data for marketing decision.  A novel big data and AI driven marketing analytics process model is presented and its step-by-step stages are described in detail.  This new marketing analytics process model forms the foundation of this book.  The second and third parts apply this novel marketing analytics model to various marketing decision tasks and areas.  The second part covers how big data and AI driven marketing analytics can be generated and applied to making market exploration, segmentation, and targeting, and forecasting decisions.  The third part focuses on how big data and AI driven marketing analytics can be generated and applied to tactical marketing decisions such as customer relationship management, product development, promotion optimization, customer post-purchase behavior management, and digital marketing decisions.\n\nThe marketing analytics process model takes three unique approaches for practical illustration of big data and AI driven marketing analytics.  \nFirst, this book focuses on the big data environment of marketing analytics.  In this book, the readers will learn the various sources of big data for marketing decision and what types of structured and unstructured data marketing professionals need to understand.\n\nSecond, this book presents various analytical tools and techniques in the analytic toolbox.  These analytic tools can be used by marketing professionals to generate user-driven marketing analytics.  The same tools can be utilized by AI algorithms and AI service firms to provide AI driven marketing analytics to marketing managers.  With the analytic toolbox approach, this book explains the concepts, analytic models, and analytic contexts for practical understanding of those tools and techniques application.\n\nThird, this book takes practical marketing decision application focus.  By linking the analytics solution to analytic tasks and analytic questions, this book provides marketing professionals with practical steps to follow in identifying big data sources, creating input data, generating appropriate analytics output, interpreting analytic solutions, and generating marketing insights for marketing decision making.  In addition, this book provides how AI driven analytics can be applied and utilized to improve marketing productivity and performance with AI use case examples.  \n\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "tray.full")
                        Text("Summary")
                            .font(.system(size: 24, weight: .heavy, design: .default))
                            } )
                        {
                    Text("This book maintains practical and application perspective. The analytic tools, examples and the models are described throughout the book to ensure that the concepts discussed can take the reader to a position of being able to apply the presented tools and techniques to gain insights regardless of the specific software used by the firm.  This book utilizes various statistical techniques, several programming languages, and databases in the examples and discussions.  The intention of the book, however, is not to teach the reader to run these techniques using certain specific software, but rather to provide examples of these tools in action as the marketing professionals generate insights for the firm.  In addition, this book provides a series of AI driven application cases from a variety of industries to emphasize various concepts and learning points presented in each chapter.\n\nThis book will walk through the fundamental concepts, analytic tools and techniques for marketing analytics, and how to generate, interpret, and apply marketing analytics to marketing decisions.  You will gain in-depth understanding of how AI powered analytics and machine learning algorithms can improve, extend, and enhance marketing actions.  This book is filled with real-life AI marketing application examples to help you understand how AI driven marketing analytics and algorithms can change the marketing landscape.  This book is designed for marketing professionals with all the guidance to understand, develop, interpret, and apply marketing analytics for marketing decisions.  You will learn how to gain valuable insights from marketing analytics solutions and make analytics-based marketing decisions.  \n\n")
                        .font(.system(size: 18))
                    }
                    // ----------------------
                } // Section 1
                    .padding(.bottom, 30)
            } // List -- text
                .padding(30)
            .font(.system(size: 22))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("Preface", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // SECTION 1: End
        // ----------------------
    } // body
} // struct
