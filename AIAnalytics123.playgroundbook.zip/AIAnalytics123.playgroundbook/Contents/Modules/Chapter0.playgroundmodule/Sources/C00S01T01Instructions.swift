//
//  C00S01T01Instructions.swift
//  Book_Sources
//  Preface
//
//  Created by SBAMBP on 05/18/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C00S01T01Instructions: View {
    @State private var isShowingRed = false
    @State private var animationAmountSpin = 0.0

    public init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 30)!]
    } // init

    public var body: some View {
        VStack {
            Button(action: {self.isShowingRed.toggle()}){
                Text(self.isShowingRed ? " " : "Click to open ... \n\nInteractive Playground Instructions")
                .font(.largeTitle)
                .fontWeight(.semibold)
            //    .font(.system(size: 20, weight: .heavy, design: .default))
                .foregroundColor(.black)
            } // Button
                .padding(10)

               // .background(.blue)
                //                .background(isShowingRed ? Color(UIColor(red: 1.0000, green: 0.0000, blue: 0.0000, alpha: 1.0)) : Color(UIColor(red: 0.0000, green: 0.0000, blue: 1.0000, alpha: 1.0)))
//                .foregroundColor(Color.white)
//                .clipShape(RoundedRectangle(cornerRadius: 15))
                
            if isShowingRed {
                VStack {
                    Text("Interactive Playground Instructions")
                        .font(.largeTitle)
                    Text("Use this Interactive Playground to explore the preface and how the book is organization.\n\n The book focuses on three unique approaches for practical illustration of analytics\n\n1. What is the big data environment of marketing analytics?\n2. What are the various analytical tools and techniques in the analytic toolbox?\n3. What is a practical marketing decision application focus?\n\nThis book provides  professionals with practical steps to follow in identifying big data sources, creating input data, generating appropriate analytics output, interpreting analytic solutions, and generating insights for decision making.")
                        .font(.body)
                    HStack{
                        
                        Text("Now, click ... ")
                        Image(systemName: "arrowtriangle.right.fill")
                        Text("  Run My Code")
                        .font(.headline)
                    }
                } // VStack
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .center)
//                    .background(Color.white)
            } // if

        } // VStack
    } // body
} // struct
// ---------------------
// ---------------------
