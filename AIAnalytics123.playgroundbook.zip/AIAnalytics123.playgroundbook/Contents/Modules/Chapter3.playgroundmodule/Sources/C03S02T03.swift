//
//  C03S02T03.swift
//  Chapter 03 Section 02: Topic 03: Analytic Question Framing and Type of Analytics Selection
//
//  Created by SBAMBP on 4/4/20.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S02T03: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Three Step Model")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Once we know what type and nature of solutions desired, then we can move to the third step of analytic question framing.  For the right solution, managers need to come up with right questions to ask.  Marketing manager must convert the desired solution of the decision problem to appropriate analytic questions.  These questions should provide explicit specification of objectives in performing the analytic task.  For example, the questions such as “What are typical profiles of our most valued customers?” or “What type of products should our firm try to cross-sell or up-sell our potential customers?” or “What are the sales trends of our key brands?” are needed to successfully perform the next steps of the analytic process.  Once marketing managers have a clear understanding of the problem situation and the desired outcome of using analytics in solving the problems, they can clearly specify the right analytic questions.  Marketing managers can develop right analytic questions and determine what questions to ask by considering the linkages among decision problems, analytics objectives, and desired analytic solution leading to analytic questions.  The focus must be developing a series of analytical questions that should be answered from the analytics process.  For example, a major package goods firm introduced a new “ice cream” product about a year ago.  The new product is a line extension offering a distinctive new ingredient that should be attractive to younger market segments.  Brand managers want to evaluate the success of the new product based on the sales data.  The objective of this analytics process is to determine the degree of market success of a new ice cream product containing a new flavor and its relation to existing products.  The analytic questions then include: 1) What volume and market share the new product achieved in the past year? 2) What trial rates are achieved? 3) Are there any cannibalization effects of this new product on existing products in our line? 4) Which existing products does the new product draw its share from? 5) Which market segments of consumers are trying the new product? 6) Which market segments of consumers are attracted to the new ingredient? and 7) Are we achieving a higher market share and sales of the new product from the originally targeted younger generations?  Brand managers can generate numerous analytical questions that are relevant to answer the managerial problem at hand.  The generated analytic questions are then evaluated in terms of the firm’s analytics knowledge source.  The analytics knowledge source is comprised of internal and external data and the analytics model.  The data source consists of databases, data warehouses, and data marts stored in the firm’s big data.  The firm’s big data contains data content and meta-data for various metrics the firm is maintaining and updating.  Marketing managers can use the various questions and categories in analytics question framing.  These analytic questions can be generic, industry specific, company specific, or manager specific questions.  \n").padding(10)
                        }
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3. Analytic Question Framing and Type of Analytics Selection", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
