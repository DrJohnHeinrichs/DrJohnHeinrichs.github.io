//
//  C03S03T02.swift
//  Book_Sources
//
//  Chapter 03 Section 03: Topic 02 Input Data Identification and Pre-processing
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S03T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Step 5")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Step 5 involves input data identification and pre-processing for the analytic tool selected in step 4.  As each analytic tool requires a different data format, managers must identify the available data and evaluate whether the data is in the appropriated usable format and quality.  If data is not readily usable, managers need to perform data pre-processing to make them usable for the selected analytics tool.  In many cases, data pre-processing is needed as the available data in a firm’s database or in a public domain is generally incomplete with missing values, or variables are inaccurate or inconsistent.  Therefore, before managers move to next step, they must prepare the data by performing data selection and integration, and cleaning its correct missing values, noise, and inconsistencies.  They also need to transform the data to meet the data input requirements of the selected analytic tools.  These include data normalization, data conversion, and new calculated variables.  They also need to perform data reduction to reduce number of variables case and skewness of data.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("M")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("This step involves understanding data.  Different analytic questions require different sets of data.  The relevant dataset can be developed from many available databases.  Marketing managers should consider the analytic questions generated in step 3 and identify the appropriate variables in the input dataset.  In determining the input dataset, marketing managers need to determine data availability, data source, and type of available data.  Managers need to have intimate understanding of various data availability and where the relevant data are stored in what form.  Data can be available in many different forms and are retrieved either manually or electronically.  Data sources are either internal or external and contain various types of data.  As data can exist in many different forms and types, data can be categorized into structured and unstructured data.  Structured data are traditional data that can be quantitative and qualitative.  Quantitative data can be interval or ratio data that can be discrete or continuous.  Qualitative data can be ordinal or nominal data that has finite ordered values of finite non-ordered values.  Unstructured data can take forms such as online click stream, audio, or video.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("M")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Different from traditional data, big data contains data from many different sources.  For example, online click-stream data, text, image, audio, video, or web and social media sites are unstructured data created recently but important data for business analytics.  Unstructured data becomes increasingly important input for analytic tools.  In pre-processing of these unstructured data, managers need to determine how to convert the unstructured data into some form of structured or quantitative data for analytics generation.  For example, text from blog posts, Twitter tweets, and consumer product evaluation, need to be converted into usable quantitative data using text analysis or sentiment analysis.\n").padding(10)
                    } // Section
                    // ----------------------
                    .padding(10)
                // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3. Marketing Analytics Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------

