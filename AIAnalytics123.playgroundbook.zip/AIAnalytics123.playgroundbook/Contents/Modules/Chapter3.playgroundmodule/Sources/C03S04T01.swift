//
//  C03S04T01.swift
//  Book_Sources
//
//  Chapter 03 Section 04: Topic 01: Analytics Insight Generation
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S04T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure34Sheet1 = false
    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Model Steps 8 & 9")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("After generating numerous analytic tables and charts, managers need to utilize these analytic outputs for insight generation and decision-making.  Figure 3 4 shows the final stage that includes two steps in the marketing analytics stage model.\n").padding(10)
                    // ----------------------
                    } // Section
                    // ----------------------
                    Section (header: Text("Figure 3-4: Marketing Analytics Interpretation and Application Steps"))
                        {
                        Image(uiImage: UIImage(named: "Figure-3-4")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Figure 3-4: Marketing Analytics Interpretation and Application Steps") {
                        self.showingFigure34Sheet1.toggle()
                    }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure34Sheet1) {
                        Figure34View1()
                    }
                    } // Section 3-4
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Step 8 requires interpretation of analytics output and generating meaningful insights.  The generated tables and charts need to be correctly evaluated and interpreted to understand the meaning of the results.  These results provide factual information derived from the dataset.  This factual information can be used to generate insights and intelligence in the given decision context.  After assessing the insights, manager may need to run additional follow-up analysis for additional analysis output.  These additional analytic outputs may provide more meaningful insights.  This iterative process needs to be repeated to obtain significant and meaningful insights and intelligence.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("After generating analytic results and reports, marketing managers should generate insights.  With the insights generated, marketing managers may need to reassess the problem and may want to generate additional analytical solutions to gain further insights and greater understanding.  These insights would lead to valuable strategic and tactical directions for the firm.  The utilization of this information generates further insights and knowledge.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("When information is interpreted by an individual, who assimilates it using his or her current knowledge, emotions, values and insights, new knowledge results.  This is not to say that a firm’s knowledge exists only in its people.  There are at least six domains where firm knowledge appears.  These domains include employees, machinery, plant and/or equipment, internal systems and processes, firm culture, and finally, products.  Furthermore, knowledge can exist within marketing managers in different forms ranging from “tacit” and difficult to control and communicate to “explicit/codified” and easy to control and communicate.  Explicit knowledge is formal and systematic while tacit knowledge is highly personal and rooted in action and in an individual’s commitment to a specific context or skill.  Tacit knowledge consists of mental models, beliefs, and perspectives so ingrained that it is taken for granted.  Indeed, it is in the process of moving from tacit knowledge to explicit knowledge that conscious and articulated understanding of something is accomplished.  \n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("One important requirement of marketing managers in generating insights and creating knowledge is the ability to make sense out of the analytical solutions.  As discussed earlier, the decision problem is the starting point of the process.  Considering the available metrics and analytical tools, marketing managers select the appropriate analytic solutions that are consistent to their existing knowledge base.  These analytic solutions are generated applying various modules of analytical tools to the problem at hand.  The analytical solutions are typically in the form of charts, graphs, tables, and statistical values.  They are interpreted to gain insights.\n").padding(10)
                    } // Section
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The ability to sense is related to the mental models of marketing managers interpreting the information.  The mental models of marketing managers contain decision rules for filtering data and information and useful heuristics for deciding how to act on the information in light of anticipated outcomes.  Marketing managers are to assign meaning to the data uncovered and to translate it from data through information and, ultimately, to knowledge that can be used by the firm for marketing decisions leading to competitive advantage.\n").padding(10)
                    } // Section
                    // ----------------------
                    .padding(10)
                // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4. Marketing Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 3-4 VIEW
// ------------------------------
struct Figure34View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 3-4: Marketing Analytics Interpretation and Application Steps")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-3-4")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 3-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
