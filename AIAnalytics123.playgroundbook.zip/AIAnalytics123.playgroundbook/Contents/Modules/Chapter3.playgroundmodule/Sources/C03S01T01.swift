//
//  C03S01T01.swift
//  Chapter 03 Section 01: Topic 01: Three Stage Model for Marketing Decision-Making
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S01T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure31Sheet1 = false
    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Three Step Model")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Marketing managers are required to use analytics for fact-based decision marketing.  The analytics are becoming increasingly critical for market success in the highly competitive marketing environment.  One important competence that marketing managers must have is the ability to effectively generate and utilize marketing analytics for marketing decision-making.  This chapter presents the three-step business analytics process model and provides detailed explanation of the processes.  Figure 3.1 shows the three-stage model of the marketing analytics for marketing decision-making process.\n").padding(10)
                        } // Sectioon
                        // ----------------------
                        // ----------------------
                    
                    
                    
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 3-1: Three Stage Model for the Marketing Decision-Making Process"))
                            {
                            Image(uiImage: UIImage(named: "Figure-3-1")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 3-1: Three Stage Model for the Marketing Decision-Making Process") {
                            self.showingFigure31Sheet1.toggle()
                        } // button
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure31Sheet1) {
                            Figure31View1()
                        } // sheet
                        } // Section
                        // ----------------------
                        // ----------------------
                    
                    
                        // ----------------------
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Analytic Task")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The stage model starts with defining the marketing analytics task.  Managers need to understand what type of analytic task they are confronting in the marketing decision situation.  Considering the defined task, marketing managers then need to generate the appropriated business analytics in the form of analytics output.  Finally, marketing managers should interpret the generated business analytics output, generate marketing insights, and apply those insights to marketing decisions they are facing and derive solutions or answers to complete the defined analytic task.\n").padding(10)
                        } // Section
                        // ----------------------
                        // ----------------------
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1. Three Stage Model for Marketing Decision-Making", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 3-1 VIEW
// ------------------------------
struct Figure31View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 3-1: Three Stage Model for the Marketing Decision-Making Process")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-3-1")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            } // Section
            // ----------------------
            Button("Finished: Figure 3-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
