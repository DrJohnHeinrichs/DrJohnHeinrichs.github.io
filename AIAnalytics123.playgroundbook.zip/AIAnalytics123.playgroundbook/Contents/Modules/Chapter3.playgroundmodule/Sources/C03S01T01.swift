//
//  C03S01T01.swift
//  Chapter 03 Section 01: Topic 01: Three Stage Model for Marketing Decision-Making
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S01T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure31Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Three Step Model")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Marketing managers are required to use analytics for fact-based decision marketing.  The analytics are becoming increasingly critical for market success in the highly competitive marketing environment.  One important competence that marketing managers must have is the ability to effectively generate and utilize marketing analytics for marketing decision-making.  This chapter presents the three-step business analytics process model and provides detailed explanation of the processes.  Figure 3.1 shows the three-stage model of the marketing analytics for marketing decision-making process.\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 3-1: Three Stage Model for the Marketing Decision-Making Process") {
                            self.showingFigure31Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure31Sheet1) {
                            Figure31View1()
                        }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Analytic Task")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The stage model starts with defining the marketing analytics task.  Managers need to understand what type of analytic task they are confronting in the marketing decision situation.  Considering the defined task, marketing managers then need to generate the appropriated business analytics in the form of analytics output.  Finally, marketing managers should interpret the generated business analytics output, generate marketing insights, and apply those insights to marketing decisions they are facing and derive solutions or answers to complete the defined analytic task.\n").padding(10)
                        } // Section
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1. Three Stage Model for Marketing Decision-Making", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 3-1 VIEW
// ------------------------------
struct Figure31View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 3-1: Three Stage Model for the Marketing Decision-Making Process")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-3-1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 3-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
