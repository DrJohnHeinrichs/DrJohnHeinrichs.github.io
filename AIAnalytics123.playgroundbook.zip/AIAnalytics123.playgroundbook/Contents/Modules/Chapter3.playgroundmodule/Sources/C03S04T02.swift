//
//  C03S04T02.swift
//  Book_Sources
//
//  Chapter 03 Section 04: Topic 02: Decision Application
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S04T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("M")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The final step, step 9, in the analytics process model is applying generated insights and intelligence to decision task.  Managers should assess the generated insights and evaluate the nature of insights whether they are expected or unexpected.  They also need to evaluate these insights that either confirm or contradict the managers’ intuition and experience as well as current business practices and knowledge base.  The generated new insights can be applied to decision task.  New solutions or directions can be identified leading to new marketing strategy or modification of existing strategy.  Managers can create analytics-driven written reports or make analytics centered presentations to communicate the changed marketing strategy.  This chapter presented the nine steps of business analytics process model.  Although the nine steps are presented sequentially, in reality, these steps can occur concurrently with several iterations to obtain the appropriate solution answers to the analytics task that marketing managers are confronting in real world situation.\n").padding(10)
                    } // Section
                    // ----------------------
                    .padding(10)
                // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4. Marketing Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
