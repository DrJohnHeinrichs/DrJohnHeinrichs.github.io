//
//  C03S02T02.swift
//  Book_Sources
//
//  Created by SBAMBP on 4/4/20.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S02T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Determine Solution")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Once managers know the decision problems, they need to determine the desired solution.  Considering the firm’s strategic position and current decision situation, marketing managers can identify the nature and type of solutions to be generated from the analytic process.  The solution must be realistic and practical for the firm.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Solutions")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The analytic problems faced by the marketing managers in the firm can potentially be solved by utilizing various solutions that are available in the firm.  If the solutions available are not sufficient to solve the problem, a new solution can and should be developed.  The solution can take many different forms.  The solution can be in the form of a simple association, a categorization, a predictive model, or even a sophisticated simulation model.  An analytical problem can then be solved by using numerous alternative analytical solution methods.  The selected solution can be influenced by the marketing manager’s analytical sophistication, the nature of the problem, the availability of various performance metrics, and the availability of analytical mining and intelligence management tools.  Regardless, the initial guide for creating and providing analytical solutions are dependent on which perspective or strategic focus a firm takes in making strategic and tactical decisions.  The selected solution should be able to provide a predictable link between the firm’s marketing strategic choice and outcome measurements and should help the firm to make sense of the dynamic and chaotic task environment in which it operates.  Perspective or strategic focus defines how a firm approaches problem-solving and developing analytic answers for managerial problems.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Good Solution")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("What constitutes good analytical solutions?  Good analytic solutions depend on the analytical problem being addressed by marketing managers.  For example, the top management in a large firm may desire analytical solutions that are strategic in nature.  The analytical solution offered to top management must be timely, relevant, and supportive of the firm’s strategic goals are used for creating or establishing the competitive advantage of the firm.  Analytic solutions contain associations, patterns, formulas, algorithms, and models that are the outcome of collection, extraction, identification, measurement, modification, and reporting of information designed to be useful to the analysts and marketing managers.  Analytic solutions include multi-dimensional databases, visualization, calculations, logic, formulas, analytical routines, algorithms, and models.  These solutions are generated from the big data available to the firm.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                    List{
                        NavigationLink(destination: NatureAnalyticSolutions()){
                            Text("Nature of Analytic Solutions").font(.system(size: 22)).fontWeight(.black).frame(maxWidth: .infinity, alignment: .center)
                        }
                        NavigationLink(destination: AnalyticsSolutionCategories()){
                            Text("Analytics Solution Categories").font(.system(size: 22)).fontWeight(.black).frame(maxWidth: .infinity, alignment: .center)
                        }
                        NavigationLink(destination: AnalyticsSolutionTypes()){
                            Text("Analytics Solution Types").font(.system(size: 22)).fontWeight(.black).frame(maxWidth: .infinity, alignment: .center)
                        }
                    } // List
                    // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("2. Marketing Analytic Task Definition", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: NATURE OF ANALYTIC SOLUTIONS
// ------------------------------
struct NatureAnalyticSolutions: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Managerial Problem Categories").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("In converting the analytic problem into analytic solutions, marketing managers must first evaluate what the nature of the involved analytic solutions is.  The nature of analytic solutions can be understood by assessing what degree of analytic sophistication the managerial problem requires.  It is important to understand the nature of the problem in a firm’s strategic sense.  The problem may involve assessing the past and current levels of the firm’s strategic and tactical decisions or its situational factors or environmental forces.  In other cases, the analytic problem requires assessing the four types of the firm’s performance metrics.  The second type of strategic problem would be evaluating the impact of the firm’s strategic and tactical decisions on the four performance metrics.  The third type of strategic problem would be assessing the direct impact of the firm’s situational factors as well as environmental forces on the performance metrics of the four balance scorecard perspectives.  The fourth type of strategic problem is assessing the moderating or mediating effect of the firm’s situational factors as well as environmental forces on the four types of the firm’s performance metrics.  Although there is little latitude regarding the objectives of deriving the analytic solution, marketing managers should examine the list of metrics and solution models identified.  The relevance of all of these metrics and solution models should be assessed.  In addition, marketing managers need to evaluate whether these are the only relevant variables and how these metrics affect the outcome of the decision.  Marketing managers can get useful directions for problem conversion by searching company records, secondary data, and analytic models.  Secondary information can provide viable alternatives regarding the approach to take in converting managerial problems to analytical problems.  In addition, similar problems in other business units or locations need to be evaluated for further information.  Any new metrics that are critical in solving the problem can be developed for either present or future usage.\n").padding(10)
            } // Section
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: ANALYTICS SOLUTION CATEGORIES
// ------------------------------
struct AnalyticsSolutionCategories: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Solution Categories").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The ever-growing sources of information and the availability of sophisticated data-mining tools make various analytical solutions available to almost all firms.  In the past, these sources and tools were beyond the reach of the most firms due to cost, analytical sophistication, technical, and information technology infrastructure requirements.  The analytic solutions can be classified into three major categories.  These categories are labeled strategic solutions, scanning / customer-related solutions, and tactical solutions.  Each of these categories can be further subdivided or classified as descriptive, predictive, or prescriptive in nature.  The next section describes the categories of analytics solutions.  \n").padding(10)
            } // Section
            // ----------------------
            List{
                NavigationLink(destination: StrategicSolution()){
                    Text("Strategic Analytic Solutions").fontWeight(.black).italic().frame(maxWidth: .infinity, alignment: .center)
                }
                NavigationLink(destination: ScanningSolution()){
                    Text("Scanning / Customer-Related Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center)
                }
                NavigationLink(destination: TacticalSolution()){
                    Text("Tactical Analytic Solutions").fontWeight(.black).italic().frame(maxWidth: .infinity, alignment: .center)
                }
            } // List
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: ANALYTICS SOLUTION TYPES
// ------------------------------
struct AnalyticsSolutionTypes: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Solution Types").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The previous solution categories of strategic solutions, scanning / customer-related solutions, and tactical solutions can be further classified.  Each of these categories can be explored or classified as descriptive, predictive, or prescriptive in nature.\n").padding(10)
            } // Section
            // ----------------------
            List{
                NavigationLink(destination: DescriptiveSolution()){
                    Text("Descriptive Analytic Solutions").fontWeight(.black).italic().frame(maxWidth: .infinity, alignment: .center)
                }
                NavigationLink(destination: PredictiveSolution()){
                    Text("Predictive Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center)
                }
                NavigationLink(destination: PrescriptiveSolution()){
                    Text("Prescriptive Analytic Solutions").fontWeight(.black).italic().frame(maxWidth: .infinity, alignment: .center)
                }
            } // List
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: STRATEGIC SOLUTIONS
// ------------------------------
struct StrategicSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Strategic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Taking.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: SCANNING / CUSTOMER-RELATED ANALYTIC SOLUTIONS
// ------------------------------
struct ScanningSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Scanning / Customer-Related Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Taking.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: TACTICAL SOLUTIONS
// ------------------------------
struct TacticalSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Tactical Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The tactical analytics solutions are used to solve a specific analytic problem at hand.  Managers are taking specific tactical solutions by implicitly or explicitly estimating the results of their tactical decisions.  These solutions provide analytical patterns and models that can help reduce uncertainty and error in their tactical decision-making.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: DESCRIPTIVE ANALYTIC SOLUTIONS
// ------------------------------
struct DescriptiveSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Descriptive Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Taking.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: PREDICTIVE ANALYTIC SOLUTIONS
// ------------------------------
struct PredictiveSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Predictive Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Taking.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: PRESCRRIPTIVE ANALYTIC SOLUTIONS
// ------------------------------
struct PrescriptiveSolution: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Prescriptive Analytic Solutions").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Thg.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
