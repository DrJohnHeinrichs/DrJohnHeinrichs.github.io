//
//  C03S03T01.swift
//  Book_Sources
//
//  Chapter 03 Section 03: Topic 01 Three Stage Model for Marketing Decision Making
//
//  Created by SBAMBP on 04/04/20.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S03T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure33Sheet1 = false
    @State private var showingTable31Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            List {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Second Stage")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The second stage for the Marketing Decision-Making Process involves developing the detailed process of generating analytic deliverables that can answer the analytic questions generated in the first stage.  Figure 3 3 provides the detailed steps of generating business analytics solutions in the form of analytic output.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        }
                        // ----------------------
                        // ----------------------
                            
                            
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 3-3: Marketing Analytics Solution Generation Steps"))
                            {
                            Image(uiImage: UIImage(named: "Figure-3-3")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 3-3: Marketing Analytics Solution Generation Steps") {
                            self.showingFigure33Sheet1.toggle()
                            } // Button
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingFigure33Sheet1) {
                                Figure33View1()
                            } // sheet
                        } // Section
                        // ----------------------
                        // ----------------------
                                
                                
                        // ----------------------
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("W")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Step 4 involves determining the applicable analytic tool.  In this step, marketing managers need to select the right analytic tool from the analytics toolbox.  They need to consider the tool’s functionality, assumptions, and data requirement in selecting the analytic tool for use.  The analytic toolbox shown in Table 3 1 describes various analytic tools that are typically available for marketing managers.  The analytic tools in Table 3 1 are classified by analytic goals, analytic types, and analytic technology.  Marketing managers will evaluate what type of analytic procedures is most appropriate to generate solutions for the analytic questions at hand.  In some cases, the analytic questions are such that application of simple descriptive statistics would be sufficient to answer the question.  In other cases, the analytic question may require extensive modeling using sophisticated statistical procedures.  In either situation, marketing managers are selecting the necessary analytics tool for the analytic questions.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                        // ----------------------
                      
                                
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("M")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Marketing managers need to understand whether the solution requires a simple display of metrics, a prediction of certain metrics, or some form of data-mining and/or statistical procedures.  If a simple display of metrics is required, visualization techniques can be applied for better presentation of the information and ease of insight.  However, if prediction of certain metrics is involved, various trend and time series analysis techniques can be applied.  If the problem requires some form of statistical procedures, marketing managers should assess which of the statistical and analytics procedures are appropriate.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                            }
                        // ----------------------
                        // ----------------------
                                
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 3-1: Analytics Toolbox"))
                            {
                            Image(uiImage: UIImage(named: "Table-3-1")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 3-1: Analytics Toolbox") {
                            self.showingTable31Sheet1.toggle()
                        } // Button
                            .font(.caption)
                            .foregroundColor(.blue)
                                .sheet(isPresented: $showingTable31Sheet1) {
                                    Table31View1()
                                } // sheet
                        } // Section
                        // ----------------------
                        // ----------------------
                                
                                
                    // ----------------------
                    // ----------------------
                    } // Section Main
                        .padding(.bottom, 20)
                        NavigationLink(destination: AnalyticsGoals()){
                            Text("Analytics Goals")
                            .foregroundColor(.blue)
                            .font(.system(size: 18, weight: .heavy, design: .default))
                            .padding(10)
                        } // navigation link
                        NavigationLink(destination: AnalyticsToolType()){
                            Text("Analytics Tool Type")
                            .foregroundColor(.blue)
                            .font(.system(size: 18, weight: .heavy, design: .default))
                            .padding(10)
                        } // navigation link
                        NavigationLink(destination: AnalyticsToolTechnology()){
                            Text("Analytics Tool Technology")
                            .foregroundColor(.blue)
                            .font(.system(size: 18, weight: .heavy, design: .default))
                            .padding(10)
                        } // navigation link
                    // ----------------------
            } // List -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3. Marketing Analytics Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// Table 3-1 VIEW
// ------------------------------
struct Table31View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 3-1: Analytics Toolbox")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-3-1")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 3-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// Figure 3-3 VIEW
// ------------------------------
struct Figure33View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure-3-3: Marketing Analytics Solution Generation Steps")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-3-3")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 3-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// TOPIC: ANALYTIC GOALS
// ------------------------------
struct AnalyticsGoals: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Goals").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Analytics goals describe what analytic techniques can do or achieve in analyzing a data set.  There are four different goals that analytic techniques aim and achieve in analyzing a set of data.  These include exploration, group difference, association and relationships, and classification and category prediction.  Exploration techniques aim to describe status, conditions or situation of people, events, or objectives in the data set.  Group difference evaluates where the differences exist between two groups among three or more groups.  These groups are naturally formed or classified intentionally for evaluation.  Assessing the significance of group differences evaluates the extent to which the metrics (dependent variables) vary as a function of determinant categorical metrics (independent variables).  The typical assessment process involves the use of t-test and ANOVA related procedures.  Association and relationship evaluate where the significant relationships exist between or among variables or objects in the data set.  Assessing the degree of relationships among variables involves using various association techniques such as correlation and regression techniques.  In this case, the analyst may determine that some metrics may act as independent and dependent variables.  Finally, classification and category prediction techniques can classify people, object, or events into different categories or groups for descriptive or prediction purposes.  Group membership prediction is performed to classify people or objects based on a set of independent metrics.\n").padding(10)
            } // Section
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: ANALYTICS TOOL TYPE
// ------------------------------
struct AnalyticsToolType: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Tool Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Analytic tool type describes the nature of the variables in the data set.  There are two types of analytic tools, dependence analytic tools and inter-dependence analytic tools.  When managers deal with analytic questions in step 3 that make distinctions between independent and dependent variables, dependence analytic tools should be used.  These tools identify a variable or a set of variables as dependent variable that can be explained or predicted by other variables designated as independent variables.  For example, a dependent variable such as “sales amount” can be explained by a number of independent variables such as “advertising budget”, “product quality”, “brand image”, and others using multiple regression analysis.  Dependence analytic tools are used when managers deal with analytic questions that do not distinguish between independent and dependent variables.  No one variable or a set of variables is explained or predicted by other variables.  Therefore, dependence analytic tools involve the simultaneous analysis of all variables in the dataset and attempt to uncover the underlying structure in the data set.  These tools assess variable inter-dependence or inter-object similarity.  Table 3 1 lists both dependence and inter-dependence analytic tools.  Managers can select one or a combination of tools listed in the toolbox to answer analytic questions.  In the dependence analytic tools, typical exploration tools include data visualization and reporting tools.  For group difference, mean difference techniques such as t-test, ANOVA, MANOVA and related techniques are used.  Discriminant analysis also belongs here.  Association and relationships tools are most commonly used in business analytics.  Those tools include correlation and regression-related techniques, time series and forecasting, conjoint analysis, and formula-equation modeling.  Classification and category prediction tools include K-nearest neighbor (KNN) method, Naïve Bayes, classification tree, and neural network.  Inter-dependence tools include factor analysis, text mining and sentiment analysis, network analysis and many others.  For association and relationship, association analysis and multi-dimensional scaling techniques can be used as in the dependence analytic tool.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: ANALYTICS TOOL TECHNOLOGY
// ------------------------------
struct AnalyticsToolTechnology: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        List {
            // ----------------------
            VStack{
            // ----------------------
            Text("Analytics Tool Technology").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Analytic tool technology refers to whether these analytic tools can be applied by individual managers or analysts in a firm or run by AI software that requires massive machine learning and computing capability.\n").fixedSize(horizontal: false, vertical: true).padding(10)
            } // Section
            } // VStack - inner
            // ----------------------
                NavigationLink(destination: UserDrivenAnalytics()){
                    Text("User Driven Analytics")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
                NavigationLink(destination: AIDrivenAnalytics()){
                    Text("AI Driven Analytics ")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
                NavigationLink(destination: MachineLearning()){
                    Text("Machine Learning")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
                NavigationLink(destination: AIDrivenAnalyticsOutcome()){
                    Text("AI Driven Analytics Outcome")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
              //  .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, height: 650, maxHeight: .infinity)
            // ----------------------
        } // List
    } // body
} // struct
// ------------------------------
// TOPIC: USER DRIVEN ANALYTICS
// ------------------------------
struct UserDrivenAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Tool Technology").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("User-Driven Analytics")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("User-driven analytic tools allow managers to easily find the data and produce analytic solutions using multiple software tools and data sources in the firm.  These tools allow managers to create various types of reports, advance analytics, and big-data applications supported by analysts.  In addition to the analytics generated within the firm, artificial intelligence (AI) analytics service firms can also provide comprehensive and big data driven analytics to marketing managers.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: AI-DRIVEN ANALYTICS
// ------------------------------
struct AIDrivenAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Tool Technology").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("AI-Driven Analytics")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("AI-driven analytics tools are provided by AI firms such as IBM Watson and Google analytics services.  For example, IBM Watson provides the ‘Knowledge Discovery’ service where Watson’s accelerated data optimization capabilities uncover hidden value in data by providing answers, monitoring trends, and identifying patterns in a large data set.  IBM ‘Watson Studio’ and ‘Watson Machine Learning’ can create, train, and deploy self-learning analytic models by preparing and analyzing a firm’s big data.  The AI generated results can complement the user-generated analytics to provide a more comprehensive understanding of market trends, customer reactions, market performance.  IBM Watson ‘Studio’ is a leading data science and machine learning platform that speeds up data exploration and model development.  It can scale data science operations and provide marketing managers AI powered predictive analytics, enhanced visual modeling, and automated deep learning.  These tools are offered by AI firms upon the request of managers.  These services use similar statistical techniques and tools and provide analytic outputs requested by managers using AI and machine learning capabilities with significant computing power.  In this case, managers need to consider the analytic questions on hand in using the AI driven analytic service tools.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: MACHINE LEARNING
// ------------------------------
struct MachineLearning: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Tool Technology").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Machine Learning")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("AI powered analytics algorithm is built on machine learning capabilities.  AI utilizes three types of machine learning that include classic machine learning, generic representation learning, and deep learning.  Classic machine learning takes in input, use manually created features from the input, and perform mapping from features to generate output.  On the contrary, generic representation learning generates auto-created features instead of manually created features from input and then perform mapping from the auto-created features to generate output, deep learning generates simple features from input, generate more advanced features from simple features, and then perform mapping from advanced features to generate output.  Deep learning delivers system or algorithm that can think, keep learning, and update the solution based on new data through continuous learning.  These machine learning methods can be used by marketing managers for making predictions, recognize patterns, and support decision making.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("M")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("AI-driven marketing leverages machine learning, AI powered algorithms, and big data analytics to improve customer experience and improve return on investment (ROI) of marketing activities.  The customer insights gained from big data and AI-driven analytics can help marketing managers create more effective customer touchpoints and engage with customers better.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("M")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Two important paradigms in machine learning are undirected (unsupervised) and directed (supervised) learning.  Undirected AI learning uncovers hidden insights in big data by perceiving the data in different ways and finding structures and patterns.  In undirected modeling, there is no pre-determined mapping from some input to some output.  Undirected machine learning focuses on finding structures in data without any specific end use-cases in mind.  The structures in data are represented by repeated patterns, sequential patterns, or co-occurrence patterns.  In all these patterns, marketing managers can learn the existence of data patterns for no specific purpose in mind.  Marketing managers can use the undirected learning to improve understanding of the data and derive actionable insights.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("M")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Undirected learning is identified as one of the most important frameworks in machine learning that focuses on observing the data systematically and holistically, discovering the underlying processes or mechanisms, and revealing insights that we didn’t know existed in the data.  On the other hand, directed learning is driven by preconceived or pre-determined patterns that marketing managers are interested in.  Directed learning tries to deliberately map between one set of inputs and an output.  AI powered learning algorithms allow marketing managers to learn a mapping from an observation to prediction and decision.  Many decision systems utilize the AI powered directed learning model.  Directed learning is the art of similarity learning and maximizes the ability to focus on the particular aspects and ignore noises in the training model derived from the firm’s existing data set from big data.  The directed learning model trains the AI powered algorithm to identify similar objects and discriminate different objects using the empirical model derived from the firm’s existing data.  Depending on the nature of the input and output in the algorithm, marketing managers can gain various insights.  Inputs are a set of features and outputs are a class label, a real value, a list of items, or a set of effects.  Directed machine learning can map cause-and-effect relationships or prediction relationships.  \n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------
// TOPIC: AI-DRIVEN ANALYTICS OUTCOME
// ------------------------------
struct AIDrivenAnalyticsOutcome: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Analytics Tool Technology").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The goal of AI is to create intelligent machines that can perform reasoning, thinking, learning, and problem solving originally performed by individuals.  AI can duplicate the human thought process and can learn to do things better over time.  AI’s goal is to mimic the way individuals think, learn, reason, solve problems, and make decisions.  AI can model the analytic process performed by marketing managers and analysts.  Consequently, AI can reduce the cost of performing the analytics work, be more efficient, enhance productivity of marketing managers, and increase marketing efficiency and profitability.\n").padding(10)
            } // Section
            
            
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("P1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Big data can empower AI as AI can provide powerful new capabilities of processing big data at a reduced cost with scaling up algorithms.  For example, IBM powered AI provides a distribution platform for AI with machine learning.  IBM can help firms improve analytics processes and facilitate the training of complex AI models that can be used in performing analytics.\n").padding(10)
            } // Section
            // ----------------------
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
