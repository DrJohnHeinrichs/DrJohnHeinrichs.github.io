//
//  C03S02T01.swift
//  Chapter 03 Section 02 Topic 01: Marketing Analytics Task Definition
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S02T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure32Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("First Stage")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("This first stage in the process model entails three steps.  Figure 3.2 shows the steps involved in this first stage.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 3-2: Marketing Analytics Task Definition Steps") {
                            self.showingFigure32Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure32Sheet1) {
                            Figure32View1()
                        }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Why Generate Analytics")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The key element of the business analytics process is to understand why managers want to generate analytics.  The analytics process begins with identifying the decision domain and related managerial need for new analytics solutions.  Managers need to clearly understand what decision problems or issues at hand they want to resolve or tackle with the analytics process.  The managerial problem can range from an intuitive feel that something in the firm needs to be understood or addressed to a discrete, well-defined problem statement.  Regardless, the question or problem must be converted into an analytical question.  The analytic question contains the identified metrics or analytics that are to be used in determining the response or desired solution.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Managerial Problems")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Managerial problems can take many different forms and shapes.  They can be best understood by the nature of the problems and the actions needed to be taken by managers to resolve the problem.  The managerial problem can be evaluated by assessing what level of firm activities is associated with the managerial problem.  When marketing managers face a managerial problem to solve, it is important to assess what levels of activities and decision domains are associated with the problem.  For the analytic problem, appropriate scope, unit of analysis and metrics need to be identified and assessed.  This understanding offers the scope of the analytical solutions needed to solve the problem.  It also defines the direction to take to generate analytical questions.  Understanding the scope provides an important guideline in determining the type of metrics and unit of analysis required for analytical solutions.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                        } // Section
                        // ----------------------
                    List{
                        NavigationLink(destination: ManagerialProblemCategories()){
                            Text("Managerial Problem Categories").font(.system(size: 22)).fontWeight(.black).italic().frame(maxWidth: .infinity, alignment: .center)
                        }
                    }
                    // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("2. Marketing Analytic Task Definition", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 3-2 VIEW
// ------------------------------
struct Figure32View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 3-2: Marketing Analytics Task Definition Steps")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-3-2")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 3-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TOPIC: MANAGERIAL PROBLEM CATEGORIES
// ------------------------------
struct ManagerialProblemCategories: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            // ----------------------
            Text("Managerial Problem Categories").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problem Classification: Category 1")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("Based on the nature of the problem, managerial problems can be classified into several categories.  The first category is taking a specific problem area focus.  Marketing managers will face a situation where they recognize a sign of troubling areas and need to resolve that troubling area.  This type of situation requires a systematic assessment of symptoms of the troubling area.  They need to assess the degree, duration, and persistence of the symptoms.  For example, a marketing manager may recognize the sales volume of a particular product plummeting in the past year or so.  In this case, managers first assess whether this sales decline is consistently occurring across all regions and customer types.  In addition, identifying the cause of this sales decline is also of importance.  Managers are concerned about alternative causes of this sales decline and should search for and confirm possible causes before resolving this issue.  Therefore, this manager would mine sales data to evaluate whether a particular model or region is primarily contributing to this sales decline or whether this sales decline is occurring across all product models and regions.  This type of managerial problem requires extensive analytical solutions evaluating both short term and long-term evaluation of key metrics and related marketing mix variables.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problem Classification: Category 2")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The second category is searching for a growth area or window of opportunity.  In this endeavor, marketing managers are required to perform a series of trend and environmental analysis to identify critical changes occurring in competitor or customer value propositions.  The focus of this category is on understanding the critical factors that can change the industry value proposition and competitive dynamics.  The type of analytical solutions used is trend analysis by market and product segment as well as other major social and economic trends that affects key customers’ decision-making mechanism and criteria.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problem Classification: Category 3")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The third category is described as a diagnostic problem.  Marketing managers may need to evaluate the firm’s overall competitive and market position.  They also need to determine the firm’s directions for planning and take preemptive strategic choices to avoid possible future problem areas.  Diagnostic analysis can provide valuable analytic solutions in this case.  For example, exception analysis can be performed to generate exceptional measures or metrics that is not commonly feasible in typical operations.  The exception reporting mechanism for key metrics such as revenue, sales, or cost can provide an early warning for analysts to take an appropriate action before the situation gets worse.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problem Classification: Category 4")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The fourth category is evaluating conformity to business rules set by firms and outside agencies.  The analytic solutions can provide an effective tool for validating the compliance of the firm’s activities, practices, and key metrics to business rules of the industry or government agencies.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problem Classification: Category 5")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The final category is whether the firm is following a certain type of business model in the industry.  Many firms initiate programs that envision both normative and positive (industry best practice) business models.  Analytic solutions can provide tools and analytic models that can guide implementation of various business models and test the possible outcome of the implementation under alternative scenario.  For example, what-if analysis can be performed on the analytic business model to test the effect of various components of the model and find the best implementation strategy.\n").padding(10)
            } // Section
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Problems exist ...")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                {
            // ----------------------
            Text("The management problems exist within the context of the problem situation and decision domain.  The situational analysis focuses on the metrics and decision maker that have produced the stated managerial problem.  In defining the analytical problem, marketing managers need to assess available knowledge, anticipated actions, alternative scenarios, and actionable analytical solutions.  The influencing factors that have led to the problem should be identified first.  These factors include objectives, past information and forecasts, resource and constraints (such as metrics available in the data warehouse, metrics in digital form, and metrics in paper form as well as existing analytic solutions in the analytics warehouse), decision time, importance of the decision, marketing and technological skills (such as marketing implementation skills and data-mining tools and analytical sophistication), customer behavior, legal environment, and economic environment.\n").padding(10)
            } // Section
        } // ScrollView
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
