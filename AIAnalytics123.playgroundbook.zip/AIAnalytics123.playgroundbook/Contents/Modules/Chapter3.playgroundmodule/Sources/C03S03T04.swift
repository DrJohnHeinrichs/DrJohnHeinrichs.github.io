//
//  C03S03T04.swift
//  Book_Sources
//
//  Chapter 03 Section 03: Topic 04: Select Relevant Analytic Output
//
//  Created by SBAMBP on 4/04/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C03S03T04: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 4: Start --- Main Page
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Step 7")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("In step 7, marketing managers evaluate the numerous analytic outputs generated from both the user-driven and AI-driven analytics run and select the relevant analytic tables and charts for interpretation and application.  After reviewing the generated output, managers may need to go back to step 6 to run additional analysis to generate more appropriate or currently missing tables and charts for answering analytic questions.  Depending on the software tools and AI system, the format of the tables and charts can vary significantly.  Therefore, these outputs need to be organized for clear understanding and presentation.  They need to be retrieved and saved in the right format for evaluation and interpretation.  The application of the selected analytic modules will generate graphs, charts, tables, diagrams, formulas, and statistical outputs.  These results are now stored in a separate document or added to the firm’s customized report format.  Some of the analytic modules and processes can be saved within the software tools as a customized solution.  These solutions and related modules can be retrieved later for additional use.  Newly created calculations can be stored in the data warehouse.  New analytic solution modules can be stored also for future use.\n").padding(10)
                    } // Section
                    // ----------------------
                    .padding(10)
                // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("3. Marketing Analytics Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 4: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
