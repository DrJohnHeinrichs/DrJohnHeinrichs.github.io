//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "The conceptual framework involves the usee of data to perform business analytic tasks.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.4941, blue: 0.4745, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 1:
            // -------------------------
            C02S04T01(topicTitle: "4.1 Insight Generation")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("2.4.1 Insight Generation")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("2.4.1 Insight Generation")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 2:
            // -------------------------
            C02S04T02(topicTitle: "4.2 Quality of Generated Insights ")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("2.4.2 Quality of Generated Insights ")
                    }
            } else {
                    Image(systemName: "pencil")
                    Text("2.4.2 Quality of Generated Insights")
                }
                } // tabItem
            .tag("bookSection2")
            
        } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Insights and Intelligence.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Insight Generation\n\nThis is a reading assignment.",
                        "-- Topic 2: Quality of Generated Insights\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.4942, blue: 0.4745, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
// --------------------------------
// --------------------------------
//import SwiftUI
//import UIKit
//import PlaygroundSupport
//import AVFoundation
//
//// --------------------------------
//// --------------------------------
//public enum AssessmentResults {
//    case pass(message: String)
//    case fail(hints: [String], solution: String?)
//} // enum
//// --------------------------------
//// --------------------------------
//extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    public init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
//// --------------------------------
//// --------------------------------
//@available(iOSApplicationExtension 13.0.0, *)
//struct ContentView: View {
//
//    @State private var wakeUp = Date ()
//    @State private var sleepAmount = 8.0
//    @State private var coffeeAmount = 1
//
//    init() {
//        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.4941, blue: 0.4745, alpha: 1.0)
//        UINavigationBar.appearance().titleTextAttributes = [
//            .foregroundColor: UIColor.black,
//            .font : UIFont(name:"HelveticaNeue-Bold", size: 30)!]
//    } // init
//
//    var body: some View {
//        NavigationView {
//                VStack {
//                    Text("When do you want to wake up?")
//                        .font(.headline)
//
//                    DatePicker("Please enter a date", selection: $wakeUp, displayedComponents: .hourAndMinute)
//                        .labelsHidden()
//                        .datePickerStyle(WheelDatePickerStyle())
//
//                        Text("Desired amount of sleep")
//                            .font(.headline)
//
//                        Stepper(value: $sleepAmount, in: 4...12, step: 0.25) {
//                            Text("\(sleepAmount, specifier: "%g") hours")
//                        } // Stepper
//
//                        Text("Daily coffee intake")
//                            .font(.headline)
//
//                        Stepper(value: $coffeeAmount, in: 1...20){
//                            if coffeeAmount == 1 {
//                                Text("1 cup")
//                            } else {
//                                Text("\(coffeeAmount) cups")
//                            }
//                        } // Stepper
//                } // VStack top
//                .frame(maxWidth: .infinity, maxHeight: .infinity)
//                .background(Color(UIColor(red: 1.0000, green: 0.4942, blue: 0.4745, alpha: 1.0)))
//                .navigationBarTitle("Conceptual Framework of Business Analytics", displayMode: .inline)
//        } // Navigation View
//            .navigationViewStyle(StackNavigationViewStyle())
//    } // body
//
//    static var defaultWakeTime: Date{
//        var components = DateComponents()
//        components.hour = 7
//        components.minute = 0
//        return Calendar.current.date(from: components) ?? Date()
//    } // var defaultWakeTime
//
//} // struct
// --------------------------------
// --------------------------------
//if #available(iOSApplicationExtension 13.0.0, *) {
//    PlaygroundPage.current.setLiveView(ContentView())
//    PlaygroundPage.current.needsIndefiniteExecution = true
//} else {
//    // Fallback on earlier versions
//}
//
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Conceptual Framework of Business Analytics
### Table of Contents - _Chapter 2_
 1. [Section 1: Business Analytics Tasks](PlaygroundPage)
 2. [Section 2: Nature and Properties of Big Data](PlaygroundPage2)
 3. [Section 3: Analytics Tools and Software](PlaygroundPage3)
 4. **[Section 4: Insights and Intelligence](PlaygroundPage4)**
 */

/*:
* Callout(Quote: Business Analytics):
"An intelligent person is never afraid or ashamed to find errors in his understanding of things."
\
–Bryant H. McGill
*/

/*:
 ## 4.1 Insight Generation
 
 ## 4.2 Quality of Generated Insights
 * In this challenge, you'll practice your [Business Analytics](glossary://Business%20Analytics) - finding skills by finding and rearranging.
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **insights and intelligence**, view the following ...
 * [The Swift Programming Language]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
