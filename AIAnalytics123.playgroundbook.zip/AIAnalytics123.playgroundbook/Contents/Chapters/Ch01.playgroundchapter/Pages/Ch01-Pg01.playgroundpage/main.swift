//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
import Chapter1
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "There are many different reasons why firms are utilizing business analytics.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 1: Definition
            // -------------------------
            C01S01T01(topicTitle: "1.1 Business Analytics Definition")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.1.1 Business Analytics Definition")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("1.1.1 Business Analytics Definition")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 2: Strategy
            // -------------------------
            C01S01T02(topicTitle: "1.2 Business Analytics as a Strategy")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.1.2 Business Analytics as a Strategy")
                    }
            } else {
                    Image(systemName: "pencil")
                    Text("1.1.2 Business Analytics as a Strategy")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------

        } // TabView
            // -------------------------
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the Business Analytics topic.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Business Analytics Definition\n\nThis is a reading assignment.",
                        "-- Topic 2: Business Analytics as a Firm Strategy\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S01HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
// --------------------------------
// --------------------------------
//#-end-hidden-code
/*:
## Business Analytics for Professionals
### Table of Contents - Chapter 1
 1. **[Section 1: Emerging Role of Business Analytics](Ch01-Pg01)**
 2. [Section 2: Paradigm Shift: Analytics-Driven Decision-Making](Ch01-Pg02)
 3. [Section 3: Types and Categories of Business Analytics](Ch01-Pg03)
 4. [Section 4: Machine Learning](Ch01-Pg04)
 */

/*:
 * Callout(Quote: Business Analytics):
 "If you do not know how to ask the right question, you discover nothing."
 \
 –W. Edward Deming
 */

/*:
 ## 1. Emerging Role of Business Analytics
There are many different reasons why firms are utilizing business analytics.  Several key reasons firms are implementing business analytics processes include ...
 * the ability to translate real-time insights into competitive advantage,
 * the ability to provide various firm stakeholders with valuable information for improved problem-solving and decision-making, and
 * the ability to process and evaluate the ever increasing, massive amounts of unfiltered and unstructured data being utilized by the firm’s analysts for insight generation.
 
 ## 1.1 Business Analytics Definition
 
 ## 1.2 Business Analytics as a Firm Strategy for Competitive Advantage
 */

/*:
 - Important:
 Exploiting the vast quantity of data becomes both a monumental challenge and a tremendous opportunity for the firm’s analysts tasked with providing useful, action-oriented support to the firm’s management team.
 */

/*:
 - Note:
[Business analytics](glossary://Business%20Analytics) can be used by the analysts to answer a variety of probing questions such as ...
 * Why is this pattern occurring for this product line?,
 * What if specific performance trends continue?,
 * What is expected to happen in future time periods?, and
 * Given various options, what is the best possible outcome that can occur?.
 */

/*: Setup and use a link reference.
 [How to Monitor Business Trends]: https://www.trustinsights.ai/blog/2020/03/business-analytics-101-how-to-monitor-business-trends/
 
 ### Additional Information:
 For more information regarding **business analytics**, view the following ...
 * [How to Monitor Business Trends]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
