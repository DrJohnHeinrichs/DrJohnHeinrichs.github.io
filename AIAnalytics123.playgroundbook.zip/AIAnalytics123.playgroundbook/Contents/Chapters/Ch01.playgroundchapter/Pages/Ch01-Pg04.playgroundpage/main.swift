//#-hidden-code
//
import SwiftUI
import PlaygroundSupport
import Chapter1

@available(iOSApplicationExtension 13.0, *)
struct ContentView: View {
    @State private var alertTitle = "Title"
    @State private var alertMessage = "Message"
    @State private var showingAlert = false
    
    @State private var solarPanels: Double = 1
    @State private var greenhouses: Double = 1
    @State private var acres: Double = 1000
    @State private var selectedPurpose = 0
    @State private var purposes = ["Farm", "General", "Power"]
    
    @State private var marsPrice: Double = 0.0
    
    var body: some View {
        NavigationView {
            
        VStack{
            Form {
                Section (header: Text("Number of Solar Panels")){
                    Stepper(value: $solarPanels, in: 1 ... 20) {
                        if solarPanels == 1 {
                            Text("1 solar panel")
                        } else {
                            Text("\(solarPanels, specifier: "%.f") solar panels")
                        } // if-else
                    } // Stepper
                } // Section
                
                Section(header: Text("Number of Greenhouses")) {
                    Stepper(value: $greenhouses, in: 1 ... 20) {
                        if greenhouses == 1 {
                            Text("1 greenhouse")
                        } else {
                            Text("\(greenhouses, specifier: "%.f") greenhouses")
                        } // if-else
                    } // Stepper
                } // Section - greenhouses
                
                Section (header: Text("Size -- in acres")) {
                    Stepper(value: $acres, in: 1000 ... 20000, step: 1000) {
                        if acres == 1 {
                            Text("1 acre")
                        } else {
                            Text("\(acres, specifier: "%g") acres")
                        } // if-else
                    } // Stepper
                } // Section - acres
                
                Section (header: Text("Estimated Price -- in millions -- for Mars Habitat")) {
                    Text("$\(marsPrice, specifier: "%g")")
                } // Section - price
                
                } // Form
                 
            Picker(selection: $selectedPurpose, label: Text("Choose a purpose for your purchase ... ")) {
                ForEach ( 0 ..< purposes.count) {
                    Text("\(self.purposes[$0])")
                } // ForEach
            } // Picker
    } // VStack

            .navigationBarTitle("Business Analytics for Professionals", displayMode: .inline)
            .navigationBarItems(trailing:
                Button(action: callIt) {
                    Text("Calculate")
                } // Button
                )
                .alert(isPresented: $showingAlert){
                    Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("Ok")))
                } // Alert
        } // NavigationView
            .navigationViewStyle(StackNavigationViewStyle())
    } // body
            
    func callIt() {
        
// Construct the ML model object.
 let pricer = MarsHabitatPricer()

// Provide some input
 let input = MarsHabitatPricerInput(solarPanels: solarPanels, greenhouses: greenhouses, size: acres)
        
// Make prediction
        do {
            let output = try pricer.prediction(input: input)
            marsPrice = output.price
            let marsPrice1: Int = Int(output.price)
            alertTitle = "Mars Habitat"
            alertMessage = "Predicted Price (millions) ... $\(marsPrice1) \n\n for \(purposes[selectedPurpose])"
        } catch {
            
        }
// Alert the price
        showingAlert = true
    }
}

if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vc = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vc
} else {
    // Fallback on earlier versions
} // if - else
//
//#-end-hidden-code
/*:
## Business Analytics for Professionals
### Table of Contents - Chapter 1
 1. [Section 1: Emerging Role of Business Analytics](Ch01-Pg01)
 2. [Section 2: Paradigm Shift: Analytics-Driven Decision-Making](Ch01-Pg02)
 3. [Section 3: Types and Categories of Business Analytics](Ch01-Pg03)
 4. **[Section 4: Machine Learning](Ch01-Pg04)**
 */

/*:
 * Callout(Quote: Machine Learning):
 "FEAR has two meanings: 'Forget Everything And Run' or 'Face Everything And Rise. ' The choice is yours."
 \
 –Zig Ziglar
 */

/*:
# Mars Habitat Pricer

Given the number of solar panels, greenhouses, and size of a martian property, predict how much will the price be.
This illustrates the simplest way to use a Core ML model.

The data table contains the following columns of information about a habitat on Mars: Price, Size (area in acres), Number of greenhouses, Number of solar panels, and Primary purpose.

For the columns: solar_panels is a float; greenhouses is a float; size is a double; price is an integer; and purpose is a string (farm, general, power);

The inputs are the number of solar panels and greenhouses, as well as the lot size of the habitat (in acres).

The output is the predicted price of the habitat.

The model was taken from  [Mars Habitat Price Predictor]: (https://developer.apple.com/documentation/coreml/integrating_a_core_ml_model_into_your_app).

*/

/*: Setup and use a link reference.
[The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

### Additional Information:
For more information regarding **types and categories of business analytics**, view the following ...
* [The Swift Programming Language]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)

