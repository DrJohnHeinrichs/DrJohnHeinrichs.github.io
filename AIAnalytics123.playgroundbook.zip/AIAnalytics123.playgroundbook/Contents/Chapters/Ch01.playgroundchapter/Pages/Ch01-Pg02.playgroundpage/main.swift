//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "The trends that facilitate or support the use of business analytics are emerging.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 1: Trends
            // -------------------------
            C01S02T01(topicTitle: "2.1 Trends Favoring Business Analytics")
//                .onTapGesture {
//                    self.selectedTab = "bookSection2"
//                } // onTapGesture
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.2.1 Trends Favoring Business Analytics")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("1.2.1 Trends Favoring Business Analytics")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 2: Strategy
            // -------------------------
            C01S02T02(topicTitle: "2.2 Rationale for Business Analytics")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.2.2 Rationale for Business Analytics")
                    }
            } else {
                    Image(systemName: "pencil")
                    Text("1.2.2 Rationale for Business Analytics")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------

        } // TabView
            // -------------------------
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the Business Analytics topic.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Trends Favoring Business Analytics\n\nThis is a reading assignment.",
                        "-- Topic 2: Rationale for Business Analytics\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S02HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
// --------------------------------
// --------------------------------
//#-end-hidden-code
/*:
## Business Analytics for Professionals
### Table of Contents - Chapter 1
 1. [Section 1: Emerging Role of Business Analytics](PlaygroundPage)
 2. **[Section 2: Paradigm Shift: Analytics-Driven Decision-Making](PlaygroundPage2)**
 3. [Section 3: Types and Categories of Business Analytics](PlaygroundPage3)
 4. [Section 4: Machine Learning](PlaygroundPage4)
 */

/*:
 * Callout(Quote: Machine Learning):
 "A point of view can be a dangerous luxury when substituted for insight and understanding."
\
–Marshall McLuhan
 */

/*:
 ## 2.1 Trends Favoring Business Analytics
 * There exists availability of large amounts of data.
    * The amount of information created in a day is huge and the pace of information creation is increasing.
    * The current amount of data created every day exceeds 2.5 quintillion (2.5 million trillion) bytes of data.
 * The increasing realization that data is a valuable resource and should be managed as an asset.
 * The linkage of business strategy, data, and business performance.
    * High level strategy is translated into a concrete set of performance metrics allowing the implementation of the firm’s strategy based on metrics.
    * Cultural change towards evidence-based management is becoming common in many firms.
    * The realization of the importance of fact-based decisions at every level of firm. 
 
## 2.2 Rationale for Business Analytics
 
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **analytics driven decision-making**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
