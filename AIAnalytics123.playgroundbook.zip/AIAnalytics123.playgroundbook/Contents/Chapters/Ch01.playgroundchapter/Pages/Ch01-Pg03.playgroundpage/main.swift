//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
import Chapter1
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "There are many different business analytic types.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 1:
            // -------------------------
            C01S03T01(topicTitle: "3.1 Business Analytics Types")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.3.1 Business Analytics Types")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("1.3.1 Business Analytics Types")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 2:
            // -------------------------
            C01S03T02(topicTitle: "3.2 Business Analytics Categories")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("1.3.2 Business Analytics Categories")
                    }
            } else {
                    Image(systemName: "pencil")
                    Text("1.3.2 Business Analytics Categories")
                }
                } // tabItem
            .tag("bookSection2")
            
        } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the Business Analytics Types and Categories.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Business Analytics Types\n\nThis is a reading assignment.",
                        "-- Topic 2: Business Analytics Categories\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
// --------------------------------
// --------------------------------
//#-end-hidden-code
/*:
## Business Analytics for Professionals
### Table of Contents - Chapter 1
 1. [Section 1: Emerging Role of Business Analytics](Ch01-Pg01)
 2. [Section 2: Paradigm Shift: Analytics-Driven Decision-Making](Ch01-Pg02)
 3. **[Section 3: Types and Categories of Business Analytics](Ch01-Pg03)**
 4. [Section 4: Machine Learning](Ch01-Pg04)
 */

/*:
 * Callout(Quote: Business Analytics):
 "Marketing without data is like driving with your eyes closed."
 \
 –Dan Zarella
 */

/*:
 ## 3.1 Business Analytics Types
  
 [Descriptive analytics](glossary://Descriptive%20Analytics) focus on answering what happened in the past, what is happening now, and what will likely to happen based upon the past.  These analytics apply simple statistical techniques that explore data and describe what is contained in a data set or database.  For example, descriptive analytics can be used to identify possible trends in large data sets or databases to get a rough picture of what the data looks like.
 - _Descriptive Analytics_
 - _Diagnostic Analytics_
 - _Predictive Analytics_
 - _Prescriptive Analytics_
 
 ## 3.2 Business Analytics Categories

 - *Strategic Analytics*
 - *Scanning / Customer-Related Analytics*
 - *Tactical Analytics*
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **types and categories of business analytics**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
