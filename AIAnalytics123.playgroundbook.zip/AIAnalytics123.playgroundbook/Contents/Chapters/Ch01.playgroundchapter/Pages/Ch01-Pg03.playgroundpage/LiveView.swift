//
//  Abstract:
//  Instantiate a new instance of the live view from the book's auxiliary sources and pass it to PlaygroundSupport.
//
//  Chapter 1: Business Analytics for Professionals
//  Section 3: Types and Categories of Business Analytics

import SwiftUI
import UIKit
import PlaygroundSupport
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Business Analytics for Professionals")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero
    
    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(2)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                Image(name: "AnalyticsWords")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 400, height: 400)
                Spacer()
                C01S03T01Instructions()
                .padding(20)
                Spacer()
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5726, green: 0.5677, blue: 0.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------

if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC01S03 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC01S03
    PlaygroundPage.current.assessmentStatus = .pass(message: "Congratulations!\n\nYou are taking the 'Types and Categories of Business Analytics' section.")

} else {
    // Fallback on earlier versions
} // if - else

