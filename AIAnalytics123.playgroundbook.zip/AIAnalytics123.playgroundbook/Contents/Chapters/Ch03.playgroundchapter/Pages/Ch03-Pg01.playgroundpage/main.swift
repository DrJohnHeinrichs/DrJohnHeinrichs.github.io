//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// --------------------------------
// --------------------------------
for voice in (AVSpeechSynthesisVoice.speechVoices()){
    print(voice.language)
}
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "Managers are required to use analytics for fact-based decision marketing.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// --------------------------------
// --------------------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 26)!]
    } // init
    
    var body: some View {
        Group {
            TabView(selection: $selectedTab) {
                // -------------------------
                // TOPIC 1:
                // -------------------------
                C03S01T01(topicTitle: "Analytic")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.1 Three Stage Model")
                        }
                } else {
                        VStack{
                        Image(systemName: "pencil")
                        Text("3.1 Three Stage Model")
                        }
                    } // if-else
                    } // tabItem
                .tag("bookSection1")
            } // TabView
        // -------------------------
        // ASSESSMENT
        // -------------------------
        HStack {
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = true
                console(message: " Congratulations!!!\n\nYou have successfully completed Three Stage Model for Marketing Decision-Making .")
            } )
            {
                Text("I Understand this topic")
            } // button - understand
                .foregroundColor(.green)
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = false
                console(hints: [
                    "You have one topic to complete.",
                    "-- Topic 1: Three Stage Model for Marketing Decision-Making\n\nThis is a reading assignment. "
                ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
            } )
            {
                Text("I need help on this topic")
            } // button - need help
                .foregroundColor(.red)
            Spacer()
        } // HStack
                    .padding (.top, 15)
                    .padding (.bottom, 15)
                // -------------------------
            } // Group
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0000)))

    } // body
} // struct

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")

//
//#-end-hidden-code
/*:
## Marketing Analytics for Marketing Decision-Making
### Table of Contents - _Chapter 3_
 1. **[Section 1: Three Stage Model for Marketing Decision-Making](PlaygroundPage)**
 2. [Section 2: Marketing Analytic Task Definition](PlaygroundPage2)
 3. [Section 3: Marketing Analytics Solution Generation](PlaygroundPage3)
 4. [Section 4: Marketing Analytics Interpretation and Application](PlaygroundPage4)
 */

/*:
* Callout(Quote: Marketing Analytics):
"Tracking marketing is a cultural thing. Either tracking matters or it doesn’t. You’re in one camp or the other. Either you’re analytical and data-driven, or you go by what you think works. People who go by gut are wrong."
\
–Stuart McDonald, CMO at Freshbooks
*/

/*:
 ### Three Stage Model for Marketing Decision-Making
 * In this topic, you'll focus on enhancing your understanding of a three stage model for decision-making.
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **the three stage model**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
