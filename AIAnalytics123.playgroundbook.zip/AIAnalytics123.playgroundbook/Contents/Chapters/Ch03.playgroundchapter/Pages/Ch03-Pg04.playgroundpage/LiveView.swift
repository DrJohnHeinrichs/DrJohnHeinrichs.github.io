//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//
//  Chapter 3: Marketing Analytics for Marketing Decision-Making
//  Section 4: Marketing Analytics Interpretation and Application
//
// https://www.pexels.com/photo/computer-data-display-documents-577210/
// Photo by Lukas from Pexels
//
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter3
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Marketing Analytics Interpretation and Application")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero
    
    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                Image(uiImage: UIImage(named: "Marketing-Analytics-Graphs")!)
//                Image(name: "Marketing-Analytics-Graphs")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 350, height: 350)
                Spacer()
                C03S04T01Instructions()
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC03S04 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC03S04
    PlaygroundPage.current.assessmentStatus = .pass(message: "Congratulations!\n\nYou are taking the 'Marketing Analytics Interpretation and Application' section.")
} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
