//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// --------------------------------
// --------------------------------
for voice in (AVSpeechSynthesisVoice.speechVoices()){
    print(voice.language)
}
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "Managers need to utilize analytic outputs for insight generation and decision-making.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// --------------------------------
// --------------------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {

    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 26)!]
    } // init
        
    var body: some View {
        Group {
            TabView(selection: $selectedTab) {
                // -------------------------
                // TOPIC 1:
                // -------------------------
                C03S04T01(topicTitle: "Insight Generation")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.4.1 Insight Generation")
                            }
                    } else {
                            VStack{
                            Image(systemName: "pencil")
                            Text("3.4.1 Insight Generation")
                            }
                    } // if-else
                } // tabItem
                .tag("bookSection1")
                // -------------------------
                // TOPIC 2
                // -------------------------
                C03S04T02(topicTitle: "Decision Application")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.4.2 Decision Application")
                            }
                    } else {
                            VStack{
                            Image(systemName: "pencil")
                            Text("3.4.2 Decision Application")
                            }
                    } // if-else
                } // tabItem
                .tag("bookSection2")
                // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Marketing Analytics Interpretation and Application.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topics to complete.",
                        "-- Topic 1: Analytics Insight Generation\n\nThis is a reading assignment. ",
                        "-- Topic 2: Decision Application\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0000)))

    } // body
} // struct

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Marketing Analytics for Marketing Decision-Making
 ### Table of Contents - _Chapter 3_
 1. [Section 1: Three Stage Model for Marketing Decision-Making](PlaygroundPage)
 2. [Section 2: Marketing Analytic Task Definition](PlaygroundPage2)
 3. [Section 3: Marketing Analytics Solution Generation](PlaygroundPage3)
 4. **[Section 4: Marketing Analytics Interpretation and Application](PlaygroundPage4)**
 */

/*:
 * Callout(Quote: Marketing Analytics):
 "Without a goal analytics is aimless and worthless. A target should go with every goal. A target is the value that defines success."
 \
 –Michael Porter, economist, researcher, author, advisor, speaker and teacher at Harvard Business School
 */

/*:
 ## 4.1 Analytics Insight Generation
 
 ## 4.2 Decision Application
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **insights and intelligence**, view the following ...
 * [The Swift Programming Language]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
