//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// --------------------------------
// --------------------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "The key element of the analytics process is to understand why managers want to generate analytics.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// --------------------------------
// --------------------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 26)!]
    } // init
    
    var body: some View {
        Group {
            TabView(selection: $selectedTab) {
                // -------------------------
                // TOPIC 1:
                // -------------------------
                C03S02T01(topicTitle: "Problem Identification")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.2.1 Problem Identification")
                        }
                } else {
                        VStack{
                        Image(systemName: "pencil")
                        Text("3.2.1 Problem Identification")
                        }
                    } // if-else
                    } // tabItem
                .tag("bookSection1")
                // -------------------------
                // TOPIC 2:
                // -------------------------
                C03S02T02(topicTitle: "3.2.2 Solution Determination")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.2.2 Solution Determination")
                        }
                } else {
                        Image(systemName: "pencil")
                        Text("3.2.2 Solution Determination")
                    }
                    } // tabItem
                .tag("bookSection2")
                // -------------------------
                // TOPIC 3:
                // -------------------------
                C03S02T03(topicTitle: "3.2.3 Question Framing")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.2.3 Question Framing")
                        }
                } else {
                        Image(systemName: "pencil")
                        Text("3.2.3 Question Framing")
                    }
                    } // tabItem
                .tag("bookSection3")

            } // TabView

//                .frame(maxWidth: .infinity, maxHeight: .infinity)
 //               .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)))
        // -------------------------
        // ASSESSMENT
        // -------------------------
        HStack {
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = true
                console(message: " Congratulations!!!\n\nYou have successfully completed Marketing Analytics Task Definition.")
            } )
            {
                Text("I Understand this topic")
            } // button - understand
                .foregroundColor(.green)
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = false
                console(hints: [
                    "You have three topics to complete.",
                    "-- Topic 1: Analytic Problem and Decision Domain Identification\n\nThis is a reading assignment. ",
                    "-- Topic 2: Desired Solution Determination\n\nThis is a reading assignment. ",
                    "-- Topic 3: Analytic Question Framing and Type of Analytic Selection\n\nThis is a reading assignment. "
                ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
            } )
            {
                Text("I need help on this topic")
            } // button - need help
                .foregroundColor(.red)
            Spacer()
        } // HStack
                    .padding (.top, 15)
                    .padding (.bottom, 15)
                // -------------------------
            } // Group
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0000)))
    } // body
} // struct
// --------------------------------
// --------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Marketing Analytics for Marketing Decision-Making
### Table of Contents - _Chapter 3_
 1. [Section 1: Three Stage Model for Marketing Decision-Making](PlaygroundPage)
 2. **[Section 2: Marketing Analytic Task Definition](PlaygroundPage2)**
 3. [Section 3: Marketing Analytics Solution Generation](PlaygroundPage3)
 4. [Section 4: Marketing Analytics Interpretation and Application](PlaygroundPage4)
 */

/*:
* Callout(Quote: Marketing Analytics):
"What gets measured gets improved."
\
–Peter Drucker, “The Founder of Modern Management”
*/

/*:
 ## 2.1 Analytic Problem and Decision Domain Indentification
 ### *Managerial Problem Categories*
 */

/*:
 ## 2.2 Desired Solution Determination
 ### *Nature of Analytic Solutions*
 ### *Analytic Solution Categories*
 * Strategic Analytic Solutions
 * Scanning / Customer-Related Analytic Solutions
 * Tactical Analytic Solutions
 ### *Analytic Solution Types*
 * Descriptive Analytic Solutions
 * Predictive Analytic Solutions
 * Prescriptive Analytic Solutions
 */

/*:
 ## 2.3 Analytic Question Framing and Type of Analytics Selection
 
 * In this topic, you'll focus on enhancing your knowledge of marketing analytics tasks.
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

### Additional Information:
 For more information regarding **task definitions**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
