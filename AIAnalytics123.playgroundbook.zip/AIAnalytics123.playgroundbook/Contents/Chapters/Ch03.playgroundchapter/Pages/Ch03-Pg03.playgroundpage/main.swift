//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
import Chapter3
// --------------------------------
// --------------------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This stage involves developing the process of generating deliverables that answer the questions generated in the first stage.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// --------------------------------
// --------------------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 30)!]
    } // init
    var body: some View {
        Group {
            TabView(selection: $selectedTab) {
                // -------------------------
                // TOPIC 1:
                // -------------------------
                C03S03T01(topicTitle: "Toolbox")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.2.1 Toolbox")
                        }
                } else {
                        VStack{
                        Image(systemName: "pencil")
                        Text("3.2.1 Toolbox")
                        }
                    } // if-else
                    } // tabItem
                .tag("bookSection1")
                // -------------------------
                // TOPIC 2:
                // -------------------------
                C03S03T02(topicTitle: "3.3.2 Input Identification")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.3.2 Input Identification")
                        }
                } else {
                        Image(systemName: "pencil")
                        Text("3.3.2 Input Identification")
                    }
                    } // tabItem
                .tag("bookSection2")
                // -------------------------
                // TOPIC 3:
                // -------------------------
                C03S03T03(topicTitle: "3.3.3 Analytics Run")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.2.3 Analytics Run")
                        }
                } else {
                        Image(systemName: "pencil")
                        Text("3.2.3 Analytics Run")
                    }
                    } // tabItem
                .tag("bookSection3")
                // -------------------------
                // TOPIC 4:
                // -------------------------
                C03S03T04(topicTitle: "3.3.4 Output")
                .tabItem {
                    if understandSection {
                        VStack{
                            Image(systemName: "star.fill")
                            Text("3.3.4 Output")
                        }
                } else {
                        Image(systemName: "pencil")
                        Text("3.3.4 Output")
                    }
                    } // tabItem
                .tag("bookSection4")

            } // TabView

//                .frame(maxWidth: .infinity, maxHeight: .infinity)
 //               .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0)))
        // -------------------------
        // ASSESSMENT
        // -------------------------
        HStack {
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = true
                console(message: " Congratulations!!!\n\nYou have successfully completed Marketing Analytics Solution Generation.")
            } )
            {
                Text("I Understand this topic")
            } // button - understand
                .foregroundColor(.green)
            // -------------------------
            Spacer()
            Button(action: {
                self.understandSection = false
                console(hints: [
                    "You have four topics to complete.",
                    "-- Topic 1: Analytic Tool Selection from Analytic Toolbox\n\nThis is a reading assignment. ",
                    "-- Topic 2: Input Data Identification and Pre-processing\n\nThis is a reading assignment. ",
                    "-- Topic 3: Analytics Run\n\nThis is a reading assignment. ",
                    "-- Topic 4: Select Relevant Analytic Output\n\nThis is a reading assignment. "
                ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
            } )
            {
                
                Text("I need help on this topic")
            } // button - need help
                .foregroundColor(.red)
            Spacer()
        } // HStack
                    .padding (.top, 15)
                    .padding (.bottom, 15)
                // -------------------------
            } // Group
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(UIColor(red: 1.0000, green: 0.5765, blue: 0.0000, alpha: 1.0000)))
    } // body
} // struct
// --------------------------------
// --------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Marketing Analytics for Marketing Decision-Making
### Table of Contents - _Chapter 3_
 1. [Section 1: Three Stage Model for Marketing Decision-Making](Ch03-Pg01)
 2. [Section 2: Marketing Analytic Task Definition](Ch03-Pg02)
 3. **[Section 3: Marketing Analytics Solution Generation](Ch03-Pg03)**
 4. [Section 4: Marketing Analytics Interpretation and Application](Ch03-Pg04)
 */

/*:
* Callout(Quote: Marketing Analytics):
"Data are just summaries of thousands of stories – tell a few of those stories to help make the data meaningful."
\
–Chip & Dan Heath, Authors of Made to Stick, Switch and professor of business”
*/

/*:
 ## 3.1 Analytic Tool Selection from Analytic Toolbox
 ### _Analytics Goals_
 ### _Analytics Tool Type_
 ### _Analytics Tool Technology_
 * User-Driven Analytics
 * AI-Driven Analytics
 * Machine Learning
 * AI-Driven Analytics Outcome

 ## 3.2 Input Data Identification and Pre-Processing
 
 ## 3.3 Analytics Run
 
 ## 3.4 Select Relevant Analytic Output
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **solution generation**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
