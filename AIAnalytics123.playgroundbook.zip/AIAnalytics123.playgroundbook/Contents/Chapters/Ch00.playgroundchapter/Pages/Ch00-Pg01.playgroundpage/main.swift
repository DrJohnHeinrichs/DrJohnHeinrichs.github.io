//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
import Chapter0
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This is the preface of the book.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.6902, green: 0.9098, blue: 0.8824, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 1: Definition
            // -------------------------
            C00S01T01(topicTitle: "Preface")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("Preface")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("Preface")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
        } // TabView
            // -------------------------
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the Preface topic.")
                } )
                {
                    Text("I Understand this topic")
                } // button - understand
                    .foregroundColor(.green)
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Preface\n\nThis is a reading assignment."
                    ], solution: "Try this to get it to work. \n\n")
//                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S01HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need help on this topic")
                } // button - need help
                    .foregroundColor(.red)
                Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.6902, green: 0.9098, blue: 0.8824, alpha: 0.4000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
// --------------------------------
// --------------------------------
//#-end-hidden-code
/*:
## Big Data and AI Driven Marketing Analytics
### Table of Contents
 1. **[Preface](Ch00-Pg01)**
 */

/*:
 * Callout(Quote: Artificial Intelligence):
 "As more and more artificial intelligence is entering into the world, more and more emotional intelligence must enter into leadership."
 \
 –Amit Ray
 */

/*:
 - Important:
 Exploiting the vast quantity of data becomes both a monumental challenge and a tremendous opportunity for the analysts tasked with providing useful, action-oriented support to the management team.
 */

/*:
 - Note:
[Business analytics](glossary://Business%20Analytics) can be used by the analysts to answer a variety of probing questions such as ...
 * Why is this pattern occurring for this product line?,
 * What if specific performance trends continue?,
 * What is expected to happen in future time periods?, and
 * Given various options, what is the best possible outcome that can occur?.
 */

/*: Setup and use a link reference.
 [How to Monitor Business Trends]: https://www.trustinsights.ai/blog/2020/03/business-analytics-101-how-to-monitor-business-trends/
 
 ### Additional Information:
 For more information regarding **business analytics**, view the following ...
 * [How to Monitor Business Trends]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
