import SwiftUI
public let badImage = UIImage(systemName:"x.square")!
