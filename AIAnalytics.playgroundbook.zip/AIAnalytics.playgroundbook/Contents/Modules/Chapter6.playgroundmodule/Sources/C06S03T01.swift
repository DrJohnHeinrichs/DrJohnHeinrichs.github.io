//
//  C06S03T01.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 3: Classification and Prediction Analytic Solution Generation
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S03T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Selecting the Appropriate Method
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.3.1 Selecting the Appropriate Method").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Four Methods")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Four commonly used classification and prediction methods shown in Table 6-1 are described.  Each method has its own advantages and disadvantages as well as different input data requirements.  Marketing managers can use K-Nearest Neighbor (KNN) when there is a large training dataset with multiple predictor variables.  KNN makes no parametric assumption and is simple to perform.  Classification and regression tree can help marketing managers identify which predictors are most important and useful for classification.  This method can be used with real large dataset and provides good performance.  This method is easy to understand and interpret the results.  This method can be applied to a wide range of relationships including non-linear and non-parametric.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Neural Net")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Neural nets can be used for good predictive performance with large training dataset.  This method shows high tolerance for poor data quality and capture complicated relationships although it provides little insight on the nature of relationship.  Finally, Naïve Bayes can be used for computational efficiency with good classification performance.  Marketing managers can apply this method to categorical variables as it can handle categorical variables directly.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.3 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
