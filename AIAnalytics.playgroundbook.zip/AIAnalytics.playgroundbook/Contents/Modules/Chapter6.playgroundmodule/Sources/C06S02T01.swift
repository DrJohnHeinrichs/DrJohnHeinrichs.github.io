//
//  C06S02T01.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 1: K Nearest Neighbor (KNN)
//
//  Created by SBAMBP on 04/16/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S02T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure62Sheet1 = false
    @State private var showingFigure63Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- K Nearest Neighbor (KNN)
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.1.1 K Nearest Neighbor (KNN)").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Technique")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("K Nearest Neighbor (KNN) is an analytic technique to predict a response based on a set of predictor variables.  KNN is one of the most applicable and useful non-parametric algorithms.  Therefore, it does not make any assumption on the data and all data points can be used directly in classification without any training.  KNN is applied to predict either a continuous response variable or categorical response variable.  The idea in the KNN method is to identify k records in the training set that are similar to a new record a marketing manager is interested in classifying.  Based on the k records identified, the new record is assigned to the predominant class among these k neighbors.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("First Step")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("First, in applying KNN to a categorical variable, marketing managers need to choose k.  K can be any number but typically an odd number that falls in the range of 1 to 20.  K is chosen based on the classification performance.  The class performance can be calculated by computing error rates of various values of k for classifying the records in the validation data using the training dataset classification results.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Second Step")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Second, KNN finds the nearest k neighbors to the record to be classified.  For example, if k = 3 is used, the three nearest neighbors to the record to be classified are identified.  KNN determines the nearest neighbors by computing the distances between records using their predictor values.  If all predictor variables are continuous, Euclidean distance between two records (X1, X2, - - -, Xn) and (Y1, Y2, - - -, Yn) is calculated as:\n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-6-1.jpg")!)
//                            Image(name: "Equation-6-1.jpg")
                        Text("Euclidean distance measure is the most commonly used in KNN.  To calculate Euclidean distance, any non-numerical variables are converted to n dummy variables 0 and 1. \n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Third Steps")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Third, KNN uses a majority decision rule to classify a new record to the majority class of the k neighbors.  The majority decision rule is applied to classify a new record using a cutoff value of the class membership probabilities.  For example, using a simple majority rule is setting the cutoff value of 0.5.  As the cutoff value can influence the accuracy of classification, marketing managers can choose the cutoff value other than the default value of 0.5.  The cutoff values that are higher than 0.5 can be selected when marketing managers want to maximize the accuracy of classification.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("KNN")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("KNN can also be applied to continuous response variables.  The process is similar to the case of categorical response variables.  However, the way the majority is determined is different.  The average response value of the k-nearest neighbors is used to determine the prediction.  The average is the weighted average with the weight decreasing with increasing distance from the response value of the new case predicted.  Figure 6-2 shows the classification rule for the categorical response of purchaser (1) versus non-purchaser (0).  Depending on the value of k, the k-nearest neighbors are selected and evaluated for class membership in the training set.  In this example, when k = 5, four of the five nearest neighbors are purchasers and one of the five nearest neighbors is non-purchasers.  Therefore, the new customer is classified as a purchaser.\n").padding(10)
                        } // Section 5
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-2: Classification Rule Example for the Categorical Response"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-2.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-2: Classification Rule Example for the Categorical Response") {
                            self.showingFigure62Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure62Sheet1) {
                            Figure62View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Classification Rule")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Figure 6-3 shows the classification rule for the continuous response of purchase amount.  In this example, when k =3, if a new customer’s income level is $75,000, then this customer’s predicted purchase amount is $650, that is the average purchase amount ((600 + 550 + 800 / 3), of the three nearest neighbors whose income levels are $73,000, $81,000, and $82,000.\n").padding(10)
                        } // Section 5
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-3: Classification Rule Example for the Continuous Response"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-3.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-3: Classification Rule Example for the Continuous Response") {
                            self.showingFigure63Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure63Sheet1) {
                            Figure63View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.2 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 6-2 VIEW
// ------------------------------
struct Figure62View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-2: Classification Rule Example for the Categorical Response")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 6-3 VIEW
// ------------------------------
struct Figure63View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-3: Classification Rule Example for the Continuous Response")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
