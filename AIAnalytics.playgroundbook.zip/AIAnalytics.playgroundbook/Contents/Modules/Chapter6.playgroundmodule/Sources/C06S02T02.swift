//
//  C06S02T02.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 3: Classification and Regression Trees
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S02T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure64Sheet1 = false
    @State private var showingFigure65Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Classification and Regression Trees
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.2.2 Classification and Regression Trees").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Technique")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Classification trees are an important data-mining analysis algorithm or technique.  Using this data-mining algorithm, marketing managers can predict both discrete and continuous attributes.  This data-mining technique is used to classify the data into groups which are also known as branches.  The decision tree is used to identify the potential segments that have the strongest separation in the values or states of the desired dependent variable.  An advantage with using the decision trees algorithm is that the results obtained are easily understandable and easily explained.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Decision Trees Algorithm")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In building a data-mining model, the decision trees algorithm examines how each input attribute in the dataset affects the result of the predicted attribute.  It then uses the input attribute with the strongest relationship to create a series of splits (or nodes or branches).  As new splits are added to the data-mining model, a tree-like structure begins to form.  The top branch of the tree describes the breakdown of the predicted attribute over the entire population of data.  Each additional branch in the tree is created based on the distribution of states of the predicted attribute as compared to the input attributes.  If an input attribute is seen to cause the predicted attribute to favor one state over another state, a new branch is added to the data-mining model.  Again, the first branch in the decision tree represents the greatest difference in the describing dimension or input variable in helping to understand the dependent or predicted variable.  The second split in the decision tree considers the data identified in the first split separately.  The decision tree model continues to grow until none of the remaining input attributes can create a branch that provides an improved prediction over the existing node.  Then, the decision tree is considered created.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Model")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The tree data-mining model seeks to find a combination of input attributes and their states that creates a disproportionate distribution of states in the predicted attribute, thereby allowing prediction of the outcome of the predicted attribute.  Classification trees are designed to sequentially partition the data with the objective of maximizing the difference in the desired dependent variable.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Tree Methodology")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Classification and regression trees method uses a tree methodology that is considered to be performing well across a wide range of situations.  Trees are based on separating customers into subgroups of response variable by creating splits on predictor variables.  In a classification tree algorithm, each split is depicted as a split of a node into two successor nodes.  Figure 6-4 shows the first split step.\n").padding(10)
                        } // Section 4
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-4: First Split Step"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-4.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-4: First Split Step") {
                            self.showingFigure64Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure64Sheet1) {
                            Figure64View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Tree Diagram")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The first step shown in Figure 6-4 is represented by a tree diagram in Figure 6-5.  The tree algorithm represents the first decision node that has successors by circles.  In the Figure 6-5, income is the first split node and shown above the node.  The numbers inside the circles are the splitting values.  The numbers on the left fork (n1) is the number of records that have values less than the splitting value and the numbers in the right fork (n2) is the number of records that have values equal or greater than the splitting value of in the decision node income.\n").padding(10)
                        } // Section 5
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-5: Tree Diagram"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-5.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-5: Tree Diagram") {
                            self.showingFigure65Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure65Sheet1) {
                            Figure65View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Recursive Partitioning")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("This splitting process is repeated until no further possible splits are available using recursive partitioning.  Recursive partitioning is used to construct the tree such that each rectangle is as pure as possible.  Pure in a tree algorithm refers to the condition that all records belong to only one class representing perfect classification.  Purity is typically measured by Gini index or an entropy measure.  The tree algorithm also uses the process of pruning to cut the tree back for optimal classification solution.  To classify a new customer, that new customer is dropped down to the lowest level of node called a terminal node.  If the majority of observations in the training set of that particular terminal node belong to the purchaser, the new customer is classified as a purchaser.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Classification Trree Method")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("When the tree algorithm is applied to categorical response variables, it is called classification tree method.  When the same tree algorithm is applied to continuous response variables, it is called regression tree method.  The classification procedure of the regression tree is similar to that of the classification tree.  The only difference is that the response variable is a continuous variable.\n").padding(10)
                    } // Section 7
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.2 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 6-4 VIEW
// ------------------------------
struct Figure64View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-4: First Split Step")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 6-5 VIEW
// ------------------------------
struct Figure65View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-5: Tree Diagram")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
