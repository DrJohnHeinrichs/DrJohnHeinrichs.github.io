//
//  C06S03T00.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 3: Classification and Prediction Analytic Solution Generation
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S03T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure67Sheet1 = false
    @State private var showingFigure68Sheet1 = false
    @State private var showingTable62Sheet1 = false
    @State private var showingTable63Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.3.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Group {
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Solution Output Example")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In the previous section, the four commonly used classification and prediction methods were introduced.  These four methods provide a similar solution output when these methods are applied.  Therefore, instead of explaining each of the solution examples, one common solution output example is presented and discussed.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Input Data")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("As discussed earlier, in order to generate classification and prediction method solutions, marketing managers first identify input data and split the selected input data into training and validation sets.  Most statistical software tools used by firms offer the input data split with simple specifications.  Using these training and validation datasets, marketing managers should run one of the four methods described in Table 6-1.  Depending on the method selected, input data must be preprocessed to meet the input data scaling requirement of the selected method.  Whichever method marketing managers choose, the analytic output will be similar as the goal is classification and prediction of the membership of new cases to the specified classes.  Table 6-2 shows a solution output for the training dataset.  The training data solution is a part of classification model development.  Table 6-2 solution output includes classification confusion matrix and error report for the training data.  Classification confusion matrix shows how many cases are misclassified in each class.  Error report shows the error rates for each class.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Error Report")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In Table 6-2, marketing managers evaluate the error rates reported in the error report.  The training dataset solution shows error rates of 3.8% and 1.3 % for the class 0 and class 1, respectively.  In this case, class 0 (purchasers) show 3.8 % error rate indicating that 6 purchasers are classified wrongly to the class 1 (non-purchasers).  Class 1 (non-purchasers) show an error rate of 1.3 % showing that 13 non-purchasers are classified as class 0 (purchasers) in the generated classification system.  The overall error rate for the two classes is 1.6%.  These error rates indicate how well the model fits to the training dataset.  These error rates can be considered as acceptable.  However, marketing managers can accept this training model or improve the model by adding new predictor variables or selecting different predictor variables if the provided error rates are not satisfactory.  Through the trial and error process, marketing managers can identify an acceptable classification model.  Although the training model looks reasonable, marketing managers should still validate the classification model by applying the model to the validation dataset.\n").padding(10)
                        } // Section 3
                    } // Group1
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 6-2: Training Data Summary Report"))
                            {
                            Image(uiImage: UIImage(named: "Table-6-2.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 6-2: Training Data Summary Report") {
                            self.showingTable62Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable62Sheet1) {
                            Table62View1()
                        }
                        .padding(10)
                        } // Section 5-1
                    // ----------------------
                    // ----------------------
                    Group {
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Data Summary Report")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Table 6-3 shows an example of validation data summary report.  Typically, the number of records in the validation dataset is smaller than the number of records in the training dataset.  In Table 6-3, the validation data has 800 records while the training data includes 1,200 records.  The validation dataset contains 40 percent of the total records.  Marketing managers can determine whether the trained classification model can be used for classification and prediction for marketing decisions by evaluating the error rates reported in the error report. In Table 6-3, error rates for the validation dataset show 6.7% and 2.8% for the class 1 and class 0, respectively.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Accept / Not Accept")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Class 0 (purchasers) shows 6.7 % error rate indicating that 8 out of 119 purchasers are classified to the wrong class 1 (non-purchasers).  Class 1 (non-purchasers) shows an error rate of 2.8 % showing that 19 of 681 non-purchasers are classified into class 0 (purchasers).  The overall error rate for the two classes is 3.4%.  These error rates indicate the predictive performance and suggest how accurately this classification model can predict the class assignment of new records.  Typically, error rates from the validation dataset are higher than error rates of the training dataset because the model is developed using the training set.  The decision whether to accept the classification and prediction mode as acceptable depends on the marketing managers and decision task at hand.  Marketing managers can use set criteria such as 1% or 5%.  Marketing managers may choose the best classification and prediction model among several models generated using different predictor variables.\n").padding(10)
                        } // Section 5
                    } // Group 2
                        // ----------------------
                        // ----------------------
                    Section (header: Text("Table 6-3: Validation Data Summary Report"))
                        {
                        Image(uiImage: UIImage(named: "Table-6-3.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale3, body: { (value, scale3, trans) in
                                scale3 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Table 6-3: Validation Data Summary Report") {
                        self.showingTable63Sheet1.toggle()
                    }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable63Sheet1) {
                        Table63View1()
                    }
                    .padding(10)
                    } // Section 5-1
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Lift Chart")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("To help marketing managers make the decision whether to accept and to use the classification model for targeting and other marketing decisions, these error rates are presented graphically.  This graphic presentation is called lift chart.  A lift chart is a graphical presentation of predictive performance.  Figure 6 7 shows an example of lift chart.  A lift chart compares the model’s predictive performance of the validation dataset to a baseline model with no predictors.  The lift chart shows the cumulative value of the set of records ordered by their predicted value, from high to low on the y-axis and the number of records accumulated on the x-axis.  The model performs better if the lift curve is farther away from the baseline model.  This means that the model can separate records with high-value outcomes from those with low-value outcomes well.\n").padding(10)
                        } // Section 6
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-7: Lift Chart Example"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-7.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-7: Lift Chart Example") {
                            self.showingFigure67Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure67Sheet1) {
                            Figure67View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Decile Lift Chart")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In addition to lift chart, another graphic presentation useful for marketing managers is a decile lift chart.  In a decile lift chart, the ratio of model lift to baseline model for each decile is presented on the y axis while the ordered records grouped into 10 deciles are presented on the x axis.  The first decile value of 1.6 indicates that choosing the top 10% of the objects based on the lift curve will be 1.6 times more effective than randomly choosing 10% of the objects using the baseline model.\n").padding(10)
                        } // Section 7
                        // ----------------------
                        // ----------------------
                        // ----------------------
                    Section (header: Text("Figure 6-8: Decile-wise Lift Chart"))
                        {
                        Image(uiImage: UIImage(named: "Figure-6-8.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale4)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale4, body: { (value, scale4, trans) in
                                scale4 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Figure 6-8: Decile-wise Lift Chart") {
                        self.showingFigure68Sheet1.toggle()
                    }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure68Sheet1) {
                        Figure68View1()
                    }
                    .padding(10)
                    } // Section 5-1
                    // ----------------------
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.3 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 6-7 VIEW
// ------------------------------
struct Figure67View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-7: Lift Chart Example")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-7.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-7 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 6-8 VIEW
// ------------------------------
struct Figure68View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-8: Decile-wise Lift Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-8.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-8 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 6-2 VIEW
// ------------------------------
struct Table62View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 6-2: Training Data Summary Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-6-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 6-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 6-3 VIEW
// ------------------------------
struct Table63View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 6-3: Validation Data Summary Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-6-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 6-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
