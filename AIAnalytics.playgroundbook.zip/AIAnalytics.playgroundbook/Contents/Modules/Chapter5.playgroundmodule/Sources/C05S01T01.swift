//
//  C05S01T01.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 1: Market Segment Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Customer Segment Analytics
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Profile and Segmentation")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Finding the right customers involves both profiling and segmentation.  A profile is defined as a collection of information about a single customer.  Segmenting is defined as dividing the customers or consumers into various groupings of mutually exclusive categories.  These categories or groupings exhibit similar responses to the firm’s marketing strategy.  Both profiling and segmenting, however, provide marketing managers with different insights.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Profiling Approaches")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In understanding the customer needs, requirements, preferences, and interests, two alternative approaches to profiling have emerged.  These two approaches to profile development are labeled personal profiling and social profiling.  A personal profile can be developed based on personal information provided by each individual customer through traditional and web-based survey responses, product registration, and/or web click-stream activities.  A social profile can be developed by profiling the community to which that individual belongs.  In social profiling, preferences are identified through common interests of the community that a customer or consumer belongs and the interacting members in that community.  When a product or service is found by a member of the community, every member in the community with a similar profile is alerted to the available information.  For example, Amazon.com uses social profiling by offering reviews of a book by other readers and providing book recommendations based on purchase patterns of purchasers with similar social profiles.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Social Profile")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The social profile can be used to determine customer needs, requirements, preferences, and interests as well.  These common types of profiling originated in the catalog industry.  RFM (Recency, Frequency, Monetary) factors are used to segment customers based upon their buying behavior and are used to identify high-value customers.  The recency factor is defined as the number of months since the last purchase; the frequency factor is defined as the value of the number of purchases made; and the monetary factor is defined as the value of the total dollar amount of the purchases made.  So, RFM factors provide a view of customers based upon the last time they purchased, how often they purchased, and how much they purchased.  Thus, profiling enables marketing managers to identify consumers and demographic groups.  Profiling can help marketing managers identify the interests and preferences of specific individuals as well.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Segmentation")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Segmentation is used to identify segments or groupings within variable categories.  Segmentation is an analytical procedure by which predictor variables are split into subgroups that impact or explain variation in the target variable.  It is used to gain more detailed knowledge of cause and effect between variables and the target.  Applications include response profiles, customer profiles, profit profiles, and process profiles.  Marketing managers could explore the question, “Does age or income level really influence the consumer’s purchasing habits?”.  If the analyst discovers this to be true, then the analyst can ask, “What are the significant segments that require further analysis?”.  However, with the segmentation technique, the analyst is unable to perform sensitivity analysis or to conduct forecasting of future events.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Decision Tree")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("How can the marketing managers use the segmentation technique?  The marketing managers can use the decision tree algorithm to decide which consumers should be focused on.  For example, the marketing managers can segment all customers by age (0-25, 25-55, 55+), by gender (male, female), or by region (North, East, South, West).  The marketing managers can identify exceptional customers who do not fit well into their expected group.  As such, segmentation can be data-driven or market-driven.  Data-driven segmentation uses characteristics that are determined to be important drivers of the firm.  Market-driven segmentation uses techniques such as cluster analysis or factor analysis to find homogenous groups.  An example of market-driven segmentation is “Life Stages”.  Life stages are patterns that change over time.  The consumers are clustered into groups defined by demographics such as age, gender, and marital status as they progress through various life stages.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Segmentation Scheme")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("One marketing task that all marketing managers are facing is developing and implementing a successful market segmentation scheme for a given product or service.  Such effective segmentation provides strategic guidelines for the firm and helps marketing managers make various marketing decisions.  It also helps firms to determine the right product-market relationship.  The analytic question relevant to this task is how to identify groups of customers who are relatively homogeneous with respect to their responses to market offerings.  It is important for marketing managers to answer the analytic questions of how to group potential customers into homogeneous groups that are large enough to be profitable.  This type of decision must be data-centered and focused on a fact-based decision-making process.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.1 Market Segment Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
