//
//  C05S02T00.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 2: Clustering Analytics Generatioon
//
//  Created by SBAMBP on 04/14/2020
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S02T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure51Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Cluster Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("To answer the analytic questions of grouping potential customers into homogeneous segments, marketing managers can select cluster analysis from the analytics toolbox.  The most common approach for segmentation is cluster analysis.  Cluster analysis is a class of statistical techniques generating natural groupings based on the entire set of interdependent variables.  Cluster analysis uses customer raw data and generates groups of relatively homogeneous customers.  Using measures of similarity between customers such as correlation coefficients, distance measures, and association coefficients, cluster analysis determines and maps the number of clusters.  Each cluster contains customers similar in characteristics.  Managers can determine which clusters to target based on the profile and behavioral properties of each identified cluster.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Undirected Data-Mining Technique")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Clustering is a data-mining approach or technique that can be used to identify relationships between groups of data and then to position these groups of data.  The clustering algorithm is a low-level investigation of large amounts of data.  With the clustering data-mining model, marketing managers are seeking to discover hidden relationships in the data without directing the analysis one way or another.  Thus, clustering is typically referred to as an undirected data-mining technique as it creates clusters or groups and is not used in predicting an outcome.  The clustering algorithm identifies groupings of similar variables without the incorporation of a target variable.  The mathematical concept used in this technique is to divide the data into groups with similar characteristics.  The clustering algorithm uses iterative techniques to group records into clusters containing similar characteristics.  Using these clusters, the data can be further explored by the analyst to facilitate learning about the various relationships that exist in the data that may not be easily detected from simple casual observation.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Directed Data-Mining Technique")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("However, predictions can be created from the clustering data-mining model as well.  This enables this technique to be used as a directed data-mining technique.  For example, consider a group of people who live in the same neighborhood, drive the same kind of car, eat the same kind of food, and buy a similar version of a product.  This becomes a cluster or grouping of data.  Another cluster may include people who go to the same restaurants, have similar salaries, and vacation twice a year outside the country.  Observing how these clusters are distributed in the data facilitate the marketing manager in developing an understanding of how the various data records interact, as well as how that interaction affects the outcome of a predicted attribute.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Use of Cluster Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("One of the important uses of cluster analysis has been identifying aggregates of customers who behave similarly.  Cluster analysis deals with how objects or people should be assigned to groups such that there will be as much similarity within and difference among groups as possible.  In cluster-based segmentation, the number and type of segments are not known in advance.  The cluster-based analytics approach utilizes a design that identifies segments based on a clustering of respondents on a set of relevant variables.  Marketing managers need to identify bases for clustering that include customers’ attitude towards product characteristics, benefits sought, use situations, and other attributes.  Demographic data is also identified to describe the cluster members for the purpose of profiling.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Steps to Perform Cluster Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Cluster analysis is performed following certain steps.  Figure 5 1 shows the steps needed to generate clustering analytics solutions.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Button("Click to highlight ... Figure 5-1: Clustering Analytics Solution Generation Steps") {
                        self.showingFigure51Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure51Sheet1) {
                        Figure51View1()
                    }
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.2 Segment Clustering Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 5-1 VIEW
// ------------------------------
struct Figure51View1: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 5-1: Clustering Analytics Solution Generation Steps")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-5-1.jpg")!)
//                    Image("Figure-5-1.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 5-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
