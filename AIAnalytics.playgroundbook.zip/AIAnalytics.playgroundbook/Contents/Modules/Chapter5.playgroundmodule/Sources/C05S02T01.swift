//
//  C05S02T01.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 2: Segment Clustering Analytics Generation
//
//  Created by SBAMBP on 04/14/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Code Input Attributes
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Clustering Steps Decisions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers need to make decisions on each of the clustering steps considering the analytic questions on hand.  The first decision marketing managers need to make is which attributes to be used for clustering analysis.  Typically, the cluster analysis is applied to a large sample of data consisting of many attributes or variables.  As the cluster analysis searches through the data and identify customers who show identical or similar pattern of values, it is important to select the right attributes for the effective natural groupings.  Changes in the selected attributes can lead to changes in the natural groupings that exist in the customers.  Therefore, the choice of attributes or variables is one of the most critical decisions marketing managers need to make in performing the cluster analysis.  The issue is to find a set of variables that make sense conceptually within the context of marketing theory and managerial decisions.  The variable selection decision should not be based on convenience or availability of data.  The types of variables used for cluster analysis are scaled data typically recorded on scales such as 5 or 7 point scales.  Continuous data or categorical data can also be used for cluster analysis however, it is used less frequently.  For these types of data, additional coding may be necessary before moving to the next step of generating distance estimates to assess similarity.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Psychographic Variables")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The commonly selected input attributes are psychographic variables, product benefits sought, and attitudes towards both new and established products.  Psychographic measures allow managers to classify customers with respect to their lifestyle characteristics such as activities, attitudes, interests, beliefs, and opinions.  Customers are usually asked to indicate the extent to which they agree or disagree with a series of statements.  These statements are designed to measure specific attitudes, opinions, or beliefs that marketing managers are interested in.  Similarly, marketing managers can generate responses to measure product benefits sought and other attributes of interest.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.2 Segment Clustering Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
