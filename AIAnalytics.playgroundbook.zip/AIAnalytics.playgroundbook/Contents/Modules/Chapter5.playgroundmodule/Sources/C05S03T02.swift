//
//  C05S03T02.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 3: Clustering Analytics Interpretation and Application
//
//  Created by SBAMBP on 04/14/2020
//  Updated by SBAMBP on 04/15/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S03T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure57Sheet1 = false
    @State private var showingTable52Sheet1 = false
    @State private var showingTable53Sheet1 = false
    @State private var showingTable54Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- K-means Clustering Analytics Interpretation and Application
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Running the selected clustering procedure on the input data, a set of clusters will be obtained.  Regardless of the nature of data, clustering procedures can always produce clusters.  An important issue is whether the obtained clusters reflect some natural or compelling structure in the data.  Marketing managers may have pre-conceived or pre-determined number of clusters.  In this case, marketing managers can run the k-means clustering procedure for a solution.  After getting the clustering solution, marketing managers must examine the solution and determine the usefulness of the obtained clusters for marketing decisions.  Figure 5-4 shows an example of k-means clustering solution that identifies four clusters (k = 4).\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Table 5-2: Cluster Summary") {
                            self.showingTable52Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable52Sheet1) {
                            Table52View1()
                        }
                        // ----------------------
                        Button("Click to highlight ... Table 5-3: Cluster Summary") {
                            self.showingTable53Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable53Sheet1) {
                            Table53View1()
                        }
                        // ----------------------
                        Button("Click to highlight ... Table 5-4: Cluster Summary") {
                            self.showingTable54Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable54Sheet1) {
                            Table54View1()
                        }
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("\n").padding(10)
                            Image("Group-5-1.jpg")
                        // ----------------------
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Figure 5 4 shows the k means clustering summary for k = 4.  In using k means clustering, marketing managers must select k for generating the clustering solution.  However, clustering analysis does not provide the number of clusters that is appropriate for the data.  Marketing managers may need to select k arbitrarily.  To resolve this critical issue, marketing managers can use the commonly used approach of the elbow plot to determine the appropriate number of clusters in the data.  The elbow plot helps marketing managers determine the appropriate number of clusters.  Marketing managers can choose a number of clusters when adding another cluster does not add the explanatory power of clustering solution.  The elbow plot is created by plotting the ratio of the within cluster variance to the between cluster variance against the number of clusters.  In order to generate the elbow plot, marketing managers need to run cluster analysis for k is 1 through 7 or more k values.  After generating 7 or more clustering solution, the elbow plot can be drawn.  The logic behind the elbow plot is that cluster analysis generates the best solution that minimize the within cluster variance and maximizes the between cluster variance.  The ratio of the within cluster variance to the between cluster variance will decrease when the number of clusters is increasing.  Marketing managers can select the number of clusters until this ratio does not decrease enough with the increase of the number of clusters (indicated as an angle in the graph).  Figure 5 7 shows the elbow plot where k is 1 through 7.  The elbow plot shows an angle when k = 5.  This suggests that the number of clusters most appropriate for the given data is 5.  Marketing managers can use the clustering solution generated with k = 5.\n").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 5-7: Elbow Plot") {
                            self.showingFigure57Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure57Sheet1) {
                            Figure57View1()
                        }
                        Text("\n").padding(10)
                    } // Section 3
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.3 Clustering Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 5-7 VIEW
// ------------------------------
struct Figure57View1: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 5-7: Elbow Plot")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image("Figure-5-7.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 5-7 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 5-2 VIEW
// ------------------------------
struct Table52View1: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 5-2: Cluster Summary")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image("Table-5-2.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 5-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 5-3 VIEW
// ------------------------------
struct Table53View1: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 5-3: ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image("Table-5-3.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 5-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 5-4 VIEW
// ------------------------------
struct Table54View1: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 5-4: ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image("Table-5-4.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Table 5-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
