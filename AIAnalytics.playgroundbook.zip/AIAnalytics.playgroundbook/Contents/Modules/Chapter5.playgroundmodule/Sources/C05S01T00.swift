//
//  C05S01T00.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 1: Market Segment Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Segmentation and Targeting")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Market segmentation and targeting analysis is the process of dividing an entire market into different segments and then deciding which markets to target or which potential segments the firm will focus on.  This can depend of lifestyles, demographic areas, common needs, interests, characteristics, and much more.  This is important to determine the other marketing activities such as price, distribution, promotion, and product.  Each segment needs to be approached in different ways.  A problem marketing managers could face when deciding which markets to segment and target is identifying the right technologies.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Targeting")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Deciding what customers/markets to target is a problem that marketing managers at any firm face at some point.  Customers that are profitable and want or need a product or service that the firm offers are ideal candidates.  Successful implementation of the marketing strategy requires a detailed understanding of those customers and how they are segmented.  Marketing managers can come across the problem that they may be marketing to the wrong customers or to the wrong markets.  Targeting the wrong customers wastes the firm’s marketing dollars and decreases overall profit because nobody that really wants what you offer knows about your product or service.  Knowing different techniques to target the right customers at the right time with the right media will help ensure the firm has a competitive advantage.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Market Segmentation")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The marketing objectives in segmentation analysis are to reduce the risk in deciding where, when, how, and whom a product or service will be marketed to as well as to increase efficiency by directing the most resources and marketing initiatives toward the designated segment(s).  Some benefits of market segmentation are better serving customers’ needs and wants, purchasing power by price differentiation, attracting additional customer groups, sustainable customer relationships, and higher market shares.  Even with a limited product range it can seem possible to target a variety of customers.  Just using different forms, bundles, incentives, or promotional items associated with the product can make it effective in different markets.\n").padding(10)
                    } // Section 3
                    // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.1 Market Segment Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
