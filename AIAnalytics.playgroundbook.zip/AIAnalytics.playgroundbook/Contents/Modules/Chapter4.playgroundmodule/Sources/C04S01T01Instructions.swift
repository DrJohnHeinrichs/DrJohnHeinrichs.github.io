//
//  C04S01T01Instructions.swift
//  Book_Sources
//
//  Chapter 4: Visualization Tools for Marketing Environment Analytics
//  Section 1: Marketing Environment Analytics Task
//
//  Created by SBAMBP on 04/04/20.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public struct C04S01T01Instructions: View {

    @State private var isShowingRed = false
    @State private var animationAmountSpin = 0.0

    public init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 26)!]
    } // init

    public var body: some View {
        VStack {
            Button(action: {self.isShowingRed.toggle()}){
                Text(self.isShowingRed ? " " : "Click to open ... \n\nInteractive Playground Instructions")
                .font(.largeTitle)
                .fontWeight(.semibold)
                .foregroundColor(.black)
            } // Button
                .padding(10)

            if isShowingRed {
                VStack {
                    Text("Interactive Playground Instructions")
                        .font(.largeTitle)
                    Text("Use this Interactive Playground to explore visualization tools for marketing environment analytic tasks .\n\n The key questions analysts can answer include:\n\n1. What  ?\n2. How ?\n3. Given various options, what is the best possible outcome?")
                        .font(.body)
                    HStack{
                        
                        Text("Now, click ... ")
                        Image(systemName: "arrowtriangle.right.fill")
                        Text("  Run My Code")
                        .font(.headline)
                    }
                } // VStack
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .center)
//                    .background(Color.white)
            } // if

        } // VStack
    } // body
} // struct
// ---------------------
// ---------------------
