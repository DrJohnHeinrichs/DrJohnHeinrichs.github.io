//
//  C04S02T05.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 05: Graphic Display Visualization Chart Type
//
//  Created by SBAMBP on 04/12/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T05: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 5: Start --- Graphic Display Visualization Chart Type
        // ------------------------------
        NavigationView {
            List {
                // ----------------------
                Text("4.2.5 Graphic Display Visualization Chart Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Text("Two types of graphic display visualization chart types include tthe geospatial map and the spiral chart.").padding(10)
                    // ----------------------
                    NavigationLink(destination: GeospatialMap()){
                        Text("Geospatial Map")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: SpiralChart()){
                        Text("Spiral Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: LINE CHART
// ------------------------------
public struct GeospatialMap: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Geospatial Map")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Managers can display data of interest on a map.  With any kind of location data such as postal codes, state name, or country name, maps can be used to show attribute values of interest.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: SPIRAL CHART
// ------------------------------
public struct SpiralChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Spiral Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Spiral charts display movement from initial to final stage and the changes along the path.  Spiral charts are used to show trends or large datasets over a period of time.  Spiral charts can present bars, lines, or points along the spiral line.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
