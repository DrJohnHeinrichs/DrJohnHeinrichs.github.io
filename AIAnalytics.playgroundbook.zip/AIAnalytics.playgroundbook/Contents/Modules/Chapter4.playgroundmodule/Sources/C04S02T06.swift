//
//  C04S02T06.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 06: Dashboard Report Visualization Tool
//
//  Created by SBAMBP on 04/12/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T06: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable42Sheet1 = false
    @State private var showingTable43Sheet1 = false
    @State private var showingTable44Sheet1 = false
    @State private var showingTable45Sheet1 = false
    @State private var showingTable46Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0
    @GestureState var scale5: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 6: Start --- Dashboard Report Visualization Tool
        // ------------------------------
        NavigationView {
            ScrollView {
                    // ----------------------
                    Text("4.2.6 Dashboard Report Visualization Tool").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Dashboards")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("A dashboard is a form of business report that utilizes analytics visualization.  A dashboard is a data visualization tool that presents a range of different performance indicators on one page like a dashboard in a car.  Dashboards show multiple numerical values with automatic updates when new data become available.  Dashboards provide the important performance information that managers can quickly access for decision making.  Dashboards provide a set of predefined charts and tables with the possibility of customizing them with target metrics.  Key performance indicators are highlighted with color.").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Dashboard Design")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Dashboards should be clean and simple with not too many colors.  Dashboards must be designed for usability and effective aid for decision-making.  While most dashboards look professional and well-designed aesthetically, what is important is what types of data and information are displayed and the validity of information displayed.  Dashboards must present the right metrics that managers are interested in tracking and using in decision-making.  The metrics need to be presented with industry benchmark data so that managers can understand how well they are doing relative to their major competitors.  In addition, the presented metrics must be reliable, timely, complete, and consistent.  In dashboards, alerts and exceptions are generated for the managers.  These alerts and exceptions must be those detected critical patterns or incidents that require the immediate attention of managers.  For these reasons, alerts and exceptions are information that requires the immediate attention of managers.  Alerts and exceptions also need to be prioritized and ranked for streaming to the dashboard.  Depending on the nature and importance of information, the information can be presented as a visual dashboard metric, static report, or self-service analytics.  The guided analytics allows typical managers experience the analytic path that is used by analytically savvy marketing managers.  The next section discusses the guided analytics.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Generated Solutions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("While the generated analytic solution should provide answers to the current managerial problem at hand, it can also be used for other managerial problems.  The insights generated can be applied to other decision areas.  This application can occur at the time when the solutions are generated.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Guided Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("As these generated solutions are stored in the firm, the application can occur later when a decision problem calls for the same type of analytic solutions.  The dashboard analytics can provide graphs, charts, tables, diagrams, formulas, and statistical outputs.  These results are presented in the dashboard or in customized report format.  Some of the analytic modules and processes can be saved as a customized solution.  These solutions and related modules can be retrieved later for additional use.  After generating analytic results and reports, managers should generate insights.  In generating additional insights marketing managers may need to reassess the problem and may want to generate additional analytical solutions to gain further insights and greater understanding.  These insights would lead to valuable strategic and tactical directions for the firm.  In performing this interactive process of insight generation, guided analysis can be utilized.  Guided analysis provides answers to the pre-determined sets of questions typically used by marketing managers of a particular firm in making marketing decisions.  The provided answers are typically visualization results.  Various forms of charts and tables are provided to marketing managers for effective decision-making.  Guided analysis is available for the marketing manager.  Tables 4-2 through 4-5 show a guided analysis example that includes the various categories that can be chosen and the various questions that prompt the manager.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Guiding Questions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The various questions and categories can be generated.  These questions can be generic, industry specific, company specific, or manager specific questions.  One important point of marketing analytics and business intelligence application is the need of understanding the importance of customization.  The typical guided analysis screen can provide the manager with a visual review of the answer and provide a text description of the purpose of the prompt.  The following set of prompting questions presents a sample list of guided analysis questions for strategic market planning.\n").padding(10)
                        // ----------------------
                        // ----------------------
                        // ----------------------
                        // ----------------------
                        Group {
                        // ----------------------
                        Section (header: Text("Table 4-2: Sample List of Guided Analysis Questions for Brands and Products (BP)"))
                            {
                            Image(uiImage: UIImage(named: "Table-4-2.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 4-2: Sample List of Guided Analysis Questions for Brands and Products (BP)") {
                            self.showingTable42Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable42Sheet1) {
                            Table42View1()
                            }.padding(10)
                        } // Section 5-1
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 4-3: Sample List of Guided Analysis Questions for Customer Performance (CP)"))
                            {
                            Image(uiImage: UIImage(named: "Table-4-3.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 4-3: Sample List of Guided Analysis Questions for Customer Performance (CP)") {
                            self.showingTable43Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable43Sheet1) {
                            Table43View1()
                        }.padding(10)
                        } // Section 5-1
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 4-4: Sample List of Guided Analysis Questions for Market Review (MR)"))
                            {
                            Image(uiImage: UIImage(named: "Table-4-4.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale3)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale3, body: { (value, scale3, trans) in
                                    scale3 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 4-4: Sample List of Guided Analysis Questions for Market Review (MR)") {
                            self.showingTable44Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable44Sheet1) {
                            Table44View1()
                        }.padding(10)
                        } // Section 5-1
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 4-5: Sample List of Guided Analysis Questions for Promotional Effectiveness (PE)"))
                            {
                            Image(uiImage: UIImage(named: "Table-4-5.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale4)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale4, body: { (value, scale4, trans) in
                                    scale4 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 4-5: Sample List of Guided Analysis Questions for Promotional Effectiveness (PE)") {
                            self.showingTable45Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable45Sheet1) {
                            Table45View1()
                        }.padding(10)
                        } // Section 5-1
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Table 4-6: Sample List of Guided Analysis Questions for Personal Questions (PE)"))
                            {
                            Image(uiImage: UIImage(named: "Table-4-6.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale5)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale5, body: { (value, scale5, trans) in
                                    scale5 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Table 4-6: Sample List of Guided Analysis Questions for Personal Questions (PE)") {
                            self.showingTable46Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable46Sheet1) {
                            Table46View1()
                        }.padding(10)
                        } // Section 5-1
                        // ----------------------
                        } // Group
                        // ----------------------
                        // ----------------------
                        // ----------------------
                        // ----------------------
                    } // Section 5
                // ----------------------
                // ----------------------
                // ----------------------
                // ----------------------
                // ----------------------
                // ----------------------
            } // ScrollView -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 6: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 4-2 VIEW
// ------------------------------
struct Table42View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-2: Sample List of Guided Analysis Questions for Brands and Products (BP)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 4-3 VIEW
// ------------------------------
struct Table43View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-3: Sample List of Guided Analysis Questions for Customer Performance (CP)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 4-4 VIEW
// ------------------------------
struct Table44View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-4: Sample List of Guided Analysis Questions for Market Review (MR)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 4-5 VIEW
// ------------------------------
struct Table45View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-5: Sample List of Guided Analysis Questions for Promotional Effectiveness (PE)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 4-6 VIEW
// ------------------------------
struct Table46View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-6: Sample List of Guided Analysis Questions for Personal Questions (PE)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
// ------------------------------------------
// ------------------------------------------
