//
//  C04S03T02.swift
//  Book_Sources
//
//  Chapter 04 Section 03: Topic 02: Relationship Chart Application
//
//  Created by SBAMBP on 04/13/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S03T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure48Sheet1 = false
    @State private var showingFigure49Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 2: Start --- Relationship Chart Application
        // ------------------------------
        NavigationView {
            ScrollView {
                    // ----------------------
                    Text("4.3.2 Relationship Chart Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Relationship")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers need to visualize the pattern of relationship.  They are interested in visualizing the increase, decrease, change, or varying degree of a measure.  The commonly used chart type is a scatter plot.").padding(10)
                        }
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Analysis Results")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        Text("Figure 4-8 presents a scatter chart showing “net sales % growth” and “profit % growth” of the five major product lines of a firm.  In this case, the target metrics used for this chart are two revenue measures of net sales % growth and profit % growth calculated from net sales and profit over time.  The y-axis represents the profit % growth and the x-axis represents the net sales % growth.  The color and shape were used to represent the visual difference among product lines.  The classification metric is the product line that includes deodorants, hair care, oral care, shaving, and skin care product.  In assessing product performance, the sales growth of each product line can be evaluated.  This visualization chart shows both negative sales and profit growth indicating that all five product lines are not doing very well in terms of sales and profit.  The analysis results imply that management should make a drastic change in their marketing strategy to stop this downward spiral of sales and profit decline.  The firm needs complete competitive and situation assessments to find the source of this decline.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-8: Product Line Net Sales Scatter Chart") {
                            self.showingFigure48Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure48Sheet1) {
                            Figure48View1()
                        }.padding(10)
                        }
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Scatter Chart Insights")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                        // ----------------------
                        Text("Figure 4-9 presents a scatter chart that shows “% Sales Growth” and “% Total Net Sales”.  In this case, the target metrics used for this chart are two revenue measures of % total net sales and % sales growth calculated from net sales and sales over time.  The y-axis represents the % total net sales and the x-axis represents the % sales growth.  The color and shape were used to represent the visual difference among market regions.  The classification metric is the market regions that include the East, Midwest, South, West, and Key accounts.  The chart shows that the Midwest region is growing at a rate of over 100 percent in a product line.  All other regions, however, exhibit negative sales growth in the given product line.  Managers need to develop modified marketing strategies for all regions other than the Midwest region.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-9: Market Net Sales Scatter Chart") {
                            self.showingFigure49Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure49Sheet1) {
                            Figure49View1()
                        }.padding(10)
                        // ----------------------
                    } // Section 1
                    // ----------------------
            } // ScrollView -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.3 Visualization Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 4-8 VIEW
// ------------------------------
struct Figure48View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-8: Product Line Net Sales Scatter Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-8.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-8 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-9 VIEW
// ------------------------------
struct Figure49View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-9: Market Net Sales Scatter Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-9.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-9 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
