//
//  C04S02T02.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 02: Relationship Visualization Chart Types
//
//  Created by SBAMBP on 04/12/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 2: Start --- Relationship Visualization Chart Types
        // ------------------------------
        NavigationView {
            List {
                    // ----------------------
                Text("4.2.2 Relationship Visualization Chart Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)

                    Text("The following chart types can be used for comparison and contrast purposes.\n").padding(10)
                    // ----------------------
                    NavigationLink(destination: ScatterChart()){
                        Text("Scatter Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: NetworkChart()){
                        Text("Network Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: SCATTER CHART
// ------------------------------
public struct ScatterChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Scatter Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Scatter plots show relationships between two or more variables.  As a visual exploration tool, scatter plots are very effective in exploring trends, concentrations, and outliers in a dataset.  Although it is a useful visualization tool, its use is limited to no more than three dimensions because it is difficult to display more than three dimensions in a single plot.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: NETWORK CHART
// ------------------------------
public struct NetworkChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Network Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Network charts display interconnections between a set of entities.  Each entity is represented by a node and connection between nodes that are represented through links.  Network charts show how things are interconnected using nodes and link lines to highlight the type of relationships between entities.  They can help managers interpret the structure of a network by evaluating the layout of nodes, density of links, and clustering of nodes.  These charts can be used for a limited data capacity where there are not too many nodes in a chart.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
