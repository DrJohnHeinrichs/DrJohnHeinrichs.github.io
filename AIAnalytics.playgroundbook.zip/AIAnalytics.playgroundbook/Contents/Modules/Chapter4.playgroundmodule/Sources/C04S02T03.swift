
//
//  C04S02T03.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 03: Tabulation Visualization Chart Type
//
//  Created by SBAMBP on 04/12/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T03: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 3: Start --- Tabulation Visualization Chart Type
        // ------------------------------
        NavigationView {
            List {
                    // ----------------------
                Text("4.2.3 Tabulation Visualization Chart Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Text("Tables are used when managers want to display specific numerical values and comparisons between values.  Many types of tables can be used depending on the number of variables and analytic questions managers are facing.  When managers want to describe data of two variables, cross tabulation can be used.  Cross tabulation presents two variables in a table format.  Additional variables can be added to the table.  Cross tabulation is also considered as a pivot table.\n\nIn pivot tables, highlight tables are used to highlight table values with gradients of colors with a number on top to provide additional details.  Similarly, sparklines display a row or a column of data in a single cell with a different color.").padding(10)
                    // ----------------------
                    NavigationLink(destination: PivotTables()){
                        Text("PivotTables")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: PivotChart()){
                        Text("PivotChart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: PIVOT TABLE
// ------------------------------
public struct PivotTables: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("PivotTable")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A variety of tools can be used by the marketing manager to understand the existing data.  The PivotTable and PivotChart reports help the manager understand the data by permitting rapid shifting of dimensions, filtering data, and adding facts and measures to the analysis grid or chart.  The layout for the PivotTable report allows the marketing manager to specify the data or facts to be displayed, the dimensions to be analyzed as either the row or column, and other dimensions to act as off grid filters.  The available measures or dimensions for the rows, columns, page or data area are displayed on the right side of the screen.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: PIVOT CHART
// ------------------------------
public struct PivotChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("PivotChart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A PivotChart report provides the marketing manager with the ability to perform interactive analysis of the data and display the analysis in a chart format.  The various views of the data can be changed thus enabling the marketing manager to uncover different levels of detail.  Marketing managers can explore the data by changing the chart layout by dragging fields or dimensions onto the chart.  The PivotChart report works in conjunction with the PivotTable.  Thus, the PivotTable provides the data used by PivotChart report.  Since the two tools work together, when the marketing manager changes the information layout in one tool, the information layout in the other tool also changes.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
