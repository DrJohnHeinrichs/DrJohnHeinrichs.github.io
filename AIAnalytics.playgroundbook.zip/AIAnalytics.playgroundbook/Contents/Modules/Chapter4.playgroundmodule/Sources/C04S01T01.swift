//
//  C04S01T01.swift
//  Book_Sources
//
//  Chapter 04 Section 01: Topic 01: Market Trend Analytics
//
//  Created by SBAMBP on 04/07/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Market Trend Analytics
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("4.1.1 Market Trend Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Focus")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Market trend analytics provides focus for evaluating the market and the industry.  The nature and scope of the market can be assessed in this context; whereas industry characteristics are also of interest to the marketing managers with respect to trends and changes in the value chain for the industry.  Environmental scanning provides continuous scanning information about the political, economic, social, and technological environmental forces highlighting emerging trends that can potentially influence marketing performance.  Different firms confront unique blends of these environmental forces.  The most critical environmental force includes economic factors affecting customers and value chain participants within the served market.  The political nature of regulation and deregulation actions on industries such as trucking, communications, or utilities can create new markets or eliminate existing markets.  The social environment concerns cultural trends such as life styles, value system, or habits.  It also encompasses demographic changes such as age, education, and geographical location.  The technological environment deals with the development and use of product technology, process technology, and other supporting technologies.\n").padding(10)
                    } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Long-term Opportunities")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                            Text("In generating the market trend analytics, the first task is to analyze the long-term opportunities available to the firm.  Managers must be able to determine if either an abundance or a lack of opportunities exists.  The determination of these opportunities will allow the marketing manager to decide what the long-term goal of the firm is.  The desired solutions from this analysis include determining the reasons for the growth (or decline) in the identified market, the overall industry capacity utilization for the available plant and equipment, and the redefinition of the current market segments according to the perceived major current and projected trends.  To help focus the marketing managers’ investigation into the external environment and assist them in insight generation, three key prompting concepts or questions are used to guide the marketing managers.  The prompting questions include:\n").padding(10)
                            VStack (alignment: .leading, spacing: 10) {
                                Text("\u{2022}  What are the major trends that will affect our identified market in the future?").italic().padding(5)
                                Text("\u{2022} What are the most important market segments to the firm’s future success?").italic().padding(5)
                                Text("\u{2022} What affect will the projected trends have on each of our identified market segments?").italic().padding(5)
                            }
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Market Scope")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                            Text("To accomplish these objectives and to answer the prompting questions requires the marketing managers to complete various tasks and activities.  The marketing managers must define the market scope.  Defining and identifying the market scope is accomplished by analyzing the market or industry economic drivers, analyzing the barrier costs to entry into the identified marketplace, and determining how the firm can generate profits in this defined market segment.  The marketing managers must perform this analysis and store the identified information regarding the market segments and product segments for future use.  Ultimately, the marketing managers must clearly define the segments in which the firm has decided to participate.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Analytic Solutions")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                            Text("These analytics solutions include a variety of generated outputs and require various inputs to create the desired outputs.  These analytics solutions provide long-term market growth (decline) projections, identify the major market forces acting on the segments, create plausible market force scenarios for use by marketing managers, describe the product life cycle of the various product and service classes in the market, detail expected changes in the product and service segment mix, assess the firm’s competitive strengths and weaknesses, and identify competencies and capabilities that are required to succeed in the market.  The input data may include information from the customer interface or relationship personnel to obtain regional trends and customer feedback, information from supplier interface or relationship personnel to obtain financial trends and stability of the supplier organizations, and operational results from the firm’s online transaction systems.  Key trends include world and regional economic trends and forecasts, industry associated data trends, market research information as well as service, product, and regional sales results.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Ongoing Activities")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                            Text("Marketing managers perform an ongoing competitive advantage assessment, monitor technology development trends, report on research and development effectiveness, evaluate opportunity, and determine potential merger and acquisition candidates as well as perform forecasting and trend analysis.  These activities provide the firm with an understanding of the growth (decline) of the industry, the level of barriers to enter into and exit from a given market or market segment, the degree of product and service differentiation, the cost of maintaining and developing the brand equity, and the level of switching costs.\n").padding(10)
                        } // Section
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Market Analysis")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            // ----------------------
                            Text("Market analysis can be performed by marketing managers using the firm’s analytical tools and the firm’s accumulated big data.  In addition, AI-driven analytics can also provide important trend information using artificial intelligence and machine learning.  For example, IBM Watson provides marketing managers important market trend analytics through its “Discovery News” tool.  Discovery news service performs aggregate analysis to detect trends and patterns using news and blogs that identifies important meta-information such as authors, publication dates, relevant key words, concepts, sentiment, and relationships.  Discovery news can identify anomalies, key events, and latest information and changes about events, product and brand perceptions, as well as competitors.\n").padding(10)
                        } // Section
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.1 Market Environment Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
