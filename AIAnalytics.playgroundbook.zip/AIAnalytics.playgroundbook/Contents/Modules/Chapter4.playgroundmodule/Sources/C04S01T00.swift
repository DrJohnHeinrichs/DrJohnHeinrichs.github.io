//
//  C04S01T00.swift
//  Book_Sources
//
//  Chapter 04 Section 01: Topic 00: Overview
//
//  Created by SBAMBP on 04/07/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("4.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Exploration Tools")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers are facing the task of assessing the marketing environment and responding to changes and new trends in their short-term tactical and long-term strategic decisions.  They are looking for and relying on marketing analytics to assist them in making these decisions.  Big data analytics exploration tools, especially data visualization, can provide more timely and reliable information about new trends and changes in the environment.  Marketing analytics focuses on all the external and internal elements which can affect the firm’s performance.  This marketing analytics helps marketing managers align their strategies with the firm’s environment and help them develop an understanding of the various external forces that can influence the future market growth (or decline) for the firm.\n\nTypically, marketing managers evaluate three key areas of the marketing environment.  The first area is the macro-environment which encompasses the economy as a whole (rather than a particular sector or region) including trends, spending, monetary, and fiscal policy.  The second area is the micro-environment which encompasses the immediate area of operations that affect the firm’s performance and decision-making freedom, competitors, customers, distribution channels, suppliers, and the general public.  Finally, the third area is the internal environment which is composed of elements within the firm, including employees, management, corporate culture, and employee behavior.  While there are many different tasks involved with generating various marketing analytics, marketing managers primarily focus on three analytical types which are market trend analytics, competitor analytics, and performance analytics.\n").padding(10)
                    } // Section
                        // ----------------------
                        .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.1 Market Environment Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
