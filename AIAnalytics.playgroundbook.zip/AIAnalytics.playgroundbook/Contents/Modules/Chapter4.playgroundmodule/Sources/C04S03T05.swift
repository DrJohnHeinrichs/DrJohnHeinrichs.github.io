//
//  C04S03T05.swift
//  Book_Sources
//
//  Chapter 04 Section 03: Topic 05: Graphic Display Chart Application
//
//  Created by SBAMBP on 04/13/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S03T05: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure414Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 5: Start --- Graphic Display Chart Application
        // ------------------------------
        NavigationView {
            ScrollView {
 //               Section {
                    // ----------------------
                    Text("4.3.5 Graphic Display Chart Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Input Data")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers need to present the value of a measure on a map.  They are interested in visualizing the values of a given measure highlighting the magnitude by the geographical areas.\n\nFigure 4-14 presents a geomap showing the sales volume of a quarter by states.  In this case, the target metric used for this chart is one revenue measures of sales revenue.  The degree of shade represents the amount of sales revenue.  The classification metric is the market dimension of state.  The visualization chart shows that Massachusetts has the largest sales volume followed by Colorado and Connecticut.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-14: Sales Revenue by States") {
                            self.showingFigure414Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure414Sheet1) {
                            Figure414View1()
                        }
                    } // Section 1
                    // ----------------------
    //                .padding(10)
                    // ----------------------
    //            } // Section Main
    //               .padding(.bottom, 20)
            } // ScrollView -- text
    //        .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.3 Visualization Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 5: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 4-14 VIEW
// ------------------------------
struct Figure414View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-14: Sales Revenue by States")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-14.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-14 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
