//
//  C04S02T01.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 01: Chart Types
//
//  Created by SBAMBP on 04/11/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 1: Start --- Comparison Visualization Chart Types
        // ------------------------------
        NavigationView {
            List {
                    // ----------------------
                    Text("4.2.1 Comparison Visualization Chart Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Text("Marketing managers may need to compare sales among different brands or market regions.  In addition, they also want to contrast the advertising cost to the total marketing expense.  The following chart types can be used for comparison and contrast purposes.\n").padding(10)
                    // ----------------------
                    NavigationLink(destination: BarChart()){
                        Text("Bar Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: Histogram()){
                        Text("Histogram")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
                    NavigationLink(destination: Heatmap()){
                        Text("Heatmap")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: BulletChart()){
                        Text("Bullet Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
                    NavigationLink(destination: TreeMap()){
                        Text("Tree Map")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: PieChart()){
                        Text("Pie Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: BAR CHART
// ------------------------------
public struct BarChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Bar Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Bar charts are one of the most commonly used business analytic charts for data visualization.  Bar charts are used for displaying nominal (categorical) data or ordinal data with rank order characteristics (e.g., car preference, cell phone preference) that can be classified into different categories.  Bar charts are used to compare data across multiple categories.  Bar charts can be horizontal, vertical, cone, or cyclically shaped.  They can be multi-dimensional with overlaying variables stacked on top of each other to show multiple dimensions in a single chart.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: HISTOGRAM
// ------------------------------
public struct Histogram: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
//                Text("Histogram").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Histogram")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A histogram looks like a bar chart.  The difference between the two is the information displayed in them.  It is ideal to show frequency distributions in variable datasets.  In a histogram, the x-axis is typically used to show the categories or ranges, and the y-axis is used to present the measures or values of interest.  A histogram reduces the size of data by grouping data points into frequencies and shows the distributional shape of the data.  It can show whether the data is distributed normally or skewed and in which direction.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: HEATMAP
// ------------------------------
public struct Heatmap: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Heatmap")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Heatmaps are used to present visual comparison of continuous values across two categories using color.  Heatmaps allow managers to quickly identify intersections of two variables that are stronger or weaker in terms of the measurement values of those variables.  For example, heatmaps can show the degree of purchase amount by target customer firm size with color gradient.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: BULLET CHART
// ------------------------------
public struct BulletChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Bullet Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A bullet chart is a variation of a bar chart showing progress toward a target measure.  A bullet chart can intuitively show how the measure of interest such as actual sales is progressing toward the target (e.g., quarterly sales quota).  This chart can help managers understand intuitively the meaning of the chart that is placed in a dashboard.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: TREE MAP
// ------------------------------
public struct TreeMap: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Tree Map")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A tree map presents the pattern of data in the hierarchical, tree structured format.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: PIE CHART
// ------------------------------
public struct PieChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Pie Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("A pie chart presents the relative proportion into pie shaped areas.  Pie charts are useful in displaying proportions.  There exist many other similar forms such as the donut chart with a hollow center.  This chart is useful when the number of categories is limited.  Pie charts need to be used only for presenting relative proportions of a specific measure of interest.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
