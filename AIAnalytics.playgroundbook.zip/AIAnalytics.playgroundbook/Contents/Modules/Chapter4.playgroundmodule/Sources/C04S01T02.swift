//
//  C04S01T01.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 02: Competitor Analytics
//
//  Created by SBAMBP on 04/07/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S01T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Competitor Analytics 
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("4.1.2 Competitor Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Competitor Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Competitor analytics assesses the trends, strategies, and performance of direct competitors.  Competitive intelligence activities can provide valuable information about competitor activities and performances.  The firm is trying to understand where the competitors fit in the marketplace and how to position their products and services in relation to the competitors’ products and services.  The competitor analytics focuses on identifying competitors’ success factors, their strengths and weaknesses, and their realized strategic directions.  This assessment or analysis provides both an offensive and defensive strategic context to identifying opportunities and threats in the market.  An in-depth competitive analysis will also provide an understanding of how the existing and potential customers rate the competition, a positive identification of the competitor’s strengths and weaknesses and a mechanism to develop effective competitive strategies in the target market.\n").padding(10)
                        Text("A decision that marketing managers face in dealing with competitor analytics is what types of firms should be considered as competitors.  Any firm marketing a product similar to, or as a substitute for, the firm’s products in the same geographic area is a direct competitor.  Firms offering dissimilar or substitute products in relation to the firm’s products or services are considered indirect competitors.  For example, indirect competition would exist between the manufacturer of butter and a manufacturer of margarine selling to the same customers.  Another example is the manufacturer of eyeglasses who competes indirectly with contact lens manufacturers.  Stated in other terms, indirect competition will satisfy the customer’s need with a particular product or service, although the product or service used may be different from the product or service offered by the firm.  If a firm has similar products and distribution channels, but has chosen to operate in different market segments, then that firm is currently not a direct competitor.  However, it’s important to monitor the marketing activities of such competitors because they may decide to move into the identified market segment, just as the firm may decide to move into the competitor’s market segment.  What means are available to limit and control the competition?  Marketers of different brands of products will often pursue a particular market segment.  Market segmentation, which is the means of breaking down larger markets into smaller ones requiring different marketing mixes, is a means for strengthening and focusing the firm’s attempt to limit and control the competition.  There are however, a broad range of strategies a firm can employ in a competitive environment ranging from price changing and new packaging to improving customer service and new product development.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Market Type")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("There are several markets where it is relatively easy to name every competitor.  These are concentrated markets where only a handful of competitors exist.  If this is the scenario for the firm’s product or service, the firm will need to develop an analysis for each competitor.  The steel industry and automobile industry are examples of these types of markets.  If the firm is selling in a market with many competitors, the task of analyzing the competition becomes a little more difficult.  Since it is unrealistic to collect and maintain information on dozens of competitors, the firm will be able to save valuable time, without sacrificing the integrity of the competitive analysis, by using the 80/20 rule.  In fragmented markets with many competitors, it is most probable that 80% of the total market revenues are accounted for by 20% of the competitors.  It is the 20% of competitors that would need to be examined most closely.  When using this approach, it is important to keep abreast of the market for new and upcoming players who, through some variable, whether it uses new technology or an aggressive advertising campaign, may become a dominant player.\n").padding(10)
                        Text("When generating competitor analytics, it is important to include the following four main categories.  Those categories are competitors, environment, technology, and decision location/decision maker.  The first category is that of competitors.  For generating the competitor analytics, the product or brand level is the narrowest perspective that an analyst can take of competitors and it focuses only on rivals pursuing the same segment with essentially the same product offerings.  The product category level improves the analytic situation by looking at products/services with similar features and attributes.  Needs-based / generic-level competitors seek to satisfy the same functional need of a customer.  A share-of-wallet level is probably the broadest category of competition and considers any other product that a customer might choose to buy.  It can also refer to what percentage of a customer’s total spending is devoted to the firm’s products as opposed to a competitor’s products.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Competitive Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("The competitive analysis should ideally focus on the following environmental sectors – competitive, customer, economic, political, legal, regulatory, social, and technological.  Competitive refers to both current and prospective competitors and the means by which those competitors compete.  Customer refers to the firm’s current customers, to potential customers, and to the competitor’s customers.  Economic refers to issues such as inflation, financial markets, interest rates, price regulations, raw material sourcing, and exchange rate volatility.  Political, legal, and regulatory includes institutions, government, pressure groups, and stakeholders that influence the “rules of the game”.  The social aspect refers to the demographics, wealth distribution, attitudes, and social and cultural characteristics that determine the firm’s purchasers.  Technological refers to the current and emerging technologies, product, and process innovations, and basic and applied research and development efforts.  The competitive analysis of the environmental sectors is broken up into the macro-environment and the micro-environment.\n").padding(10)
                        Text("Competitive analysis includes competitive technology intelligence (CTI).  CTI involves the innovation product/process, and research and development (R&D).  Identifying innovation and disruptive innovation requires an understanding of the development of intellectual property.  Technology driven industries experience rapid change and new or different technologies will be needed within a short-term time period to compete with competitors.  Product/process attempts to understand the nature and potential results of process improvements.  For firms with technology-intensive products and/or processes, technology is an important differentiating factor in product features, production steps, or pricing strategy.  Many industries have a high proportion of firms with high R&D intensity.  As such, those firms display higher-than-average ratios of R&D expenditures to sales.  Those firms are also those whose R&D portfolio may contain a high proportion of large, long-range products that are most active in developing innovation, as well as product and process improvements.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Competitor Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Any strategic analysis performed by the firm requires some degree of competitor analytics.  The focus of competitor analytics is on understanding the firm’s competitors and their activities.  Competitive strategy aims to establish a profitable and sustainable position for the firm against the market forces that determine competition.  Two central questions need to be answered to develop an effective competitive strategy.  The first question centers on determining the long-term profitability of the chosen market.  The second question involves evaluating the firm’s relative competitive position within the field of competitors in the marketplace.  Competitive analytics is developed to offer analytic patterns and models to answer these types of questions.\n").padding(10)
                        } // Section 4
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Formulated Competitor Analytics")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                            {
                            Text("Competitor analytics can be formulated and developed in three different ways.  They can be developed by focusing on strategic groups, key business issues, and/or customers segments.  The first way to develop competitor analytics involves the concept of strategic groups.  Strategic groups provide a resource-driven and capability-driven approach toward understanding the competitive structure of an industry.  This approach leads the firm to develop analytics that will assess and evaluate the target competitor’s characteristics, capabilities, competitive advantages, strategic market position, and current performance.  Using this approach, competitor analytics can be developed to classify competitors into various strategic groups that pursue similar competitive strategies (e.g., an aggressive market expansion strategy), have similar characteristics (e.g., firm size or innovativeness), and have similar assets and capabilities (e.g., brand equity).  The typical analytics used will provide the firm with the target competitor’s mission and objectives, management and ownership, unique and differentiating capabilities and advantages such as production and service delivery capabilities, R&D activities, marketing and distribution (M&D) strategies, and financials and related forecasts and predictions.  These types of information are pre-analyzed, modeled, and presented using visualization tools in the competitor analytics warehouse.\n").padding(10)
                            Text("The second way to develop competitive analytics involves using key business issues.  Competitors are more broadly defined and assessed according to key business domain categories and strategies.  Under this type of focus, a broad view of a group of key competitors is identified and their competitive dynamics within the industry are assessed.  For example, investments and expansion strategies utilized by key competitors are analyzed and modeled under various economic conditions that affect the industry.  New technology trends are systematically analyzed by evaluating patents, R&D expenditures patterns, new technology investments, and new product development activities of key competitors.  Competitor analytics also includes activities and patterns of emerging new lines of business, divestiture, joint ventures, and mergers & acquisitions (M&A) of key competitors.\n").padding(10)
                            Text("The third way to develop competitive analytics is evaluating competitors who are competing for the same customers.  Under this method, competitor analytics can include analysis patterns and models assessing key competitors and their market positions and brands for various market segments, brand-switching patterns for a particular market segment, and customer’s value perception relative to the primary competitors.  In developing customer-based competitors, a firm can use either customer choices or product-use associations in identifying such competitor groups.  The customer choice approach views what brand or product items are competing with the firm’s brand or product item at the time of the customer choice.  This is evaluating what other brands or products are in the same choice set of the firm’s target customers.  Analytics solution can provide comparative information for these identified competitors based on the customer choice approach.  The other approach to evaluating competitors is by focusing on the association of products with specific use contexts or applications.  Which brand of competitors’ products are purchased and used for the same use context or application that the firm’s brand or product is used.  In order to develop analytic solutions using these two approaches, a firm needs to gather information from customers in the defined target market.  This type of information can be obtained from the traditional survey method, from syndicated data sources, or from web survey methods.\n").padding(10)
                            Text("The purpose of the competitive analytics is to provide the marketing manager with analytic patterns and models that can help determine the strength and weakness of the primary competitors within the target market.  Additionally, competitive analytics can help develop identify strategies and barriers that will provide a firm with a distinct long-term advantage.  The first step in developing competitor analytics is to identify the firm’s current and potential competitors.  For each of the identified major competitors, analysis can be performed to understand their strategies and identify vulnerable areas.  The presence and absence of key assets and capabilities indicate strengths and weaknesses of the firm’s competitors.  Competitor analytics can offer systematic assessment of such assets and capabilities.  The assessment can include reasons behind successful and unsuccessful firms, prime customer motivators, major component costs, and industry mobility barriers.  Competitor analytics also helps marketing managers develop a marketing strategy that will generate a distinct and enduring competitive advantage.  While an analytic model is only an approximation of reality, sensitivity of the solution to changes in the model input and assumptions is a very important part of utilizing competitor analytics.\n").padding(10)
                            } // Section 5
                            // ----------------------
                            .padding(10)
                        // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.1 Market Environment Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
