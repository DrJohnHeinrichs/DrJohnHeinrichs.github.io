//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//
//  Chapter 4: Visualization Tools for Marketing Environment Analytics
//  Section 2: Visualization Analytics Generation
//
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
// https://www.pexels.com/photo/macbook-pro-beside-papers-669619/
// Photo by Lukas from Pexels
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter4
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Visualization Analytics Generation")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero
    @State private var amount: CGFloat = 0.0
    
    var body: some View {
        VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                            .animation(Animation.default.delay(Double(num) / 20.0))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
            
                
            VStack {
                ZStack {
                    Circle()
                        .fill(Color(red: 1, green: 0, blue: 0))
                        .frame(width: 200 * amount)
                        .offset(x: -50, y: -80)
                        .blendMode(.screen)

                    Circle()
                        .fill(Color(red: 0, green: 1, blue: 0))
                        .frame(width: 200 * amount)
                        .offset(x: 50, y: -80)
                        .blendMode(.screen)

                    Circle()
                        .fill(Color(red: 0, green: 0, blue: 1))
                        .frame(width: 200 * amount)
                        .blendMode(.screen)
                } // ZStack
                .frame(width: 150, height: 150)

                Slider(value: $amount)
                    .padding()
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
            .edgesIgnoringSafeArea(.all)
                Spacer()
                C04S02T01Instructions()
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC04S02 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC04S02
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!\n\nYou are taking the 'Visualization Analytics Generation' section.")
} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
