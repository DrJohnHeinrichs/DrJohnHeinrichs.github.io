//#-hidden-code

import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on developing your skills and understanding with working on line charts. ")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)

_setup()

public func findUserCodeInputs(from input: String) -> [String] {
    var inputs: [String] = []
    let scanner = Scanner(string: input)

    while scanner.scanUpTo("//#-editable-code", into: nil) {
        var userInput: NSString? = ""
        scanner.scanUpTo("\n", into: nil)
        scanner.scanUpTo("//#-end-editable-code", into: &userInput)

        if userInput != nil {
            inputs.append(String(userInput!))
        }
    }
    return inputs
}

public func makeAssessment(of input: String) -> String {
    let codeInputs = findUserCodeInputs(from: input)
    print("\(codeInputs)")
    
    if codeInputs[1] == "var I_Understand_The_Material = 1\n" {
        print("\(codeInputs)")

        return "Yes"
    } else {
        print("\(codeInputs)")

        return "No"
    }
    return "Yes"
}
//#-end-hidden-code

/*:
 # Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart - Interactive](BarChart2)
 3. **[Line Chart](LineChart)**
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. [Scatter Chart](ScatterChart)
 */

/*:
# Interactive Playground
* In this challenge, you'll practice your [Chart Dimensions](glossary://Chart%20Dimensions) - finding skills by creating, developing, and rearranging lines on a chart.
*/

/*:
 1. Create a line plot.
    The xyData indicates the starting (x,y) coordinate, various other (x,y) coordinates, and the ending (x,y) coordinate.
 * Add an (x,y) data point
 * Change the existing (x,y) data points
*/
 //#-editable-code Enter your answer
let line = LinePlot(xyData: (1,1), (3,9), (6,100), (10,50))
//#-end-editable-code

/*:
 2. Create a line plot from a data set.
    The data to plot is created from a function that generates multiple "i" points.
 * Change the line color
 * Change the line width
 * Change the line style (.solid, .dashed, .dotted, .none)
 */
//#-editable-code Enter your answer
let data = XYData()
for i in 1...5 {
    data.append(x: Double(i), y: Double(i * i))
}
let lineFromDataSet = LinePlot(xyData: data)
lineFromDataSet.color = #colorLiteral(red: 0.07005243003, green: 0.5545874834, blue: 0.1694306433, alpha: 1)
lineFromDataSet.lineWidth = 5
lineFromDataSet.style = .dashed
//#-end-editable-code

/*:
3. Create a line plot from a mathmatical function.
   Develop a function you want to explore.
 * Consider x + 5
 * Consider x * 5
 * Consider x / 5
*/
//#-editable-code Enter your answer
let function = LinePlot { x in
    10 + x * x/2
}

function.color = #colorLiteral(red: 0.7086744905, green: 0.05744680017, blue: 0.5434997678, alpha: 1)
function.lineWidth = 3
function.style = .solid
//#-end-editable-code

/*:
4. Do you understand the material?
   Change the 0 to a 1 if you understand the challenges regarding line charts.
 */
//#-editable-code Enter your answer
var I_Understand_The_Material = 0
//#-end-editable-code
/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Discussion on Editable Regions]: https://developer.apple.com/documentation/swift_playgrounds/specifying_editable_regions_in_a_playground_page

 
 ### **Additional Information**
 For more information regarding line charts, view the following ...
 * [Discussion on Editable Regions].
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)

//#-hidden-code

let input = PlaygroundPage.current.text
let JHHStatus = makeAssessment(of: input)

if JHHStatus == "No" {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Hint #1: **Sorry** that you got it wrong", "Hint #2: Do the exercises again!!", "Hint #3: Never give up"], solution: "This is the solution - the answer is 1 - enter the number 1. ")
    } else if JHHStatus == "Yes" {
        PlaygroundPage.current.assessmentStatus = .pass(message: "Great job!")
    } else {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["Hint #1: **Sorry** you got it wrong.  Please enter 1 for Yes."], solution: "Understand requires a Yes (1) or No answer.")
}

//#-end-hidden-code
