//#-hidden-code
//
//  ContentView.swift
//  SwiftUI -- Bar Charts
//
// UnitPoint (x: 1.0, y: 1.0)
// startPoint: UnitPoint(x: , y: )

import SwiftUI
import PlaygroundSupport
// -------------------------------
// -------------------------------
struct ContentView: View {
    @State private var janSales: String = ""
    @State private var febSales: String = ""
    @State private var marSales: String = ""

    var janSales1: CGFloat {
        let salesJanAmount = Double(janSales) ?? 10.0
        return CGFloat(salesJanAmount)
    }

    var febSales1: CGFloat {
        let salesFebAmount = Double(febSales) ?? 30.0
        return CGFloat(salesFebAmount)
    }
    
    var marSales1: CGFloat {
        let salesMarAmount = Double(marSales) ?? 20.0
        return CGFloat(salesMarAmount)
    }
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.blue, .yellow]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            VStack {
//                Spacer()
                Form {
                    HStack {
                        TextField("January", text: $janSales)
                        TextField("February", text: $febSales)
                        TextField("March", text: $marSales)
                    } // HStack - Jan, Feb, Mar
                        .keyboardType(.decimalPad)
                } // Form
                    .frame(maxHeight: 250)
                Text("Sales First Year")
                    .font(.system(size: 26, weight: .light, design: .serif))
                    .italic()
                HStack(alignment: .bottom, spacing: 8){
                    Bar(percent: self.janSales1, day: "Jan")
                    Bar(percent: self.febSales1, day: "Jan")
                    Bar(percent: self.marSales1, day: "Jan")
//                    ForEach(percents){i in
//                        Bar(percent: i.percent,day: i.day)
//                    }
                } // HStack 1
                    .frame(maxHeight: 300)
                Spacer()
//                Text("Second Year")
//                    .font(.system(size: 26, weight: .light, design: .serif))
//                    .italic()
//                HStack(alignment: .bottom, spacing: 8){
//                    ForEach(percents){i in
//                        Bar(percent: i.percent,day: i.day)
//                    }
//                } // HStack 2
//                Spacer()
            } // VStack
            //.frame(height: 250)
        } // ZStack
    } // body
} // struct
// -------------------------------
// -------------------------------
struct Bar: View {
    var percent: CGFloat = 0
    var day = ""
    var body: some View{
        VStack{
            Text(String("$" + String(format: "%.0f", Double(percent)))).foregroundColor(Color.black.opacity(0.5))
            
            Rectangle().fill(Color.red).frame(width: UIScreen.main.bounds.width / 50, height: getHeight())
            
            Text(day).foregroundColor(Color.black.opacity(0.5))
        } // VStack
    } // body
    
    func getHeight() -> CGFloat { 
        return 200 / 100 * percent
    } // func - getHeight
} // struct - Bar
// -------------------------------
// -------------------------------
// Sample Datas....
struct type : Identifiable {
    var id : Int
    var percent :CGFloat
    var day : String
} // struct - type

var percents = [
type(id: 0, percent: 100, day: "Jan"),
type(id: 1, percent: 55, day: "Feb"),
type(id: 2, percent: 75, day: "Mar"),
type(id: 3, percent: 25, day: "Apr"),
type(id: 4, percent: 5, day: "May"),
type(id: 5, percent: 15, day: "Jun"),
type(id: 6, percent: 65, day: "Jul"),
type(id: 7, percent: 100, day: "Aug"),
type(id: 8, percent: 55, day: "Sep"),
type(id: 9, percent: 75, day: "Oct"),
type(id: 10, percent: 25, day: "Nov"),
type(id: 11, percent: 5, day: "Dec")
]
// -------------------------------
// -------------------------------
//
//#-end-hidden-code
/*:
# Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. **[Bar Chart - Interactive](BarChart2)**
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. [Scatter Chart](ScatterChart)
 */

/*:
 # Interactive Playground
 * In this challenge, you'll practice your [Business Analytics](glossary://Business%20Analytics) - finding skills by finding and rearranging .
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Custom Bar Chart]:
 https://kavsoft.tech/Swift/Custom%20Bar%20Chart/
 [Custom Gradient]: https://sarunw.com/posts/gradient-in-swiftui/
 [Creating Charts]: https://www.raywenderlich.com/6398124-swiftui-tutorial-for-ios-creating-charts
 [SwiftUI Documentation Enhancement]: https://swiftui-lab.com/welcome/
 
 ### **Additional Information**
 For more information regarding bar charts, view the following ...
 * [Custom Bar Chart]
 * [Custom Gradient]
 * [Creating Charts]
 * [SwiftUI Documentation Enhancement]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")

