//#-hidden-code

import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on developing your skills and understanding with working on scatter charts. ")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)

_setup()

//public func findUserCodeInputs(from input: String) -> [String] {
//    var inputs: [String] = []
//    let scanner = Scanner(string: input)
//
//    while scanner.scanUpTo("//#-editable-code", into: nil) {
//        var userInput: NSString? = ""
//        scanner.scanUpTo("\n", into: nil)
//        scanner.scanUpTo("//#-end-editable-code", into: &userInput)
//
//        if userInput != nil {
//            inputs.append(String(userInput!))
//        }
//    }
//    return inputs
//}

//public func makeAssessment(of input: String) -> String {
//    let codeInputs = findUserCodeInputs(from: input)
//    print("\(codeInputs)")
//
//    if codeInputs[1] == "var I_Understand_The_Material = 1\n" {
//        print("\(codeInputs)")
//
//        return "Yes"
//    } else {
//        print("\(codeInputs)")
//
//        return "No"
//    }
//    return "Yes"
//}
//#-end-hidden-code
/*:
 # Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart - Interactive](BarChart2)
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. **[Scatter Chart](ScatterChart)**
 */

/*:
# Interactive Playground
* In this challenge, you'll practice your [Chart Dimensions](glossary://Chart%20Dimensions) - finding skills by creating, developing, and rearranging lines on a chart.
*/

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Discussion on Editable Regions]: https://developer.apple.com/documentation/swift_playgrounds/specifying_editable_regions_in_a_playground_page

 
 ### Additional Information:
 For more information regarding **scatter charts**, view the following ...
 * [Discussion on Editable Regions] 
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
