//#-hidden-code
//
//  ContentView.swift
//  SwiftUI -- Bar Charts

import SwiftUI
import PlaygroundSupport

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

@available(iOSApplicationExtension 13.0, *)
struct ContentView: View {

    @State var pickerSelection = 0
    @State var barValues : [[CGFloat]] =
        [
        [75,125,35,150,50,100,200,110,30,170,50,165],
        [200,110,30,170,50,100,100,100,200,140,120,80],
        [10,20,50,100,120,90,180,200,40,60,90,60]
        ]
    
    var body: some View {
        ZStack {
            Color(.blue)
            .edgesIgnoringSafeArea(.all)
            VStack {
                Text("LJL Industries").foregroundColor(.white)
                    .font(.largeTitle)

                Picker(selection: $pickerSelection, label: Text("Stats")) {
                    Text("Page Views").tag(0)
                    Text("Reads").tag(1)
                    Text("Fans").tag(2)
                }.pickerStyle(SegmentedPickerStyle()) // Picker
                    .padding(.horizontal, 10)
                
                HStack(alignment: .center, spacing: 10) {
                    ForEach(barValues[pickerSelection], id: \.self){
                        data in
                        BarView(value: data, cornerRadius: CGFloat(integerLiteral: 1*self.pickerSelection))
                    } // ForEach
                }.padding(.top, 24).animation(.default) // HStack
                
                HStack(alignment: .center, spacing: 10) {
                    Text("Jan   Feb   Mar   Apr   May   Jun   Jul   Aug   Sep   Oct   Nov   Dec").foregroundColor(.white)
                }.padding(.top, 14).animation(.default) // HStack
            } // VStack
        } // ZStack
    } // body

    init() {
        UISegmentedControl.appearance().selectedSegmentTintColor = .darkGray
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
    } // init
} // struct - ContentView

@available(iOSApplicationExtension 13.0, *)
struct BarView: View{

    var value: CGFloat
    var cornerRadius: CGFloat
    
    var body: some View {
        VStack {
            ZStack (alignment: .bottom) {
                RoundedRectangle(cornerRadius: cornerRadius)
                    .frame(width: 30, height: 200)
                RoundedRectangle(cornerRadius: cornerRadius)
                    .frame(width: 30, height: value).foregroundColor(.green)
            }.padding(.bottom, 8) // ZStack
        } // VStack
    } // body
} // struct - BarView

//
//#-end-hidden-code

/*:
 # Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. **[Bar Chart](BarChart)**
 2. [Bar Chart - Interactive](BarChart2)
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. [Scatter Chart](ScatterChart)
 */

/*:
 # Interactive Playground
 * In this challenge, you'll practice your [Business Analytics](glossary://Business%20Analytics) - finding skills by finding and rearranging .
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### **Additional Information**
 For more information regarding bar charts, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)

//#-hidden-code
//

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code

