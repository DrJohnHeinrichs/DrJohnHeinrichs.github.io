//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on clustering analytics generation.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.0000, green: 0.5882, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C05S02T00(topicTitle: "5.2 Clustering Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.2.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("5.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Code Input Attributes
            // -------------------------
            C05S02T01(topicTitle: "5.2 Clustering Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.2.1 Code Input Attributes")
                } else {
                    Image(systemName: "pencil")
                    Text("5.2.1 Code Input Attributes")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Compute Distance Estimates
            // -------------------------
            C05S02T02(topicTitle: "5.2 Clustering Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.2.2 Compute Distance Estimates")
                } else {
                    Image(systemName: "pencil")
                    Text("5.2.2 Compute Distance Estimates")
                } // if-else
                } // tabItem
            .tag("bookSection3")
            // -------------------------
            // TOPIC 3: Selected Clustering Procedures
            // -------------------------
            C05S02T03(topicTitle: "5.2 Clustering Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.2.3 Selected Clustering Procedures")
                } else {
                    Image(systemName: "pencil")
                    Text("5.2.3 Selected Clustering Procedures")
                } // if-else
                } // tabItem
            .tag("bookSection4")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Clustering Analytics Generation section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have three topics to complete.",
                        "-- Topic 1: Code Input Attributes\n\nThis is a reading assignment. ",
                        "-- Topic 2: Compute Distance Estimates\n\nThis is a reading assignment. ",
                        "-- Topic 3: Selected Clustering Procedures\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.0000, green: 0.5882, blue: 1.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Clustering Tools for Market Segment Analytics
 ### Table of Contents - _Chapter 5_
 1. [Section 1: Market Segment Analytics Task](Ch05-Pg01)
 2. **[Section 2: Clustering Analytics Generation](Ch05-Pg02)**
 3. [Section 3: Clustering Analytics Interpretation and Application](Ch05-Pg03)
 4. [Section 4: AI Powered Clustering Analytics](Ch05-Pg04)
 */

/*:
 * Callout(Quote: Segment Analytics):
 "No great marketing decisions have ever been made on qualitative data."
 \
 –John Sculley
*/

/*:
 # Section 2: Clustering Analytics Generation
 
 ## 2.1 Code Input Attributes
 ## 2.2 Compute Distance Estimates
 ## 2.3 Select Clustering Procedures
 * Hierachical Clustering Method
 * [K-Means Clustering](glossary://K-Means%20Clustering) Method
 */

/*:
Cluster analysis is performed following certain steps.
* Code Input Attributes
* Compute Distance Estimates
* Select Clustering Procedures
*/

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Data Clustering Tutorial]: https://towardsdatascience.com/clustering-for-data-nerds-ebbfb7ed4090

 ### Additional Information:
 For more information regarding **clustering analytics generation tasks**, view the following ...
 * [Data Clustering Tutorial]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)

