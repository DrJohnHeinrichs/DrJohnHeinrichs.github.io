//
//  C07S01T00.swift
//  Book_Sources
//
//  Chapter 7: Logistic Regression and Forecasting Tools for Customer Behavior Analytics
//  Section 1: Customer Behavior Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C07S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Choice Behavior")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The most important task marketing managers are facing is understanding and predicting customer choice behavior as accurately as possible.  Marketing managers are interested in finding out how individual customers make brand and product choices as well as how individual customer choices lead to firm sales and market share.  At the individual customer level, analytic question managers have to answer is which customers will make what type of choice decisions.  These choice decisions include which customers will make a purchase, choose our products, remain as our customers instead of churning, accept our promotional offers, or click a paid search link.  These analytic questions are related to understanding the propensity or the likelihood of taking actions.  At the aggregate market level, analytic questions marketing managers have to answer include how much would we be likely to sell to the customers.  This question can be translated to what are the probable future sales.  As both short-term and long-term sales projections are critical for firms, the most common analytic questions are related to market analysis and sales forecasting.  The next section describes the analytics task related to customer behavior.  These are individual customer purchase behavior analytics and market sales forecasting analytics that are the aggregate outcome of individual customer purchase behaviors.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.1 Customer Behavior Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
