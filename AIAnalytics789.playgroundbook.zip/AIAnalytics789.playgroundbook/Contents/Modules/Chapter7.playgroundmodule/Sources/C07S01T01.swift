//
//  C07S01T01.swift
//  Book_Sources
//
//  Chapter 7: Logistic Regression and Forecasting Tools for Customer Behavior Analytics
//  Section 1: Customer Behavior Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C07S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Individual Customer Purchase Behavior Analytics Task
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.1.1 Individual Customer Purchase Behavior Analytics Task").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Behavior Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Customer behavior analysis includes studying and gathering information about individuals, groups, or firms and the processes in which they select, secure, use and dispose of products, services, or experiences to satisfy their needs and wants. The analysis also discusses social and economic impacts that purchasing and consumption behavior has on both the consumer and society.  The study of consumer behavior is concerned with all aspects of purchasing behavior, from pre-purchase activities through post-purchase consumption and evaluation activities.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Study of Consumers")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The study of consumers helps firms improve their marketing strategies by understanding issues such as how the psychology of how consumers think, feel, reason, and select among different alternatives (e.g., brands, products, and retailers); the psychology of how the consumer is influenced by his or her environment (e.g., culture, family, signs, media); the behavior of consumers while shopping or making other marketing decisions; limitations in consumer knowledge or information processing abilities influence decisions and marketing outcome; how consumer motivation and decision strategies differ between products that differ in their level of importance or interest that they entail for the consumer; and how marketers can adapt and improve their marketing campaigns and marketing strategies to more effectively reach the consumer.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Questions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers want to know who buys their products or services and who makes that decision to buy that specific product/service.  They also want to find out who influenced the decision to buy the product and how the purchase decision was made.  Most need to find out why the customer buys.  Is it a need or want?  Is there a reason the consumer prefers one brand over another?  Where do customers go to buy the brand – the store, online, travel far away?  Marketing managers also need to be aware of what the product’s/service’s perception is and if it matches the goals.  There are always social factors that influence the purchase decision so finding out what those are should be done sooner than later.  What is the role of the consumer’s lifestyle in their behavior?  These questions will be answered in the following paragraphs based on analysis of consumer behaviors.  The following are four reasons why firms should be analyzing customer behavior and how firms can engage, retain, and strengthen bonds with their customers.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Gain Insight")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Clearly, one of the main reasons firms analyze data is to gain insight.  Exploring your data for insights about customer behavior may involve segmenting your customer base, which often uses cluster analysis (i.e., a technique that organizes a set of observations into two or more groups that are mutually exclusive based on combinations of variables).  Typically, firms do discovery and segmentation analysis using structured data.  However, unstructured text data, such as social media data or text data, can also provide great insights into customer sentiment and behavior.  More often, firms are performing social media analytics, such as voice-of-the-customer analysis, using text analytics technology to gain insight about what customers are saying and how their brand resonates with existing and potential customers.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Target Customers")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("If the customer base is segmented, then the manager can target customers and engage them because the manager has a better sense of what customers might be interested in.  For instance, a firm wants to make customers the right offer when it launches a product campaign across various channels (e.g., online, e-mail, mobile, in-store).  By analyzing historical purchases and profiles, firms can predict the likelihood, or propensity, of future activity at a customer level.  For instance, a firm might use a propensity model and past purchase behavior to gauge the probability of a customer making a certain purchase.  This data can be used when developing the new campaign.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Retention")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Customer retention is a key marketing activity, especially when it comes to profitable customers, and predictive analytics can be extremely helpful in customer retention.  For instance, decision trees can be useful where there are discrete target or outcome variables of interest (e.g., leave or stay).  Typically, a set of historical training data is provided to the predictive analytics algorithm.  The data might consist of different kinds of information about customers (demographics, purchase history, past sentiment) and it is used by the decision-tree algorithm to determine decision rules that describe the relationship between the input and outcome variables.  These rules can be used against new data where the outcome is not known (for instance, leave or stay).  These models are often operationalized in a call-center where agents can use them to try to retain customers at risk.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.1 Customer Behavior Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
