//
//  C07S01T02.swift
//  Book_Sources
//
//  Chapter 7: Logistic Regression and Forecasting Tools for Customer Behavior Analytics
//  Section 1: Customer Behavior Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C07S01T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Forecasting Analytics Task
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.1.2 Forecasting Analytics Task").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Market Forecasting")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Market forecasting is a core component of a market analysis.  It helps project future sales, costs, profit and characteristics/trends in the target market.  Normally this is divided into segments showing the projected number of potential customers and the growth rate of that market.  Typically, marketing managers utilize four steps in any market forecasting: 1) defining the market, 2) dividing the total industry demand into its main components, 3) forecasting the drivers of demand in each segment and projecting how likely they are to change, and lastly 4) conducting sensitivity analyses to understand the most critical assumptions to determine risks.\n").padding(10)
                        Text("Providing the return-on-investment (ROI) of marketing activities is a vital way for marketing managers to understand the effectiveness of each particular marketing campaign, piece of content, and post.  Providing ROI goes hand-in-hand with making an argument to increase budget.  A challenge that marketing managers face is whether to use non-repeatable and non-comparable methods to forecast the market.  Due to lack of common forecasting tools or methodologies, each manager has a very different way of forecasting.  Every manager does what they think looks best and that may change every year depending on what is included in the forecast.  Managers also have deadlines and don’t always have enough time to spend and make exactly the same forecasting sheet.  As a result, business units across the firm create multiple different forecasts, none of which are comparable or repeatable.  Each forecast is customized to a manager’s “gut feeling” which is largely unrepeatable.  Any tweaks or adjustments require managers to almost redo the entire forecast.  Further, these forecasts are then rolled into a larger forecast, which compounds and amplifies errors and approximations in the final estimates.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Quantitative Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Another problem associated with not using the same method every time marketing managers forecast is the lack of quantitative analysis.  Despite the many great statistical software products in market today, most managers do not utilize any quantitative analysis for their forecasts.  Most of them prefer to follow a simplistic approach of linear extrapolation.  The simplistic approach may work some times, but often it does not.  The lack of a quantitative baseline is one of the key reasons that most forecasts differ significantly from real performance.  A forecast based on sound quantitative analysis provides a solid baseline, which can then be tweaked to account for business variations.\n").padding(10)
                        Text("Most of the time managers need information from other departments to forecast. So, if another department’s forecasts or numbers are off, the manager’s forecast will also be off.  One of the biggest challenges with any forecast is estimating changes due to potential future business (wins, losses, or leads).  As a result, most top-down revenue estimates do not account for new sales opportunities.  Few diligent managers manually approximate incremental revenue from key new products, while assuming all else remains equal.  This approach is better than not including any new revenue, but it still largely does not account for any bottom up information from the field about new wins, losses or potential leads that could be converted to opportunities.  It also does not account for any changes in competitive landscape or price degradation.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Tools")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In some firms, the marketing manager might not be provided with all the necessary tools to complete a thorough analysis.  In any firm, sales teams are usually closest to the customer and have maximum visibility into potential awards, losses and leads.  Unfortunately, rarely is this data from sales accurately maintained.  Even if it is maintained, it is hardly quantified into expected net revenue by quarter and integrated into the firm’s forecasting process.  The sales pipeline (forward looking) and business forecasting tools (historical data, if any) are disconnected.  The sales pipeline tools are not connected with the forecasting templates used by the marketing managers.  As a result, managers either spend days trying to collect the right information or cannot use the right information to develop a realistic forecast.\n").padding(10)
                        Text("There has to be two-way communication between the firm’s marketing activities and the sales reports.  Using a marketing software and customer relationship management (CRM) system can tie them together.  Inbound organizations with Service Level Agreements (SLAs) are over 5 times as likely to rate their marketing strategy as effective compared to outbound organizations with misaligned marketing and sales teams.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "1.circle")
                        Text("Metrics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("First, marketing managers need to choose meaningful and predictable metrics.  The sales and revenue forecasts deliver what management needs to compare projections with objectives and then plan accordingly.  Projecting the average revenue per sale is particularly useful as marketing can influence this metric through strategies such as targeting.  More often, marketers will need to forecast metrics that are good indicators of sales and revenue.  Take, for example, marketers that forecast sales opportunities (i.e., leads that are determined by a sales team to have good sales potential).  Marketing may be able to manage this metric’s outcome more easily than closed sales that must occur over a long sales cycle.  Choose forecasting metrics that are closely aligned to sales and/or revenue, have consistent influence on financial outcomes over time, are reasonably predictable with the data available, have clear definitions and meaning to everyone involved, and are within marketing’s ability to impact and manage.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "2.circle")
                        Text("Accurate Forecasting")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Second, managers should establish an approach for accurate forecasting.  In most situations, accuracy is the goal for forecasting, which may differ from a common practice of “low-balling” estimates in order to consistently exceed goals.  When managing performance, low projections should trigger corrective actions.  Therefore, under-estimating forecasts could lead to marketing adjustments that are unnecessary and ultimately hurt the credibility of the marketing department.  Using the historical conversion rates approach applies historical rates of conversions between tracked metrics and sales or financial outcomes.  This method works very well when tracking marketing outcomes that come shortly before a purchase decision, such as sales opportunities.  The approach works similarly for other metrics such as product trials or website landing page visits as long as the conversion rates are fairly consistent over time.  They can also use the forecast modeling approach, which can be used to develop forecasting models that are very predictive of sales and/or revenue outcomes.  These models are created using many data points that include detailed marketing activity, changes in market conditions, product and pricing changes, and competitive activity.  Once the model is developed, actual data is inputted along with upcoming planned assumptions to project the outcomes.  Forecasting models can take many variables into consideration and generate fairly accurate projections, so this approach is often preferred for quality forecasts over longer periods of time.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Goals and Outcomes")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Another way to forecast marketing metrics is to report goals and outcomes versus the forecasts.  When reporting your forecast metrics, it is important to have a process to understand, assess, and act on the information to manage performance.  The reports should show comparisons of the forecast versus goals and forecasted versus actual outcomes.  The process will outline how to diagnose the gaps and take corrective actions.  The forecast metrics need a comparison to some goal to indicate whether that forecast is on track or above/below a specific target.  When the forecast is below the goal, it alerts the marketing team to take corrective actions to improve results, which is a primary purpose of forecasting.  Over time, the firm needs and experience will shape the process for when alerts should trigger actions.  For each period, the forecast is updated and the most recent period is replaced with actual results.  Standard practice seems to be to discard the previous forecast as it is replaced with a more current version.  But there is significant value in comparing the actual value to prior forecasts to improve the forecasting accuracy and to provide full disclosure of the forecast changes to stakeholders.\n").padding(10)
                        Text("Marketing managers’ forecasting needs vary considerably.  They may need to forecast the size and growth of a market or product category.  When strategic issues are being considered, they need to forecast the actions and reactions of key decision makers such as competitors, suppliers, distributors, governments, their own actions, and complementor’s (firms with whom they cooperate) actions.  These actions can help to forecast market share.  The resulting forecasts can permit a sales forecast to be calculated.  If strategic issues are not important, sales can be extrapolated directly.  Finally, by forecasting costs and using the sales forecast, profits and other financial outcomes can be forecasted.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Forecast Trends")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("A requirement to understand the external environment is the ability to forecast trends.  As such, an important environment monitoring analytics solution involves accurate and reliable forecasts.  These forecasts encompass the results of a firm’s strategic and tactical decisions under various identified alternative decision scenarios.  These analytic solutions should provide information and models for estimating and predicting the market demand for products and services, the market potential for those products and services, the firm’s competitive position in the market, and the market share.  These analytic solutions also provide tools and resulting solutions for forecasting future unit and dollar sales as well as profits for a given product line or for a strategic business unit (SBU) within a specified time period with a given level of resources.  A forecast, then, is what the firm expects to achieve under given conditions and may provide target performance standards for the firm, its functional units, and individual personal forecasts.  Forecasts can be calculated at several levels depending on the analytic problems of the decision-maker.  Forecasts can be stated at industry, market, market segment, firm, product, and/or product item level.  Forecasts are used to solve such analytic problems of market entry, as inputs for sales forecasts, and monitoring deviation from actual sales.  One component of the forecasting analytics is in forecasting growth.  Historical data can provide a useful perspective for achieving this task.  However, the interest is not on projections of the past, but rather on the prediction of the turning points in that data.  In addition, the interests are on the rate and direction of the change.  Market sales forecasts, especially new product sales, can be based on the experience of similar industries or similar products and services.  Using a prior market or market segment with similar characteristics, the sales of new product or service offerings can be forecasted expecting that this new product or service will follow a similar sales history.\n").padding(10)
                        Text("Given the importance of forecasting for the firm, it is important to briefly examine the uses of forecasting and the forecasting methods.  The importance of forecasting is tacitly understood because of the variety of uses forecasting has in the decision-making process.  Forecasting may provide the marketing manager with a five-year view of the market or market segment for a particular product or service which would take numerous external factors into account.  Forecasting may provide the marketing manager with insight into the inventory demands for the next quarter which should influence the purchasing, scheduling, and sales functions of the firm.  Each of these forecasting scenarios contains two unique components: a time series component and a causal factor component.  Forecasts look at what will happen over an identified time period and what will influence this prediction.\n").padding(10)
                    } // Section 7
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.1 Customer Behavior Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
