//
//  C07S03T00.swift
//  Book_Sources
//
//  Chapter 07 Section 03: Topic 0: Overview
//  Created by SBAMBP on 04/27/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
////    // usage: Image(name: "imageNameHere.jpg"
////    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C07S03T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.3.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Forecasting Techniques")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("There are a variety of qualitative and quantitative forecasting techniques.  The two most commonly used forecasting analytics methods are time series algorithm and regression-based forecasting.  The time series algorithm represents a quantitative forecasting technique.  The time series data-mining algorithm can be used by the marketing manager to predict continuous variables over an identified time period.  The historical transactions in the data warehouse can provide the required information to perform this algorithm.  The underlying assumption for utilizing historical transactions is that the past patterns will continue into the future.  Hence, identifying the turning points and reasons for those turning points is important to successfully using these patterns.  One of the benefits of using the time series algorithm is that it can use cross-variable correlations in its predictions.  Cross-variable correlation allows the marketing manager to evaluate or project current patterns at one location by using the past patterns from another location.  The marketing manager can develop a series of questions from various analytics.  These questions could include, “How do sales fluctuate throughout the year?”, “Is there a sales pattern that can be identified?”, and “Do the product sales interact?”.  These questions help the marketing manager understand the manifested patterns and discern trends, seasonality, and other cyclical movements.\n").padding(10)
                    Text("In addition to the time series, the other component to the forecast is ascertaining the various causal factors.  The marketing manager develops a forecasting model containing various factors that may influence the forecast.  The relative influence of each of these factors in a mathematical model produces a regression equation.  This regression equation can then be used by the marketing manager in “what-if” analysis and understanding incremental allocation of resources.  Creating this model requires a detailed understanding of the identified factors or variables of interest.  The marketing manager is looking to include elements in the forecast that are related to or influence the desired outcome variable.  The marketing manager must be careful not to include variables or factors that are randomly related.  As such, the marketing manager must clearly understand the issue being forecasted.\n").padding(10)
                    } // Section 1
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.3 Forecasting Analytics Generation, Interpretation, and Application ", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
