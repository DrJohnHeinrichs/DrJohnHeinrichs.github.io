//
//  C07S03T02.swift
//  Book_Sources
//
//  Chapter 07 Section 03: Topic 2: Regression Based Method
//  Created by SBAMBP on 4/27/20.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
////    // usage: Image(name: "imageNameHere.jpg"
////    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C07S03T02: View {
    var topicTitle: String = "Topic Title"

    @State private var showingFigure72Sheet1 = false
    @State private var showingTable75Sheet1 = false
    @State private var showingTable76Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Regression Based Method
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.3.2 Regression Based Method ").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("7.3.2.1 Regression Model ")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Regression analysis is a directed data-mining approach that is used in the high-end of data mining.  Regression analysis focuses on causal identification between the various drivers and the targets.  Regression analysis presents a mathematical form that describes the relationship between explanatory or independent variables and predicted or dependent variables.  The simple linear regression form is expressed in a mathematical equation as Y = b0 + b1X where Y is the dependent variable of interest to the marketing manager and X is the independent variable of interest with b1 representing the degree of association between the independent and dependent variables and b0 representing the intercept of the initial level.  Regression analysis can be used for categorical variables to answer questions to determine if the consumer will purchase a product or respond to an event, or for continuous variables, to answer questions regarding the relationship between sales and advertising.\n").padding(10)
                    Text("Regression analysis can be used to identify statistically significant relationships between various facts or measures.  Then, the marketing manager can use regression analysis to create a model to forecast future trends or events and then to make predictions.  These defined models can also identify how changing the level of a particular independent variable actually changes the dependent or target variable.  Regression models can be used in determining pricing policies for the firm.  Regression models can help determine if pricing changes affect the particular demand of the product or service.  \n").padding(10)
                    Text("Regression analysis techniques base its model on a mathematical equation or series of equations; whereas neural networks base their models on computer programming.  Both techniques attempt to quantify relationships between explanatory variables and the target variable with the objective of achieving a minimized error in the difference between historical data and data-mining model projections.  Once the marketing managers have developed the model, they can forecast into the future or conduct “what if” analysis. \n").padding(10)
                    Text("Multiple linear regression is a popular forecasting tool that captures trend and seasonality.  A linear regression model is estimated with actual sales data and used for forecasting future sales.  First, a regression forecasting model with trend is discussed followed by a regression model with trend and seasonality.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    // ----------------------
                    Text("7.3.2.2 Regression Model with Trend").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("In a regression model that captures a linear trend, time index is set as a predictor variable with the dependent variable (Y) as the time series sales values.  To obtain a linear relationship between sales and time, sales is set as the dependent variable Y and time index = 1, 2, 3, - - -, n as the single independent predictor variable in the regression model.  The resulting regression model is: \n").padding(10)
                    Image(uiImage: UIImage(named: "Equation-7-11.jpg")!)
//                    Image(name: "Equation-7-11.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.bottom, 30)
                    Text("In this regression model, three time series components are modeled.  β0 represents level (intercept), β1 represents trend, and ε represents noise.  In this model, seasonality is not modeled.  The sample input data for this forecasting model is presented in Table 7-4.\n").padding(10)
//                        Image(uiImage: UIImage(named: "Figure-7-2.jpg")!)
//                        Image(name: "Figure-7-2.jpg")
//                            .resizable()
//                            .scaledToFit()
//                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
//                            .aspectRatio(contentMode: .fit)
//                            // .frame(width: geo.size.width)
//                            // .frame(width: UIScreen.main.bounds.width, height: 200)
//                            .frame(width: 400, height: 200)
//                            .scaleEffect(self.scale1)
//                            .gesture(MagnificationGesture()
//                            .updating(self.$scale1, body: { (value, scale1, trans) in
//                                scale1 = value.magnitude
//                                })
//                            )
//                            .padding(.bottom, 30)
//                        Button("Click for ... Figure 7-2: Sample Input Data for Regression Model with Trend") {
//                            self.showingFigure72Sheet1.toggle()
//                        }
//                        .font(.caption)
//                        .foregroundColor(.blue)
//                        .sheet(isPresented: $showingFigure72Sheet1) {
//                            Figure72View1()
//                        }
                    } // Section 5
                    // ----------------------
                    // ----------------------
                    Text("7.3.2.3 Regression Model with Trend and Seasonality").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                            VStack {
                    Text("In time series forecasting, some time series may exhibit a seasonal pattern.  These seasonal patterns must be captured to generate accurate forecasts.  Marketing managers have to incorporate the seasonal sales pattern in sales forecasts.  Seasonal patterns depend on the products a firm sells and may have day-of-week patterns, monthly patterns, or quarterly patterns.  Seasonality is represented by dummy variables that are incorporated as independent variables in the regression equation.  Dummy variables denote the session for each data point in the dataset.  For the quarterly pattern time series, the regression model with trend and seasonality is: \n").padding(10)
                    Image(uiImage: UIImage(named: "Equation-7-12.jpg")!)
//                    Image(name: "Equation-7-12.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.bottom, 30)
                    Text("In this regression model, all four time series components are modeled.  β0 represents level, β1, β2, β3 represents seasonality, β4 represents trend, and ε represents noise.  In this model, seasonality is modeled.  The sample input data for this regression model is presented in Table 7-5.\n").padding(10)
                            }
                    Text("Table 7-5 presents the same sales data shown in Table 7-4.  However, the input data is set differently.  The trend is captured as an independent variable t.  The three dummy variables are created to capture four quarters of a year.  The four quarters in a year are captured by three dummy variables in the table.  The regression equation can be estimated using the input data.\n").padding(10)
                        Image(uiImage: UIImage(named: "Table-7-5.jpg")!)
//                        Image(name: "Table-7-5.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 7-5: Sample Input Data for Regression Model with Trend") {
                            self.showingTable75Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable75Sheet1) {
                            Table75View1()
                        }
                            VStack {
                        Text("An example of regression analysis output is presented in Table 7-6.  Table 7-6 shows typical regression analysis output tables.  The output table shows that the regression model is supported by the data with R-square value of 0.996 and significant F-value of 199.49.  The four independent variables show significant t-values with p values less than 0.05.  The significant negative coefficients for Q1 (β1 = -502.5, p < 0.05) and Q2 (β2 = -1335, p < 0.05) suggest that there exists negative seasonal effect in quarter 1 and quarter 2.  The significant positive coefficient for Q3 (β3 = 342.5, p < 0.05) indicates the positive seasonal effect in Quarter 3.  The significant positive coefficient (β4 = 37.5, p < 0.05) for t representing trend indicates a general linear increasing trend.  The regression equation becomes:\n").padding(10)
                        Image(uiImage: UIImage(named: "Equation-7-13.jpg")!)
//                        Image(name: "Equation-7-13.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .padding(.bottom, 30)
                        Text("The forecasted sales of year 3 Quarter 1 can be calculated as 1,935 (2100 – 502.5(1) –1335(0) + 342.5(0) + 37.5(9)).  The forecasted sales of year 3 Quarter 2 can be calculated as 1,140 (2100 – 502.5(0) –1335(1) + 342.5(0) + 37.5(10)).  Similarly, any future quarter sales can be calculated using this regression equation that accounts for both trend and seasonality.\n").padding(10)
                            }
                        Image(uiImage: UIImage(named: "Table-7-6.jpg")!)
//                        Image(name: "Table-7-6.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale3, body: { (value, scale3, trans) in
                                scale3 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 7-6: Sample Regression Analysis Output") {
                            self.showingTable76Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable76Sheet1) {
                            Table76View1()
                        }
                        Text("Marketing managers need to evaluate forecast accuracy in utilizing forecasted values in marketing decision making.  The measures used for evaluating forecasting accuracy include mean squared error (MSE), root mean squared error (RMSE), mean absolute percent error (MAPE), and mean absolute error (MAE).  These values are either provided by software tools or can be calculated by marketing managers.  As the error estimates represents the forecast for the period forecasted, marketing managers need to make assumptions about the structure of error distribution.  The values of these measures will be different and interpreted differently for models incorporating trend and seasonality versus those without trend and seasonality components in the model.\n").padding(10)
                    } // Section 6
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.3 Forecasting Analytics Generation, Interpretation, and Application ", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 7-2 VIEW
// ------------------------------
struct Figure72View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 7-2: Sample Input Data for Regression Model with Trend")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-7-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 7-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 7-5 VIEW
// ------------------------------
struct Table75View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 7-5: Sample Input Data for Regression Model with Trend and Seasonality ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-7-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 7-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 7-6 VIEW
// ------------------------------
struct Table76View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 7-6: Sample Regression Analysis Output")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-7-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 7-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
