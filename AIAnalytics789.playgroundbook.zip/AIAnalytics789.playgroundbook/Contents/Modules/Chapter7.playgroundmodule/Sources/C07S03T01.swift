//
//  C07S03T01.swift
//  Book_Sources
//
//  Chapter 07 Section 03: Topic 1: Time Series Based Forecasting Model
//  Created by SBAMBP on 04/27/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
////    // usage: Image(name: "imageNameHere.jpg"
////    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C07S03T01: View {
    var topicTitle: String = "Topic Title"

    @State private var showingFigure71Sheet1 = false
    @State private var showingTable73Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Time Series Based Forecasting Model
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("7.3.1 Time Series Based Forecasting Model").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Sales forecasting is done by modeling time series data.  A time series is the observations of sequential numerical values at successive points in time.  To perform forecasting analysis, the time series analytics algorithm is employed.  Various parameters in the time series algorithm that are under the control of the marketing manager include the ability to set the sensitivity of detecting periodicity in the data values, the ability to set the missing value default to a previous value, the mean value or a chosen constant value, and the ability to indicate how often an identified pattern repeats itself in the data.\n").padding(10)
                    Image(uiImage: UIImage(named: "Figure-7-1.jpg")!)
//                    Image(name: "Figure-7-1.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale1)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale1, body: { (value, scale1, trans) in
                            scale1 = value.magnitude
                            })
                        )
                        .padding(.bottom, 30)
                    Button("Click for ... Figure 7-1: Time Series Forecast Line") {
                        self.showingFigure71Sheet1.toggle()
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure71Sheet1) {
                        Figure71View1()
                    }
                    Text("After the time series analytics model is created and processed, the marketing manager can view and begin the interpretation of the forecasted results.  The time series chart is used to investigate trends in the data.  The time series analytics algorithm creates a separate model for each chosen time series so that if the marketing manager is evaluating dollar sales and quantity sold for five different product lines, then ten different time series models will be created.  The time series chart shown in Figure 7 1 graphically displays the time series forecast line for each of the predicted variables.  The marketing manager can visually determine both the historical data and the projected future data with the future data containing the expected deviations.  \n").padding(10)
                    Text("Time series or sequencing is a data-mining approach or algorithm that examines data over a particular time period.  It is used for forecasting future activity in the next time period.  Additionally, it can be used to investigate the sequence in which events unfold.  Forecasting is predicting the future values on the basis of past values by the means of a forecasting algorithm.  The forecasting algorithms assume that the trends and cycles observed in the past time periods will continue into the future.  Univariate forecasting is defined as predicting a variable based upon a single factor; whereas multivariate forecasting is defined as predicting a variable based upon multiple factors.  For example, multivariate forecasting would be predicting store sales based upon the level of advertising expenses, past sales at that store, and upon the price level of given products.  Using the time series algorithm, one or more variables can be predicted; however, the variables to be predicted must be continuous.\n").padding(10)
                    Text("In time series analysis, a time series is modeled to identify four components of time series.  These four components are level, trend, seasonality, and noise.  Level represents the average value of the series.  Trend is a pattern showing the gradual movements over a long period of time.  The trend pattern can be linear or non-linear.  Seasonality refers to recurring pattern over successive periods of time.  Noise is the random variations due to measurement error or other external factors.  In identifying the components of time series, two common approaches are used.  The two common approaches are smoothing forecasting method and regression-based method.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    // ----------------------
                    Text("7.3.1.1 Smoothing Forecasting Method ").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The simplest forecasting method is a naïve forecasting method that uses the historical data.  This method applies the time t1 value to time t2.  Three different commonly used approaches are available in the smoothing forecasting method.  The three approaches are the simple method, moving average method, and exponential smoothing method.  While all three approaches use the historical data, the way they calculate forecasting values are different.  Table 7 3 presents a sample sales data and forecasted sales using the three smoothing approaches.\n").padding(10)
                    Image(uiImage: UIImage(named: "Table-7-3.jpg")!)
//                    Image(name: "Table-7-3.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale2)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale2, body: { (value, scale2, trans) in
                            scale2 = value.magnitude
                            })
                        )
                        .padding(.bottom, 30)
                    Button("Click for ... Table 7-3: Time Series Forecast Line") {
                        self.showingTable73Sheet1.toggle()
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable73Sheet1) {
                        Table73View1()
                    }
                    } // Section 2
                    // ----------------------
                    // ----------------------
                    Text("Simple Method").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The simple forecasting method applies the first week (t1) actual sales as the forecasted sales for week 2 (t2).  This method applies the week 2 actual sales to week 3 sales forecast, and so on.  As shown in Table 7 3, the sales amount for 10-week periods are presented with the forecasted sales using the simple forecasting method.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    // ----------------------
                    Text("Moving Average Method ").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The second approach is moving average method.  This method intends to smooth out random fluctuations in the time series.  The moving average method applies the average value of the most recent n data values in the time series as the forecast for the next period.  The moving average equation is:\n").padding(10)
                    Image(uiImage: UIImage(named: "Equation-7-9.jpg")!)
//                    Image(name: "Equation-7-9.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.bottom, 30)
                    Text("For example, if managers decided to use 3 periods (n = 3), time period 4 (t4) sales forecast is calculated as: y ̂4 = (10 + 15 +11) / 3 = 12.33.  Similarly, time period 5 (t5) sales forecast is calculated as: y ̂5 = (15 +11 +18) / 3 = 14.67.  Using the similar calculation formula, the rest of the periods’ sales forecast values can be calculated.  The forecasted values are shown in Table 7-3.  \n").padding(10)
                    } // Section 4
                    // ----------------------
                    // ----------------------
                    Text("Exponential Smoothing Method").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The third approach is exponential smoothing method.  This method utilizes a weighted average of actual sales and forecasted sales of the previous period as a forecast.  By applying the smoothing constant α (weight) to the actual sales value in the period t - 1, and (1 – α) to the forecasted value in the period t -1, the forecast for the period t are estimated.  The range of the smoothing constant can be set between 0 and 1 (0 ≤ α ≤ 1).  One important assumption is that the forecasted value of the time series in period 2 equals the actual sales value of the time series in period 1.  The exponential smoothing formulas to be used for forecasting are: \n").padding(10)
                    Image(uiImage: UIImage(named: "Equation-7-10.jpg")!)
//                    Image(name: "Equation-7-10.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.bottom, 30)
                    Text("Using the exponential smoothing formula shown above, forecasting values for period 2 in Table 7-3 can be calculated as y ̂2 = 10.  Using α = 0.1, the sales forecast for period 3 is calculated as:  y ̂3 = 0.1(15) + 0.9(10) = 10.5.  The sales forecast for period 4 is calculated as:  y ̂4 = 0.1(12) + 0.9(10.5) = 10.65. \n").padding(10)
                    Text("Similar calculations can be done for the rest of the periods.  The forecasted values are shown in Table 7 3.  In exponential smoothing, managers can try different smoothing constant α to derive more accurate forecasts.  Larger value of the smoothing constant α allows managers to adjust the forecasts quickly to the changes in time series.  As a result, the forecasts can react more quickly to changing conditions.  \n").padding(10)
                    } // Section 5
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("7.3 Forecasting Analytics Generation, Interpretation, and Application ", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 7-1 VIEW
// ------------------------------
struct Figure71View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 7-1: Time Series Forecast Line ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-7-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 7-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 7-3 VIEW
// ------------------------------
struct Table73View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 7-3: Sample Sales Data and Forecasted Sales Using the Three Smoothing Approaches")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-7-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 7-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
