//
//  C08S01T02.swift
//  Book_Sources
//
//  Chapter 8: Market Basket Analysis for CRM Analytics
//  Section 1: CRM Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C08S01T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Managing Customer Relationships with Analytics
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("8.1.2 Managing Customer Relationships with Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Firm Goal")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The customer is the most important force in any firm.  The goal of the firm, then, should be to give the customer what they want, when they want it, and the way they want it.  Customer relationship management (CRM) software helps the firm implement customer-centric strategies.  CRM allows a firm to identify and target their most profitable customers.  Firms can focus on retaining these people as lifelong customers.  CRM analytics enables real-time customization and personalization of products and services based on the customer’s wants, needs, buying habits, and life cycles.  CRM analytics provides functionality for marketing and fulfillment, sales support, and customer service and support.  Key objectives include customer loyalty, attrition management, lifetime value analysis, churn, and response.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("CRM Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("CRM analytics helps firms identify and target profitable customers for sales incentives and customer reward programs with the objective to help the firm focus on customer retention and customer loyalty.  CRM analytics provides information on the distribution of the customer base to the general population.  CRM analytics allows marketing managers to develop value-based customer classification by providing the value of a customer in a long-term customer retention perspective.  The core of these analytics is calculating various measurement metrics such as lifetime value of a customer.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Categories")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("CRM analytics can be used to classify customers into various categories.  For example, the classification can include gold, silver, and bronze customers.  Alternatively, high, medium, low, and subzero categories can be used.  These analytics solutions are also used to identify loyal customers and evaluate their worth to the firm, calculate the threshold level of special offers, and develop detailed customer retention strategies for a particular type of customers.  Firms are using these analytic patterns and models to increase retention rates, average order value, and profits per customer over time.  The same information can be used to reduce defection rates, churning, and interactions with the least profitable customers.  Some customers cost more than they contribute to the firm.  Unprofitable customers tend to place many small orders, habitually ordering products or service and then returning them, or contact customer services and tie-up call center lines.  The analytics model can identify these customers and provide managers tools to remedy this undesirable situation and to increase marketing efficiency.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Retention")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The emphasis on customer retention in customer relationship management generates various metrics measuring the impact of customer care programs and actions.  One important task is quantifying the expected results of CRM programs and activities.  Using the database of multi-year revenue history of customers, a firm can calculate the expected revenue from a new customer.  The analytics can also provide a model that measures the financial profit from increasing customer retention.  Customer lifetime value can be used to derive expected profit from customer retention.  Using this model, a firm can calculate the break-even point of customer care costs compared to increase in revenue due to retention of loyal customers.  Customer care programs can affect the retention rate and customer satisfaction.  Although improved customer care increases retention rate and profits, the cost of offering the improved customer care should be considered.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Value Matrix")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("CRM analytics can be used to develop the customer value matrix (CVM) that involves understanding the customer base with respect to revenue and risk.  The firm should segment the customer base by profitability to enable improved customer relationship management.  The segment should be assigned a value for revenue (high / low) and a value for risk (high / low).  This information can be useful in developing marketing strategies.  The customer value matrix (2x2) categories are labeled consummate consumers that are in the most profitable (low risk and high revenue) cell, risky revenue, business builders, and balance bombs.  CRM analytics can help the sales team by tracking customer contacts and other events of customers for the purpose of cross-selling and up-selling.  CRM analytics can help a firm provide a consistent customer experience and superior service and support across all contact points.  It assists customer service representatives in helping customers who are having problems with a product or service by providing relevant data and suggestions for solving their problems.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Engage with Customers")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("With the increased importance of customer relationship marketing, marketing managers have more opportunity to engage with customers.  In interacting with customers, managers can provide personalized recommendations based on other customers who purchased a similar set of items.  They can do cross-selling or up-selling of products or services associated with an item that customers are considering.  An important task of marketing managers is determining what type of products to recommend or cross-sell to a particular customer.  Analytic question related to this task is to understand which products are purchased together.  In other words, which items are co-purchased with the first item purchased by that customer?  Managers are interested in knowing whether certain items are consistently purchased together.  With increased online or mobile purchase by customers, managers need to decide in online store front design which items to display or recommend to online shoppers when they are examining an item or putting an item in the shopping basket.  Marketing managers focus on selling more products or services to existing customer through cross-selling or motivate them to trade up to more profitable products with cross-selling and un-selling, marketing managers want to know which products will increase a customer’s overall profitability by selling the right product to the right customers.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("8.1 CRM Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct


