//
//  C08S01T01.swift
//  Book_Sources
//
//  Chapter 8: Market Basket Analysis for CRM Analytics
//  Section 1: CRM Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C08S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Customer Relationship Management Analytics
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("8.1.1 Customer Relationship Management Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Customer relationship analytics is the process of gathering data about customers and their relationship with the firm in order to improve the firm’s future sales and service and lower cost.  As websites have added a new and often faster way to interact with customers, the opportunity and the need to turn data collected about customers into useful information has become generally apparent.  As a result, a number of software companies have developed products that do customer data analysis.  According to an article in TechTarget, customer relationship analysis can provide customer segmentation groupings (at its simplest by dividing customers into those most and least likely to repurchase a product); profitability analysis (which customers lead to the most profit over time); personalization (the ability to market to individual customers based on the data collected about them); event monitoring (when a customer reaches a certain dollar volume of purchases); what-if scenarios (how likely a customer or customer category that bought one product to buy a similar one); and predictive modeling (comparing various product development plans in terms of likely future success given the customer knowledge base).  Data collection and analysis are viewed as a continuing and iterative process and ideally over time business decisions are refined based on feedback from earlier analysis and consequent decisions.  Benefits of customer relationship analysis are said to lead not only to better and more productive customer relations in terms of sales and service but also to improvement in supply chain management.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    .padding(10)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Role of CRM")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Progress in Information Technology (IT) and organizational changes in customer-centric procedures have positive effect on the development of customer relationship management (CRM).  Firms which implement CRM successfully will gain customer loyalty and profitability.  Today, CRM plays the pivotal role for strategic position of a firm.  CRM focuses on the integration of customer information, knowledge for finding and keeping customer to grow customer lifetime value.  It also plays an important role in helping firms to keep existing customers and to make them loyal.  Firms should know the reasons of leaving customers and finding the ways of keeping them.  Therefore, CRM’s role is important in customer retention.  By preparing employees with fast access to customer’s data, firms can better recognize the right customers and enhance their loyalty.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Text(" ")
                        } )
                        {
                        // ----------------------
                        VStack(alignment: .leading) {
                            Text("Retain and Keep the Right Clientele\n")
                            .italic().padding(10)
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            }
                        Text("Effectual customer preservation starts with information and knowledge.  Firms ought to collect an absolute customer profile that provides all demographic information, communications and interactions, and purchasing information.  This data/information, together with strong segmentation and analysis instruments, allows firms to measure the productivity and the profitability of every customer.  Firms can then make plans and policies proportionate with the customer’s profitability.  One efficient manner to increase and to maximize revenue chances is by increasing the marketing mix.  In order to implement this, however, marketing requires end-to-end visibility into marketing information throughout a united CRM request.  Firms ought to be able to rapidly make campaigns, deal out communications, track answers and qualify guides.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("8.1 CRM Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct

