//
//  C08S01T00.swift
//  Book_Sources
//
//  Chapter 8: Market Basket Analysis for CRM Analytics
//  Section 1: CRM Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C08S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("8.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Segmentation")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In customer relationship-driven marketing, the traditional segmentation approach could be used to better serve customers and to build stronger customer relationships.  Market segments are based on typical segmentation variables such as demographics or psychographics.  However, the segmentation process can be done differently based on customer lifetime value as well as on patterns and insights generated from detailed analyses of customer behaviors and purchases.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Lifetime Value")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The basic prerequisite for the customer relationship-driven marketing is knowledge of individual customer lifetime values for the customer base.  Customer lifetime value (CLV) is rapidly gaining acceptance as a metric to acquire, grow, and retain the “right” customers in customer relationship management.  The various components of CLV include purchase frequency, contribution margin, and marketing costs: however, the various CLV components can vary depending on the industry.  Some of the antecedents of purchase frequency and contribution margin (e.g., marketing communications) are under the manager’s control and affect the variable costs of managing customers.  Knowing the individual CLV’s of existing customers and the CLV distribution in the customer base along with psychographic and socio-demographic data for the relevant customers would allow firms to make efficient allocation of marketing resources.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Lifetime Value Definition")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The lifetime value is defined as the value of the customer for any customer and customer segment x and calculated by subtracting the future lifetime costs (CC) from the future lifetime revenue (CR).  In applying this formula, the marketing managers can make forecasts of lifetime duration based on previous experience with that customer and other similar customers.  The CRs vary from customer to customer and depend on various factors.  Customers vary in the number and mix of products purchased over time and the size, growth, and distribution of share of wallet over time.  The CC can be calculated by adding product costs and costs to serve the customer.  The future lifetime costs are typically allocated proportionally to sales volume or value.  As firms realize that some customers are far costlier to serve than others, activity-based costing can be used to determine appropriate allocation to customers.  Using these steps, marketing managers can determine the firm’s current customer equity for its current customer portfolio.  Various marketing strategies can be developed and implemented to increase customer equity in many firms which adopt the customer relationship-driven marketing.  The relative importance and emphasis given to customer equity compared to brand equity can vary depending on the segments’ CLV, preferences, value drivers, and purchase patterns.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Equity")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Customer relationship-driven marketing focuses on customer equity rather than product or brand equity.  This can be achieved by putting emphasis on the ‘relationship’ rather than the ‘transaction’.  In this sense, customer relationships are considered as the most critical assets of a firm.  This implies that a firm must manage customer relationships just like other assets of a firm.  This implies that customer relationships must be selectively managed and enhanced to improve customer retention and profitability.  Under this marketing approach, customers are not viewed as a group or audience who receives and responds to a range of marketing and promotional activities.  Customer equity is represented by future profit stream generated over a customer’s lifetime.  Firms will focus on growing customer equity and its market value just like any other valuable assets of the firm.  Growing customer equity puts emphasis on identifying the most profitable customers and on developing these relationships.  This, in turn, increases the asset value of the total customer base and the firm’s market value.  In many cases firms will determine that some customers are expensive to obtain and keep but this may not always be the case.  Customers that are expensive to obtain in the beginning may prove just as profitable in the long run.  Research suggests that there is no direct correlation between profitable customers in the long run and the initial costs of obtaining and retaining them.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("8.1 CRM Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
