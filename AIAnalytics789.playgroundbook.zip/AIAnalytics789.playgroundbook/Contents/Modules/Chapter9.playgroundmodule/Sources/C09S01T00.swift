//
//  C09S01T00.swift
//  Book_Sources
//
//  Chapter 9: Conjoint Analysis for New Product Design and Development Analytics
//  Section 1: New Product Design and Development Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C09S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("9.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Advantage")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("If you have a product or service that everyone needs and no one else offers, it's easy to be the best.  Unfortunately, that's not a reality for most firms today.  To succeed in the real world, firms need every advantage they can get.  Many CEOs agree that the way to win is to build and manage their firm’s new products.  From a brand management perspective, brand valuation is a strategic tool that brings together market, brand, competitor, and financial data into a single, value-based framework within which the performance of the brand can be assessed, areas for improvement identified, and the financial contribution of the brand to the firm results quantified.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Product Features")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("By combining strategy, analytics, and valuation to determine the expected impact of brand investment on the top and bottom line, marketing managers need to make decisions regarding the expected change in product features.  Strong new products usually enhance business performance by influencing three current or prospective key stakeholder groups: customers, employees, and investors.  They influence customer choices and create loyalty; attract, retain, and motivate talent; and lower the cost of financing.  The influence of new products on current and prospective customers is a particularly significant driver of economic value.  The relevant and differentiated new products consistently help shape attitudes and, therefore, purchase behavior, making products and services less substitutable and demand more sustainable.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("New Product Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("What differentiates firms from their competitors is their ability to also provide a rich and insightful new product analysis, delivering value to the firm beyond the number alone.  Product attribute analysis helps firms better understand the drivers of business and brand value.  Understanding how value is created, where it is created and the relationship between brand value and business value is a vital input to strategic decision making.  Determining product attributes shows what makes products distinct from other products.  Attributes can include size, color, flavor, and packaging.  From a consumer’s perspective, these attributes are what determine the consideration set and influence the ultimate purchase decision.  From a retail perspective, product attributes help define how aisles, departments, and shelve sets are organized.  Manufacturers use attributes to help define their product’s competitive advantage.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Product Attributes")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Some problems marketing managers face when dealing with product attributes is, “What kind of message does the brand give?” and “Does the brand and product create customer loyalty and emotionally connect with the target market?”.  Marketing managers need to know if the target market is aware that they are being targeted and does the brand share the uniqueness of what the firm offers and why it’s important?  Managers would want to know if their products have what it takes to succeed in today’s increasingly competitive marketplace.  Knowing why the brand or product is of value will explain what types of problems it can solve for customers and if it is even something customers will care about or want/need.  When people think about the firm or product, what are the feelings and associations managers want them to have?  Are they unique?  Can the firm “own” them?  What are the functional benefits that the firm delivers to its customers?  What are the emotional benefits that only the firm delivers to its customers?  All of these questions have to do with what value can the brand or product give and is it relevant to who is being targeted.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Needs of Target Customers")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The most important task marketing managers are facing is developing a product that meets the needs of the target customers.  With the high rate of new product failure rate, marketing managers must identify product opportunities and develop the right new products for market success.  For this important task, marketing managers need to determine the customer preferences and how customers value the different product attributes.  In addition, managers want to know the trade-offs customers are willing to make among the different product attributes and features a firm can develop.  Typical analytic questions marketing managers want to answer is which set of product attributes are optimal for the target market segment(s).  While firms have information about available product attributes to be incorporated in the product, managers need to identify as precisely as possible the product attribute combination for the target segment.  The key is determining the importance of various product attributes as well as relative importance of individual attributes.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("9.1 New Product Design and Development Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
