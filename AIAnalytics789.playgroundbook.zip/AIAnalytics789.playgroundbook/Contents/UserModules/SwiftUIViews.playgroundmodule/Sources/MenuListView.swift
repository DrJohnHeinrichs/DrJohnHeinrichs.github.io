import SwiftUI
public struct MenuListView:View{
    var menuItems:[MenuItem]
    var backgroundColor:Color
    public init(menuItems:MenuItems,backgroundColor:Color){
        self.menuItems = menuItems.menuItems
        self.backgroundColor = backgroundColor
    }
    public var body: some View{
        
        List(menuItems){ item in
            HStack(alignment: .top){
                Image(uiImage: UIImage(named: "\(item.id)_100w.jpg") ?? UIImage(systemName: "\(item.id).square")!)
                .cornerRadius(5)
                    .shadow(color: .black, radius: 3, x: 2, y: 2)
                    Text(item.name)
                    Spacer()
                Text(dollarFormat(value: item.price))
                        .foregroundColor(.green)
            }
        .padding()
            .background(self.backgroundColor)
        .cornerRadius(5)
        }
        
        
        
    }
}

