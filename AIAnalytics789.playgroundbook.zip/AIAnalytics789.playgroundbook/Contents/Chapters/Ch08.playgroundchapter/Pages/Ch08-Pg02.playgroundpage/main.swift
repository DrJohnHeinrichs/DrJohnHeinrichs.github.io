//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Market Basket Analysis Solution Generation.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    
    @State private var showingTable81Sheet1 = false
    @State private var showingTable82Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("8.2.0 Overview")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                            Text("To answer the analytic question of which products are purchased together for product recommendation, cross-selling, and up-selling, marketing managers can choose the market basket analysis from the analytics toolbox.  The next section describes the market basket analysis also called affinity analysis or association rules method.  Market basket analysis aims to discover which group of products tend to be purchased together using customer transaction data.  Market basket analysis can show customer preference patterns and provide answers to the question of what products are ordered or purchased together.  Using customer transaction databases, association rules are identified to determine dependencies between purchases of different items.  Association rule modeling begins with generating an item set of collection of items selected from all items in the transaction database.  Item sets can include two, three, or more items.  A association rule identifies two subsets in each item set using an ‘if-then’ format.  One subset, the antecedent, is considered as preceding the other subset and represent the ‘if’ part.  The other subset, the consequent, represents the ‘then’ part.  In market basket analysis, the item sets consists of the antecedent and consequent.\n").padding(10)
                            Text("Association is an approach that measures the probabilities or likelihood of the occurrence of a particular event given the occurrence of other events.  This data-mining technique looks for patterns of repetition in the data.  It scans the data looking for an association between one set of items and another set of items.  Market basket analysis is one example or outcome of this approach.  Market basket analysis explores the probability or percentage occurrence that a consumer who purchases product A and B will also buy product C.  Association analysis can be used for determining cross-selling and up-selling opportunities.  It can be used to identify the purchasing patterns of customers.  The firm can use this information to determine where to place items that are associated together in a display area.  Common associations include wine and cheese, batteries and toys, pencil and paper, and the often heard, beer and diapers.\n").padding(10)
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Attribute/Value Pair")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                            Text("The association data-mining algorithm considers each attribute/value pair (such as product/bread or region/Midwest) as an item.  An item set then becomes a combination of items in a single transaction.  The algorithm scans through the data trying to find various item sets that tend to appear together in many transactions.  For example, a frequent item set may contain Product = “Mountain Bicycle”, and Option = “Water Carrier”.  Each item set also has a size, which is defined as the number of items it contains.  In this example, the size for this item set is 2.  Often association models work against datasets containing nested tables.  A nested table example could be a customer table followed by a nested purchases table.  If a nested table exists in the dataset, each nested key (such as a product in the purchases table) is considered an item.  The association algorithm finds rules associated with item sets.  A rule in an association model looks like A, B=>C.  In the model, A, B, and C are all frequent item sets.  The ‘=>’ symbol implies that C is predicted by A and B.\n").padding(10)
                            Text("Association rules are generated to identify all possible combinations of items in the customer transaction database that can be single item, two items, three items, and so on.  As the generated association rules can be very large, managers need to select frequent items sets that occur often in the database.  To determine which item sets can be chosen as the frequent item sets, managers can use the selection criteria of support, confidence, and lift ratio.  The rule is evaluated based upon these three criteria.\n").padding(10)
                          } // Section 2
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Criterion")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                            Text("The first criterion, support, refers to prevalence of an item set.  Support is the number of transactions that include both the antecedent and consequent item sets.  The support measures the degree to which the data supports the validity of the rule.  If a marketing manager sets the minimum support criterion of 0.01, then any item sets that exceed the criterion of 0.01 will be the frequent item sets and will be included in the next phase of analysis.  A support criterion of 0.01 suggests that one in every one hundred market baskets must contain the item set.  The support helps the marketing manager by indicating how many transactions use this rule.  The goal is to have a relatively high support number.\n").padding(10)
                            Text("The confidence criterion refers to the degree of predictability of the if-then rule.  This criterion is an estimate of the conditional probability of the consequent, given the antecedent.  Confidence can be calculated by dividing the number of transactions with both antecedent and consequent item sets with number of transactions with antecedent item set.  For example, out of 10,000 grocery store transactions, 3,000 include both milk and bread, and 1,200 of these include jam purchases.  The association rule is “If milk and bread are purchased then jam is purchased on the same shopping trip.”  This association rule has a support of 12% (1,200/10,000) and a confidence of 40% (1,200/3,000).  While high value confidence indicates a strong association rule, confidence can be high if both the antecedent and consequent have a high level of support although the antecedent and consequent are not associated.  The probability threshold is a parameter that determines the minimum probability before a rule can be considered.  The probability is also called “confidence”.  As confidence is necessary condition for association, it is not sufficient to conclude the association.  Therefore, mangers need to evaluate the final criterion of lift ratio.  Lift ratio assess the strength of an association rule.  Lift ratio is calculated by dividing confidence with benchmark confidence assuming independence of consequent from antecedent.  The benchmark confidence is number of transactions with consequent item set divided by number of transactions in customer database.  In earlier grocery store transaction example, 2,500 transactions contain jam purchases out of 10,000 transactions.  The benchmark confidence is 25% (2,500/10,000).  Lift ratio of this rule is 1.6 (40%/25%).  As the rule is considered useful if the lift ratio is greater than 1.0, this association rule of 1.6 is considered as a useful rule.  The importance examines the usefulness of the rule.  It is a way to examine the importance of the causality of the data.  For example, all computers require a power supply.  By knowing that a power supply has been selected doesn’t help in determining the model of the computer.  Yet, the probability is 100% that if you have a power supply, you will have Model A of the computer.  No useful information is given to marketing managers. \n").padding(10)
                          } // Section 3
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
                    .navigationBarTitle("8.2 Market Basket Analysis Solution Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("8.2.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("8.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
            // ----------------------
            // Start: Topic 1 - Input Data
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Table 8-1: Input Data for Market Basket Analysis")) {
                            Text("The input data for the market basket analysis is transaction records of customers.  Input data used for market basket analysis includes information about three different entities of customers, orders (i.e., purchases or baskets) and items.  The order refers to a single purchase event by a customer such as a customer ordering several products online or purchasing a basket of groceries.  The order includes any relevant data about the transaction such as payment method, total amount, and purchased products.  Individual items in the order are represented as line items.  The transaction records contain a list of items purchased with each row representing a transaction.  Table 8-1 shows an example of transaction records in item list format.\n").padding(10)
                            Image(uiImage: UIImage(named: "Table-8-1.jpg")!)
//                            Image(name: "Table-8-1.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Table 8-1: Input Data for Market Basket Analysis") {
                                self.showingTable81Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable81Sheet1) {
                                Table81View1()
                            }
                              Text("For the market basket analysis, item list format data can be converted to the binary matrix format shown in Table 8-2.  With the input data, marketing managers can specify the criterion support level and confidence level for the analysis.\n").padding(10)
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
                    .navigationBarTitle("8.2 Market Basket Analysis Solution Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("8.2.1 Input Data")
                } else {
                    Image(systemName: "pencil")
                    Text("8.2.1 Input Data")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // ----------------------
            // Start: Topic 2 - Market Basket Analytics
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Table 8-2: Item List Format Data ")) {
                            Text("The concept of market basket analysis is in predicting what the customer might want based upon what the customer has already chosen or placed into their shopping basket.  The mining model utilizes the firm’s historical transaction to generate this prediction.  Market basket analysis, also known as product affinity analysis, can help marketing managers in their promotion strategy by informing which items tend to be purchased together.  If the customer is on the firm’s website doing online shopping, the firm can link these related items together or can place links from one item to the other item.  If the customer is shopping at the firm’s physical “brick-and-mortar” location, the items can be located together or various promotional signs can be displayed.\n").padding(10)
                            Image(uiImage: UIImage(named: "Table-8-2.jpg")!)
//                            Image(name: "Table-8-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Table 8-2: Item List Format Data") {
                                self.showingTable82Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable82Sheet1) {
                                Table82View1()
                            }
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                          // ----------------------
                          Section (header: HStack {
                              Image(systemName: "pencil")
                              Text("Associate Rules Algorithm")
                                  .font(.system(size: 20, weight: .heavy, design: .default))
                          } )
                          {
                              Text("To perform a market basket analysis, the association rules data-mining algorithm is employed.  Marketing managers can set various parameters for this algorithm including the maximum number of item sets created by the algorithm, the maximum or minimum number of items that are allowed in the item set, the item set size, the minimum generated probability that will be true, and setting the minimum absolute number or relative percentage of cases that must contain the item set before the rule is generated.  After creating the mining model structure, marketing managers can and should explore the data.  Marketing managers can sample, tabulate, or graph the data.  After the mining model is created and processed, marketing managers can view the results.  The association model provides marketing managers with information regarding the item set, the generated rules, and the dependency network.\n").padding(10)
                              Text("The item set contains information about the generated item sets.  Marketing managers can assess the support, the actual description of the various items in the item set, and the size of the item set.  Support is defined as the number of transactions that the generated item set appears in.  Size is defined as how many items are in the item set.  The rules contain additional information regarding the generated rule that the algorithm created.  The information provided includes the probability, the importance, and the rule definition.  The probability is defined as the likelihood of the generated rule occurring.  The importance is defined as a measure of the usefulness of the generated rule with higher values representing a better rule.  The rule definition is structured in the form of A, B → C.\n").padding(10)
                          } // Section 2
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
                    .navigationBarTitle("8.2 Market Basket Analysis Solution Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 2
            // ----------------------
            // End: Topic 2
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("8.2.2 Market Basket Analytics")
                } else {
                    Image(systemName: "pencil")
                    Text("8.2.2 Market Basket Analytics")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Input Data",
                        "-- Topic 2: Market Basket Analytics\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// TABLE 8-1 VIEW
// ------------------------------
struct Table81View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 8-1: Input Data for Market Basket Analysis")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-8-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 8-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 8-2 VIEW
// ------------------------------
struct Table82View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 8-2: Item List Format Data")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-8-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 8-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Market Basket Analysis for CRM Analytics
 ### Table of Contents - _Chapter 8_
 1. [Section 1: CRM Analytics Task](Ch08-Pg01)
 2. **[Section 2: Market Basket Analytics Generation](Ch08-Pg02)**
 3. [Section 3: Market Basket Analytics Interpretation and Application](Ch08-Pg03)
 4. [Section 4: AI Powered Recommendation System](Ch08-Pg04)
 */

/*:
 * Callout(Quote: CRM Analytics):
 "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency."
 \
 –Bill Gates
 */

/*:
 # Section 2: Market Basket Analytics Generation

 ## 2.1 Input Data

 ## 2.2 Market Basket Analytics
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

### Additional Information:
 For more information regarding **market basket analytics**, view the following ...
 * [The Swift Programming Language]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
