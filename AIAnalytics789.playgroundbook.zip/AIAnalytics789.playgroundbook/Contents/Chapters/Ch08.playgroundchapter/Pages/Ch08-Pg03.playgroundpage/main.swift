//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Conjoint Analysis Interpretation and Application.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    
    @State private var showingFigure81Sheet1 = false
    @State private var showingFigure82Sheet1 = false
    @State private var showingTable83Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Table 8-3: Market Basket Analysis Example Output")) {
                            Text("The market basket analysis output can be generated with the specified support level and confidence level.  The typical output showing 10 example association rules is shown in Table 8-3. \n").padding(10)
                            Image(uiImage: UIImage(named: "Table-8-3.jpg")!)
//                            Image(name: "Table-8-3.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Table 8-3: Market Basket Analysis Example Output") {
                                self.showingTable83Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable83Sheet1) {
                                Table83View1()
                            }
                          } // Section 2
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                          // ----------------------
                          Section(header: Text("Figure 8-1: Example Rules Generated ")) {
                              Text("In Table 8-3, the rules are ranked by lift and the top ten rules are displayed.  In interpreting the market basket analytics output, marketing managers need to evaluate the reported measures for each association rule.  As support is a relative frequency or probability estimates, the values will range from zero to one.  Low values indicate that those items are not as important as other items in the transaction.  The top ten rules show values between 0.024 and 0.046.  The value of 0.033 indicates that 3.3% of transactions contain the item sets of bread and cheese as the antecedent and jam as the consequent thus showing its impact in terms of overall size.  Considering the large number of affected transactions, this rule is considered useful.  As confidence is a conditional probability, confidence value rages from zero to one.  In Table 8-3, confidence ranges from 0.605 to 0.502 for the top 10 rules.  The confidence value of 0.605 for the first rule indicates that when a transaction contains bread and cheese, the estimated probability of jam also included is 60.5%.  Confidence is a relevant measure in determining usefulness of this rule for marketing decision applications.  The lift rages from 2.315 to 1.814.  For the rules to be considered useful, the lift value needs to be higher than 1.0.  In this example, as the lift values are significantly higher than 1.0, all top ten rules are considered useful for marketing decisions.  The lift ratio shows how efficient the rule is in finding consequences relative to random selection.  Marketing managers can use an association rule that has high confidence and lift with not too low support.  The criteria depend on the number of product items and purchasing patterns of customers of the firm.\n").padding(10)
                              Text("The dependency network contains information regarding the interaction of the various items in the mining model.  Each node in the network represents an item.  Figure 8-1 shows the example rules generated.\n").padding(10)
                              Image(uiImage: UIImage(named: "Figure-8-1.jpg")!)
//                              Image(name: "Figure-8-1.jpg")
                                  .resizable()
                                  .scaledToFit()
                                  .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                  .aspectRatio(contentMode: .fit)
                                  // .frame(width: geo.size.width)
                                  // .frame(width: UIScreen.main.bounds.width, height: 200)
                                  .frame(width: 400, height: 200)
                                  .scaleEffect(self.scale2)
                                  .gesture(MagnificationGesture()
                                  .updating(self.$scale2, body: { (value, scale2, trans) in
                                      scale2 = value.magnitude
                                      })
                                  )
                                  .padding(.bottom, 30)
                              Button("Click for ... Figure 8-1: Example Rules Generated ") {
                                  self.showingFigure81Sheet1.toggle()
                              }
                              .font(.caption)
                              .foregroundColor(.blue)
                              .sheet(isPresented: $showingFigure81Sheet1) {
                                  Figure81View1()
                              }
                          } // Section 3
                          .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                        Section(header: Text("Figure 8-2: Mining Accuracy Chart")) {
                            Text("To assess the predictive ability of the related product items, support, confidence, and lift measures are typically used in market basket analysis.  Support refers to the percentage of baskets where the rule was true (i.e., both the left and right-side products were present).  Confidence measures the percentage of baskets that contained the left-hand product also contained the right-hand product.  Lift measures how much more frequently the left-hand product is found with the right-hand product than without the right-hand product.  The mining accuracy chart can be generated to show how well each item can predict the purchase of the other items.  Figure 8-2 shows a mining accuracy chart.\n").padding(10)
                            Image(uiImage: UIImage(named: "Figure-8-2.jpg")!)
//                            Image(name: "Figure-8-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale3)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale3, body: { (value, scale3, trans) in
                                    scale3 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Figure 8-2: Mining Accuracy Chart") {
                                self.showingFigure82Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingFigure82Sheet1) {
                                Figure82View1()
                            }
                            Text("The market basket analytics provides marketing managers with information to generate insights regarding what type of products are purchased together.  The market basket analytics provides a degree of affinity among various types of products.  Products are related in varying degrees due to the complementary nature of the product usage or the special occasions that require the use of some set of products together.  These insights can be applied in many different application decisions.  Stores can use this insight to place these products in the same area.  Direct marketers can use this information to determine which new products to offer to their current customers.  Inventory policies can be improved if reorder points reflect the demand for the complementary products.  Marketing managers can use this insight to group product items in their web pages or recommend the complementary products for those visitors who purchased the target product.\n").padding(10)
                            Text("The association rules identified in the market basket analysis can be used by marketing managers in many different marketing decisions.  First, marketing managers can use the market basket analytics output to guide product placement in stores or product bundling recommendations for a specific customer groups or market segments.  Second, cross-category and co-marketing decisions can be made based on the insights generated from the market basket analytics.  Association data-mining models can be useful for determining cross-selling or up-selling opportunities.  For example, marketing managers can use an association model to predict items a consumer may want to purchase based on other items that the consumer has placed in the shopping basket.  Third, the analytics can also be used for building recommender systems in online and offline settings.  Finally, the association rule modeling can be used for collaborative filtering where products are recommended for customers who show similar ratings for other products.\n").padding(10)
                            Text("For practical managerial use, the rule must contain high quality and actionable information.  Marketing managers need to screen out trivial rules or inexplicable rules in applying the association rule modeling analytics.  Trivial rules are results that known by anyone in the business or the results of previous marketing campaigns.  The inexplicable rules refer to results that have no clear explanation or do not suggest a course of action.\n").padding(10)
                        } // Section 3
                        .listRowBackground(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
                    .navigationBarTitle("8.3 Market Basket Analytics Interpretation and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("8.3.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("8.3.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Market Basket Analytics Interpretation and Application\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.4510, green: 0.9882, blue: 0.8392, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// TABLE 8-3 VIEW
// ------------------------------
struct Table83View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 8-3: Market Basket Analysis Example Output ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-8-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 8-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 8-1 VIEW
// ------------------------------
struct Figure81View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 8-1: Example Rules Generated")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-8-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 8-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 8-2 VIEW
// ------------------------------
struct Figure82View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 8-2: Mining Accuracy Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-8-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 8-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Market Basket Analysis for CRM Analytics
 ### Table of Contents - _Chapter 8_
 1. [Section 1: CRM Analytics Task](Ch08-Pg01)
 2. [Section 2: Market Basket Analytics Generation](Ch08-Pg02)
 3. **[Section 3: Market Basket Analytics Interpretation and Application](Ch08-Pg03)**
 4. [Section 4: AI Powered Recommendation System](Ch08-Pg04)
 */

/*:
 * Callout(Quote: CRM Analytics):
 "How you gather, manage and use information will determine whether you win or lose."
 \
 –Bill Gates
 */

/*:
 # Section 3: Market Basket Analytics Interpretation and Application
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **market basket analytics**, view the following ...
 * [The Swift Programming Language]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
