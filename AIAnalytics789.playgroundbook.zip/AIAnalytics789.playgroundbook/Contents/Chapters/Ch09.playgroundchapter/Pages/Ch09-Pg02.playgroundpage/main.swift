//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Conjoint Analysis Analytics Generation.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    
    @State private var showingTable91Sheet1 = false
    @State private var showingFigure91Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("9.2.0 Overview")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Considering the analytic task and analytic question, marketing managers need to select the most appropriate analytic tool from the analytic toolbox.  To identify the most desirable combination of attributes or features for a new product or service, marketing managers would select conjoint analysis.\n")
                            .padding(.bottom, 380)
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("9.2 Conjoint Analysis Analytics Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("9.2.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("9.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
            // Start: Topic 1 - Conjoint Analysis
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("9.2.1 Conjoint Analysis")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                            Text("Conjoint analysis can be used by marketing managers to understand how customers develop preferences for products or services.  The basic premise of conjoint analysis is that customers evaluate the value of a product or service by combining the separate value of each attribute.  Customers form a utility that is a subjective judgment of preference unique to each customer based on all product and service features.  To perform a conjoint analysis, marketing managers need to identify all relevant product attributes or characteristics as well as all relevant values for each attribute.  The combination of the selected levels of attributes are presented to respondents and asked to provide only their overall evaluation.  Based on the respondents’ overall ratings, conjoint analysis can evaluate the importance of each attribute and value of each attribute level.\n").padding(10)
                            Text("As conjoint analysis has many unique characteristics as a multivariate analytics tool, the next section presents what marketing managers need to understand about conjoint analysis.  These include the terms used, conjoint model, and various decisions and issues that should be made by marketing managers for successful conjoint analysis design and application.\n").padding(10)
                            Text("Conjoint analysis is a decompositional model as it decomposes the preference to determine the value of each attribute.  In conjoint analysis, respondents provide only the dependent variable of the overall preference based on the independent variables and their levels specified by marketing managers.  The levels of independent variables are then used to decompose the dependent variable of overall preference provided by respondents.  One other characteristic of conjoint analysis is that it can provide a separate model for predicting preference for each respondent.  Conjoint analysis can handle both linear and non-linear relationship between independent variables and dependent variable and does not make any assumption on the relationship among independent variables.\n").padding(10)
                        } // Section 1
                        .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("9.2 Conjoint Analysis Analytics Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("9.2.1 Conjoint Analysis")
                } else {
                    Image(systemName: "pencil")
                    Text("9.2.1 Conjoint Analysis")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // Start: Topic 2 - Input Data
            // ----------------------
            VStack {
                NavigationView {
                    List {
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("9.2.2 Input Data")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                        Text("Marketing managers are required to provide product attributes (independent variables) and levels of each attribute to be used for conjoint analysis design.  Using the levels of attributes, hypothetical products can be constructed by selecting one level of each attribute.  The possible combinations of attributes depend on the number of attributes and the number of levels in each attribute.  For example, 3 attributes with 2 levels of each attribute can produce 8 possible combinations (2 x 2 x 2) that are called stimuli.  Marketing managers can understand a respondent’s preference structure using the specific combinations of attribute levels.\n").padding(10)
                        Text("Input data for conjoint analysis is preference data obtained from respondents using experimental design.  Conjoint analysis takes preference data as input and identifies what respondents consider to be the product’s most important features and most important combination of features.  Respondents are provided with various combinations of product features of interest and asked to indicate which combination they most prefer, and so on.  Experimental design for conjoint analysis uses categorical variables that represent different product attributes or features.  The design includes attributes and values of the attributes often called levels.  Table 9-1  shows the product attributes and levels of new car design.  New car attributes included in this example are price, color, brand, style, and cylinder.\n").padding(10)
                        Text("Conjoint analysis is applied to categorical variables and tries to identify interdependence among the product attributes.  All possible pairs of attributes and for each level can be considered for each attribute are presented to respondents.  While it is ideal to gather all combinations of attribute levels, it is impractical when the number of attributes and levels increase.  For Table 9-1, the number of all possible combinations using all levels of the five attributes is 540 (5 x 3 x 4 x 3 x 3).  As it is impractical to rank order or give ratings of all 540 combinations, respondents are asked to rank order or give ratings of their preferences for a representative number of the 540 combinations.  Experimental design can be used to select the appropriate set of combinations to obtain preference data.\n").padding(10)
                    } // Section 1
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    // ----------------------
                    Section(header: Text("Table 9-1: Input Data Example for Conjoint Analysis")) {
                        Image(uiImage: UIImage(named: "Table-9-1.jpg")!)
//                        Image(name: "Table-9-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 9-1: Input Data Example for Conjoint Analysis") {
                            self.showingTable91Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable91Sheet1) {
                            Table91View1()
                        }
                        Text("The obtained preference data can be used as input data for conjoint analysis.  When preference data is subjected to conjoint analysis, the conjoint analysis software can generate the analysis output.  A conjoint analysis calculates a set of utilities using preference rankings.  Conjoint analysis calculates utilities by applying a complex form of analysis of variance the respondent’s preference rankings.  Utilities reflect the relative value or desirability of a particular attribute of respondent that is derived from preference rankings.  Preference rankings indicate the relative utilities that respondents attach to each feature.  When respondents are reluctant to give up a certain product attribute, then this product attribute is considered of high utility.  As such, utilities are expected to correspond to preference rankings.  Therefore, the sum of utilities of a combination of attributes is consistent to that combination’s position in the respondents’ preference rankings.\n").padding(10)
                        Text("Utilities are most important in conjoint analysis.  Utilities can be used by marketing managers in answering analytic questions.  Utilities can provide information about relative importance of individual attributes.  They identify which attributes are more important and in what degree.  Attributes showing highly fluctuating utilities are considered to be more important than those with similar fluctuating utilities.  The importance of an attribute can be evaluated by the variation of its utilities attached to different levels of that attribute.  This range of variation indicates how sensitive the respondents are to the different levels of the attributes.  The relative importance of attributes is critical for the design of products, developing proper product positioning in the target market, estimating demand, and understanding the possible impact of competitors’ new products.  As each brand in the market competes on the combination of attributes it offers, new products must compete with all existing products in the market based on the utilities of its combination of product attributes.\n").padding(10)
                        Text("Utilities also indicate the importance of each attribute level.  The utilities attached to each level of different attributes can be used trade-off analysis of different product attribute levels considering the cost of providing that attribute level as well as assessing market share of competing brands in the target market.  Utilities can be used by marketing managers to evaluate alternative product designs.  Marketing managers can use utilities to determine the relative utilities of alternative product designs and corresponding estimated market share, sales volume, revenues, and profitability.  Marketing managers can use this information in selecting the best design combination to be used in new product design and development.\n").padding(10)
                    }
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    } // List - text
                        .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
                .navigationBarTitle("9.2 Conjoint Analysis Analytics Generation ", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 2
            // ----------------------
            // End: Topic 2
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("9.2.2 Input Data")
                    } else {
                        Image(systemName: "pencil")
                        Text("9.2.2 Input Data")
                    } // If-Else
            } // tabItem
            .tag("bookSection2")
            // ----------------------
            // Start: Topic 3 - Conjoint Model
            // ----------------------
            VStack {
                NavigationView {
                    List {
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("9.2.3 Conjoint Model")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                        Text("Respondents provide an overall evaluation in the form of rankings or ratings of each stimuli by performing trade-off of different attribute levels and attributes.  Respondents generate overall evaluation by considering the importance of each attribute and the differing levels of each attribute.  The overall evaluation represents the utility of a respondent based on the part-worth for each level.  The conjoint model can be shown as the following:\n").padding(10)
                    } // Section 1
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    // ----------------------
                    Section(header: Text("Equation 9-1 ")) {
                        Image(uiImage: UIImage(named: "Equation-9-1.jpg")!)
//                        Image(name: "Equation-9-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .padding(.bottom, 30)
                        Text("The part-worth of each level can be calculated using the following steps.  First, square the deviations and find their sum across all levels and then calculate a standardizing value that is equal to the total number of levels divided by the sum of squared deviations.  Then, estimate the part-worth by taking the square root of the standardized squared deviation.  Conjoint analysis software tools can calculate the part-worth estimates and provide them as a part of the output.  With the part-worth estimates, marketing managers can assess the preference of a respondent for any combination of attributes, the preference structure, and importance of each attribute.\n").padding(10)
                    }
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    } // List - text
                        .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
                .navigationBarTitle("9.2 Conjoint Analysis Analytics Generation ", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 3
            // ----------------------
            // End: Topic 3
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("9.2.3 Conjoint Model")
                    } else {
                        Image(systemName: "pencil")
                        Text("9.2.3 Conjoint Model")
                    } // If-Else
            } // tabItem
            .tag("bookSection3")
            // ----------------------
            // Start: Topic 4 - Conjoint Analysis Decision
            // ----------------------
            VStack {
                NavigationView {
                    List {
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("9.2.4 Conjoint Analysis Decision")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                        Text("In performing conjoint analysis, marketing managers are asked to make a series of design and analysis related decisions considering the decision task and analytics questions on hand.  The first decision to make is the number of attributes to be used for conjoint analysis design.  Depending on the number of attributes used in the design, different conjoint methods can be used.  For smaller number of attributes such as less than 6, choice-based conjoint analysis can be performed.  For less than 10 attributes, traditional conjoint analysis can be used.  For 10 or more attributes, adaptive choice method can be used.  The second decision area is selecting and identifying attributes and levels leading to the design of stimuli.  The attribute and level selection is directly related to the analytics question.  The attributes and levels must be decided considering their relevance to marketing decisions.  With the selection of the levels of each attribute, marketing managers must specify the basic model form that describes the nature of relationship between the attribute levels and preference.  Typically, three types of relationship are specified.  Figure 9 1 shows the specification of the basic model that include three types of relationships: linear, quadratic, and part-worth. \n").padding(10)
                    } // Section 1
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    // ----------------------
                    Section(header: Text("Figure 9-1: Three Type of Specification of the Basic Model")) {
                        Image(uiImage: UIImage(named: "Figure-9-1.jpg")!)
//                        Image(name: "Figure-9-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    }
                    .listRowBackground(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.2000)))
                    } // List - text
                        .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
                .navigationBarTitle("9.2 Conjoint Analysis Analytics Generation ", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 4
            // ----------------------
            // End: Topic 4
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("9.2.4 Analysis Decision ")
                    } else {
                        Image(systemName: "pencil")
                        Text("9.2.4 Analysis Decision ")
                    } // If-Else
            } // tabItem
            .tag("bookSection4")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: "Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have four topics to complete.",
                        "-- Topic 1: Conjoint Analysis\n\nThis is a reading only assignment",
                        "-- Topic 2: Input Data\n\nThis is a reading only assignment",
                        "-- Topic 3: Conjoint Model\n\nThis is a reading only assignment",
                        "-- Topic 4: Conjoint Analysis Decision\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// TABLE 9-1 VIEW
// ------------------------------
struct Table91View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 9-1: Input Data Example for Conjoint Analysis")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-9-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 9-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 9-1 VIEW
// ------------------------------
struct Figure91View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 9-1: Three Type of Specification of the Basic Model")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-9-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 9-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Conjoint Analysis for New Product Design and Development Analytics
### Table of Contents - _Chapter 9_
1. [Section 1: New Product Design and Development Analytics Task](Ch09-Pg01)
2. **[Section 2: Conjoint Analysis Analytics Generation Process](Ch09-Pg02)**
3. [Section 3: Conjoint Analysis Analytics Interpretation and Application](Ch09-Pg03)
4. [Section 4: AI Driven New Product Design and Development](Ch09-Pg04)
*/

/*:
 * Callout(Quote: New Product Design and Development Analytics):
 "If you are not embarrassed by the first version of your product, you’ve launched too late."
 \
 –Reid Garrett Hoffman
 */

/*:
 # Section 2: Conjoint Analysis Analytics Generation Process

 ## 2.1 Conjoint Analysis

 ## 2.2 Input Data

 ## 2.3 Conjoint Model

 ## 2.4 Conjoint Analysis Decision
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **conjoint analysis analytics generation**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
