//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on New Product Design and Development Analytics Tasks.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C09S01T00(topicTitle: "9.1 New Product Design and Development Analytics Task")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("9.1.0 Overview")
                    }
            } else {
                    VStack{
                    Image(systemName: "pencil")
                    Text("9.1.0 Overview")
                    }
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Market Targeting Analytics Task section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: New Product Design and Development Analytics Task\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.0000, green: 0.9765, blue: 0.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Conjoint Analysis for New Product Design and Development Analytics
 ### Table of Contents - _Chapter 9_
 1. **[Section 1: New Product Design and Development Analytics Task](Ch09-Pg01)**
 2. [Section 2: Conjoint Analysis Analytics Generation Process](Ch09-Pg02)
 3. [Section 3: Conjoint Analysis Analytics Interpretation and Application](Ch09-Pg03)
 4. [Section 4: AI Driven New Product Design and Development](Ch09-Pg04)
 */

/*:
 * Callout(Quote: New Product Design and Development Analytics):
 "Your most unhappy customers are your greatest source of learning."
 \
 –Bill Gates
 */

/*:
 # Section 1: New Product Design and Development Analytics Task
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [How AI-Enabled Product Recommendations Work]: https://emerj.com/ai-sector-overviews/ai-enabled-product-recommendations/

 ### Additional Information:
 For more information regarding **conjoint analysis**, view the following ...
 * [How AI-Enabled Product Recommendations Work]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
