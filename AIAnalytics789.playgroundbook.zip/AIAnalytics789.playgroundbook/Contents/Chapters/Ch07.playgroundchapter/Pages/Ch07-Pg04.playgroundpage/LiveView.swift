//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//
//  Chapter 4: Visualization Tools for Marketing Environment Analytics
//  Section 4:
//
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
// https://www.pexels.com/photo/macbook-pro-beside-papers-669619/
// Photo by Lukas from Pexels
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter4
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Visualization Tools for Marketing Environment Analytics ")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero
    @State private var amount: CGFloat = 0.0
    
    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                Image(uiImage: UIImage(named: "Data-Visualization.jpg")!)
//                Image(name: "Data-Visualization.jpg")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 350, height: 350)
                    .saturation(Double(amount))
                    .blur(radius: (1 - amount) * 20)
                HStack{
                    Text("Amount of Blur --> ")
                    Slider(value: $amount)
                        .padding()
                }
                Spacer()
                C04S03T01Instructions()
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC04S04 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC04S04
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!\n\nYou are taking the 'AI Powered Visualization Analytics' section.")
} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
