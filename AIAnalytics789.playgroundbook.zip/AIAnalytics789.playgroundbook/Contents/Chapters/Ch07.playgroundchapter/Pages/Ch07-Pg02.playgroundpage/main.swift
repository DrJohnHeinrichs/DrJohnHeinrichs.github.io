//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Market Basket Analysis Solution Generation.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    
    @State private var showingTable71Sheet1 = false
    @State private var showingTable72Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("7.2.0 Overview")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                            Text("To answer the analytic questions at the individual and aggregate level, marketing managers must select the appropriate analytic tool from the analytic toolbox.  To predict individual customer choice behavior, logistic regression analysis can be selected.  At the aggregate level, sales forecasting techniques can be selected.  These two analytic tools are discussed next.  \n").padding(10)
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.4000)))
                    .navigationBarTitle("8.2 Market Basket Analysis Solution Generation", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("7.2.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("7.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
            // ----------------------
            // Start: Topic 1 - Logistic Regression Analytics
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Logistical Regression")) {
                            Text("A logistical regression is similar to any linear regressions with one critical difference.  Typical regression analysis evaluates the relationship between the dependent variable and one or more independent variables.  Multiple linear regression analysis predicts the numerical value of the dependent variable with the values of the multiple independent variables.  In multiple regression analysis, a dependent variable is a continuous quantitative variable.  In logistic regression analysis, the critical difference compared to multiple regression analysis is that the predicted dependent variable is a discontinuous categorical (typically binary) variable.  This binary variable is a dummy variable such as customer product purchase or customer retention.  In using the dummy variable, a 1 will represent purchase or customer retention and a 0 will represent no purchase or customer loss.\n").padding(10)
                            Text("Logistical regression is used to predict the probability (i.e., called propensity) that the dependent variable (y) will fall into a category (1 or 0) based in the values of independent variables.  Logistic regression is applied when the dependent variable is categorical.  To classify an observation into a category, the logistic regression method estimates propensities or probabilities of belonging to each category.  The probability that an observation belongs to category 1 is p = P (Y=1).  The probability that an observation belongs to category 0 is (1 – p) = P (Y=0).\n").padding(10)
                            Text("Next, marketing managers need to select the cutoff value to classify an observation.  The cut-off is typically 0.5.  If the p is equal to or greater than 0.5, the observation is classified as class 1.  The cut-off does not need to be 0.5.  With the two probabilities estimated, the odds of belonging to class 1 is defined as the ratio of the probability of belonging to class 1 to the probability of belonging to class 0.  The odds can be calculated using the following formula.\n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-7-1.jpg")!)
//                            Image(name: "Equation-7-1.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            VStack{
                            Text("For example, if the probability of purchasing a brand by a customer is p = 0.3, then 1 – p = 0.7.  The odds of this customer purchasing the brand are 0.43 (0.3 / 0.7).  This means that this customer would purchase the brand three times out of the seven purchases made.  The logit is the natural logarithm of odds.  The range of logit is from -∞ to ∞.  In logistic regression, the logit is used as the dependent variable.  Thus, logistic regression model is:\n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-7-2.jpg")!)
//                            Image(name: "Equation-7-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            Image(uiImage: UIImage(named: "Equation-7-3.jpg")!)
//                            Image(name: "Equation-7-3.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            }
                            VStack{
                            Text("The one unit change in Xi will increase or decrease the calculated odds, as the odds are calculated by the odds formula:\n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-7-4.jpg")!)
//                            Image(name: "Equation-7-4.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            Text("The logistic function is: \n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-7-5.jpg")!)
//                            Image(name: "Equation-7-5.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            }
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.4000)))
                    .navigationBarTitle("7.2 Logistic Regression Analytics Generation, Interpretation, and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("7.2.1 Logistic Regression Analytics")
                } else {
                    Image(systemName: "pencil")
                    Text("7.2.1 Logistic Regression Analytics")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // ----------------------
            // Start: Topic 2 - Logistic Regression Input Data
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Table 7-1: Input Data Example for Logistical Regression Analysis")) {
                            Text("The input data include one categorical or binary dependent variable and multiple independent variables.  Independent variables can be either continuous or categorical variables.  For categorical variables, marketing managers need to recode the categorical variables to one or more dummy variables through dummy coding process.  Table 7 1 shows an example of input data file.  In this data file, the dependent variable is categorical variable purchase (1 = purchase, 0 = no purchase).  Six independent variables are included in the input file.  Income, education, brand attitude, and age are continuous independent variables and current home ownership and gender are categorical independent variables.\n").padding(10)
                            Image(uiImage: UIImage(named: "Table-7-1.jpg")!)
//                            Image(name: "Table-7-1.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Table 7-1: Input Data Example for Logistical Regression Analysis") {
                                self.showingTable71Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable71Sheet1) {
                                Table71View1()
                            }
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.4000)))
                    .navigationBarTitle("7.2 Logistic Regression Analytics Generation, Interpretation, and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 2
            // ----------------------
            // End: Topic 2
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("7.2.2 Input Data")
                } else {
                    Image(systemName: "pencil")
                    Text("7.2.2 Input Data")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // ----------------------
            // ----------------------
            // Start: Topic 3 - Logistic Regression Analytics Interpretation and Application
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        // ----------------------
                        Section(header: Text("Table 7-2: Logistic Regression Output Example ")) {
                            Text("The logistic regression equation is estimated using the input data.  The β parameters are estimated using the maximum likelihood method as the relationships between Y and β parameters is nonlinear.  The typical output of logistic regression analysis using the Table 7-1 data is shown in Table 7-2.  The outcome variable is product purchase coded as Y = 1. \n").padding(10)
                            Text("Using the Table 7-2 logistic regression output, marketing managers can derive the logistic regression model using all six independent variables.  The estimated logistic regression equation is:\n").padding(10)
                            Image(uiImage: UIImage(named: "Equation-7-6.jpg")!)
//                            Image(name: "Equation-7-6.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .padding(.bottom, 30)
                            Image(uiImage: UIImage(named: "Table-7-2.jpg")!)
//                            Image(name: "Table-7-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Table 7-2: Logistic Regression Output Example") {
                                self.showingTable72Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable72Sheet1) {
                                Table72View1()
                            }
                          } // Section 1
                          .listRowBackground(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.2000)))
                          // ----------------------
                          Section (header: HStack {
                              Image(systemName: "pencil")
                              Text("Equations")
                                  .font(.system(size: 20, weight: .heavy, design: .default))
                          } )
                          {
                              Text("The positive coefficients for income (X1), current ownership (X3), and gender (X4), and brand attitude (X5) are associated with higher probabilities of purchasing a product.  The negative coefficients of education (X2) and age (X6) are associated with lower probabilities of purchasing our product.  The logistic regression model suggests that if a customer has higher income, is a current owner of our product, is male, and holds a positive brand attitude, then they will have a higher probability of purchasing our product.  On the contrary, if a customer has more years of education, that customer will have a lower probability of purchase.  Age is not a significant predictor as its p-value is less than 0.05 if we use 0.05 as the level of significance. As the logistic regression model is the multiplicative model of odds, the interpretation of coefficients is different from those of multiple regression analysis.  In logistic regression, the coefficient shows how one unit of change in that independent variable increases or decreases the odds.\n").padding(10)
                              Text("The practical use and decision application of these results depend on the analytic question set by marketing managers.  One common question is what would be the probability of purchasing our product for a prospective customer.  Suppose the prospective customer makes $60,000 (coded as 6), have a college degree (coded as 4), is current owner of our product (coded as 1), is male (coded as 1), have fairly positive attitude toward our brand (coded as 4), and is 45 years old (coded as 45).  Using the logistic regression coefficients in Table 7 2, odds of purchasing a product for this prospective customer can be calculated as:\n").padding(10)
                              Image(uiImage: UIImage(named: "Equation-7-7.jpg")!)
//                              Image(name: "Equation-7-7.jpg")
                                  .resizable()
                                  .scaledToFit()
                                  .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                  .padding(.bottom, 30)
                              Text("The calculated odds for this customer are 5.20.  The calculated odds can be used by marketing managers for targeting decision as well as other promotional campaign decisions.  However, for marketing managers, propensity or probability of purchase would be more intuitively interpretive than odds.  Odds can be converted to probability.  If we convert Odds (Y = 1) = p / (1- p) in terms of p, the probability equation p is:\n").padding(10)
                              Image(uiImage: UIImage(named: "Equation-7-8.jpg")!)
//                              Image(name: "Equation-7-8.jpg")
                                  .resizable()
                                  .scaledToFit()
                                  .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                  .padding(.bottom, 30)
                              Text("Using this probability equation, the probability of purchasing our product for this prospective customer is 0.839 (5.20 / (5.20 + 1)).  This propensity or probability of purchase information can be used for various marketing decisions such as targeting, customer relationship management, and sales call planning.\n").padding(10)
                          } // Section 2
                          .listRowBackground(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.2000)))
                        // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.4000)))
                    .navigationBarTitle("7.2 Logistic Regression Analytics Generation, Interpretation, and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 2
            // ----------------------
            // End: Topic 2
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("7.2.3 Interpretation")
                } else {
                    Image(systemName: "pencil")
                    Text("7.2.3 Interpretation")
                } // if-else
                } // tabItem
            .tag("bookSection3")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have three topics to complete.",
                        "-- Topic 1: Logistic Regression Analytics\n\nThis is a reading only assignment",
                        "-- Topic 2: Logistic Regression Input Data\n\nThis is a reading only assignment",
                        "-- Topic 3: Logistic Regression Analytics Interpretation and Application\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.5216, blue: 1.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// TABLE 7-1 VIEW
// ------------------------------
struct Table71View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 7-1: Input Data Example for Logistical Regression Analysis")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-7-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 7-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 7-2 VIEW
// ------------------------------
struct Table72View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 7-2: Logistic Regression Output Example")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-7-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 7-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Logistic Regression and Forecasting Tools for Customer Behavior Analytics
 ### Table of Contents - _Chapter 7_
 1. [Section 1: Customer Behavior Analytics Task](Ch07-Pg01)
 2. **[Section 2: Logistic Regression Analytics Generation, Interpretation, and Application](Ch07-Pg02)**
 3. [Section 3: Forecasting Analytics Generation, Interpretation, and Application](Ch07-Pg03)
 4. [Section 4: AI Powered Churn Prediction and Sales Forecasting Algorithm](Ch07-Pg04)
 */

/*:
* Callout(Quote: Customer Behavior Analytics):
"You don’t need to learn what customers say they want; you need to learn how customers behave and what they need. In other words, focus on their problem, not their suggested solution."
\
–Cindy Alvarez
*/

/*:
 # Section 2: Logistic Regression Analytics Generation, Interpretation, and Application
 
 ## 2.1 Logistic Regression Analytics
 
 ## 2.2 Logistic Regression Input Data

 ## 2.3 Logistic Regression Analytics Interpretation and Application
 * In this challenge, you'll practice your [Business Analytics](glossary://Business%20Analytics)-finding skills by finding and rearranging.
 */

/*: Setup and use a link reference.
 [Linear to Logistic Regression]: https://www.kdnuggets.com/2020/03/linear-logistic-regression-explained.html
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Predictive Power Score]: https://towardsdatascience.com/rip-correlation-introducing-the-predictive-power-score-3d90808b9598
 
### Additional Information:
 For more information regarding **logistic regression analytics**, view the following ...
 * [Linear to Logistic Regression]
 * [Predictive Power Score]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
