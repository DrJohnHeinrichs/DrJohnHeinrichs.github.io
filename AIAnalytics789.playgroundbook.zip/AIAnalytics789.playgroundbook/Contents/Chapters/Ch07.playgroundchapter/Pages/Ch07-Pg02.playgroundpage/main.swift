//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on Visualization Analytics Generation.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C04S02T00(topicTitle: "4.2 Visualization Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("4.2.0")
            } else {
                    Image(systemName: "pencil")
                    Text("4.2.0")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Comparison Visualization Chart Type 
            // -------------------------
            C04S02T01(topicTitle: "4.2 Visualization Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("4.2.1")
                } else {
                    Image(systemName: "pencil")
                    Text("4.2.1")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Relationship Visualization Chart Type
            // -------------------------
            C04S02T02(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.2")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.2")
                    }
                    } // tabItem
                .tag("bookSection3")
            // -------------------------
            // TOPIC 3: Tabulation Visualization Chart Type
            // -------------------------
            C04S02T03(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.3")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.3")
                    }
                    } // tabItem
                .tag("bookSection4")
            // -------------------------
            // TOPIC 4: Trend Visualization Chart Type
            // -------------------------
            C04S02T04(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.4")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.4")
                    }
                    } // tabItem
                .tag("bookSection5")
            // -------------------------
            // TOPIC 5: Graphic Display Visualization Chart Type
            // -------------------------
            C04S02T05(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.5")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.5")
                    }
                    } // tabItem
                .tag("bookSection6")
            // -------------------------
            // TOPIC 6: Dashboard Report Visualization Tool
            // -------------------------
            C04S02T06(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.6")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.6")
                    }
                    } // tabItem
                .tag("bookSection7")
            // -------------------------
            // TOPIC 7: Visualization Analytics Input Data
            // -------------------------
            C04S02T07(topicTitle: "4.2 Visualization Analytics Generation")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.2.7")
                } else {
                        Image(systemName: "pencil")
                        Text("4.2.7")
                    }
                    } // tabItem
                .tag("bookSection8")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the 'Visualization Analytics Generation' section.")
                } )
                {
                    Text("I understand these topics")
                } // button - understand
                    .foregroundColor(.green)
                    .padding(10)
                    .background(Color.white)
                    .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have 7 topics to complete.",
                        "-- Topic 1: Comparison Visualization Chart Type\n\nThis is a reading assignment.",
                        "-- Topic 2: Relationship Visualization Chart Type\n\nThis is a reading assignment. ",
                        "-- Topic 3: Tabulation Visualization Chart Type\n\nThis is a reading assignment. ",
                        "-- Topic 4: Trend Visualization Chart Type\n\nThis is a reading assignment. ",
                        "-- Topic 5: Graphic Display Visualization Chart Type\n\nThis is a reading assignment. ",
                        "-- Topic 6: Dashboard Report Visualization Tool\n\nThis is a reading assignment. ",
                        "-- Topic 7: Visualization Analytics Input Data\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
# Visualization Tools for Marketing Environment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. **[Section 2: Visualization Analytics Generation](Ch04-Pg02)**
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart - Interactive](BarChart2)
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. [Scatter Chart](ScatterChart)
 */

/*:
 * Callout(Quote: Visualization):
 "You are more productive by doing fifteen minutes of visualization than from sixteen hours of hard labor."
 \
 –Abraham Hicks
 */

/*:
 ## Section 2: Visualization Analytics Generation
 ### 2.1 Comparison Visualization Chart Type
 * (Bar Chart; Histogram; Heatmap; Bullet Chart; Tree Map; Pie Chart;
 ### 2.2 Relationship Visualization Chart Type
 * Scatter Chart; Network Chart;
 ### 2.3 Tabulation Visualization Chart Type
 * PivotTables; PivotChart;
 ### 2.4 Trend Visualization Chart Type
 * Line Chart; Area Chart;
 ### 2.5 Graphic Display Visualization Chart Type
 * Geospatial Map; Spiral Chart;
 ### 2.6 Dashboard Report Visualization Tool
 ### 2.7 Visualization Analytics Input Data
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Data Visualization: Examples]: https://towardsdatascience.com/data-visualization/home
 
 ### Additional Information:
 For more information regarding **visualization analytics generation**, view the following ...
 * [Data Visualization: Examples]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
