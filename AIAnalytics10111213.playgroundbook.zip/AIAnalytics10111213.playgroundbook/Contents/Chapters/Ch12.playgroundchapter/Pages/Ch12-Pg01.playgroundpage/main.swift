//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on Websites Clickstream Analytics.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C12S01T00(topicTitle: "12.1 Websites Clickstream Analytics")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("12.1.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("12.1.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Market Trend Analytics
            // -------------------------
            C12S01T01(topicTitle: "12.1 Websites Clickstream Analytics")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("12.1.1 Clickstream Tasks")
                } else {
                    Image(systemName: "pencil")
                    Text("12.1.1 Clickstream Tasks")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Website Clickstream Analytics Generation
            // -------------------------
            C12S01T02(topicTitle: "12.1 Websites Clickstream Analytics")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("12.1.2 Clickstream Generation")
                } else {
                    Image(systemName: "pencil")
                    Text("12.1.2 Clickstream Generation")
                } // if-else
                } // tabItem
            .tag("bookSection3")
            // -------------------------
            // TOPIC 3: Website Clickstream Analytics Interpretation and Application
            // -------------------------
            C12S01T03(topicTitle: "12.1 Websites Clickstream Analytics")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("12.1.3 Interpretation and Application")
                } else {
                    Image(systemName: "pencil")
                    Text("12.1.3 Interpretation and Application")
                } // if-else
                } // tabItem
            .tag("bookSection4")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Website Clickstream Management Task section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Website Clickstream Management Task\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
## Digital Marketing Site Analytics
### Table of Contents - _Chapter 12_
 1. **[Section 1: Websites Clickstream Analytics](Ch12-Pg01)**
 2. [Section 2: Social Media Network Analytics](Ch12-Pg02)
 3. [Section 3: AI Powered Digital Site Analytics](Ch12-Pg03)
 */

/*:
* Callout(Quote: Digital Marketing Site Analytics):
"Content is fire; social media is gasoline."
\
–Jay Baer
*/

/*:
 # Section 1: Websites Clickstream Analytics
 
 ## 1.1 Website Clickstream Management Task
 
 ## 1.2 Website Clickstream Analytics Generation
 
 ## 1.3 Website Clickstream Interpretation and Application

 ### Mobile Web Analytics
 */

/*:
 * Finding the right customers involves developing both a [Profile](glossary://Profile) and [Segmenting](glossary://Segmenting) the market.
 * A social profile can be developed by profiling the community to which that individual belongs.  
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 ### Additional Information:
 For more information regarding **clickstream analytics**, view the following ...
 * [The Swift Programming Language] 
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
