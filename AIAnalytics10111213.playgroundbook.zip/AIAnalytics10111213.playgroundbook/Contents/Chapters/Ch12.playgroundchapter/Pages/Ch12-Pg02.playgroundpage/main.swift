//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Social Media Network Analytics.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    
    @State private var showingTable124Sheet1 = false
    @State private var showingTable125Sheet1 = false
    @State private var showingTable126Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
//            // ----------------------
//            // Start: Topic 0 - Overview
//            // ----------------------
//            VStack {
//                NavigationView {
//                    List {
//                        Section (header: HStack {
//                            Image(systemName: "pencil")
//                            Text("12.2.0 Overview")
//                                .font(.system(size: 20, weight: .heavy, design: .default))
//                        } )
//                        {
//                        Text("\n")
//                            .padding(.bottom, 380)
//                        } // Section
//                        .listRowBackground(Color(UIColor(red: 0.4784, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
//                    } // List -- text
//                    .padding(30)
//                    .font(.system(size: 22))
//                    .frame(maxWidth: .infinity, maxHeight: .infinity)
//                    .background(Color(UIColor(red: 0.4784, green: 0.9922, blue: 1.0000, alpha: 0.4000)))
//                    .navigationBarTitle("12.3 ...", displayMode: .inline)
//                } // NavigationView
//                .navigationViewStyle(StackNavigationViewStyle())
//            } // VStack - 0
//            // ----------------------
//            // End: Topic 0
//            // ----------------------
//            .tabItem {
//                if understandSection {
//                    Image(systemName: "star.fill")
//                    Text("12.2.0 Overview")
//                } else {
//                    Image(systemName: "pencil")
//                    Text("12.2.0 Overview")
//                } // if-else
//                } // tabItem
//            .tag("bookSection0")
            // ----------------------
            // Start: Topic 1 - Social Media Network Management Task
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("12.2.1 Social Media Network Management Task")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("In the new social network-enabled co-production communication form, the marketing messages and the perceived meaning associated with those messages are being exchanged among the participants in various virtual communities.  The group influence and subgroup behavior factors are important for understanding group interaction behavior within social networks and social media sites.\n\nFor social media sites, it is important for marketing managers to know how effective their firm’s social media sites are and what type of social groups are engaged in their digital sites generating the targeted and favorable posts and evaluative responses as well as uncontrolled favorable and unfavorable posts and responses.  Marketing managers also need to understand how well the firm’s social media network groups are organized and engaged with the firm’s digital sites relative to competitors.  The task is to understand the structure and nature of social media network groups and interactive patterns of participants in the social media platforms.  For social media sites, it is important to know who are network leaders and followers in their social media sites.  Managers can make the right management decisions by understanding the network structure of their social media participants and visitors as well as their engagement patterns.  Marketing managers have the analytic task of understanding and visualizing configurations of social ties within social groups formed within the firm’s digital sites.\n\n")
                        Text("In addition to knowing individual user behavior, firms need to understand the nature and structure of group interaction and collaboration within the social media networks.  Social network analysis can be performed to identify the characteristics of network leaders, the number of sub-networks, the relationship and interaction patterns between individual users, between individual user and sub-networks, and among various sub-networks.  According to social network analysis (SNA), the social tie strength (social relations) determines whether users will assimilate or differentiate their opinions.  In addition, if strong ties (connections) or a large number of ties exist, those ties impose greater demand for conformity on the users and those users are expected to heed the advice of their stronger ties.  The affective content of these relationships further strengthens the role of their influencer or network leader as affective commitment manifests itself as belongingness or attachment to the community or group.\n\nThe social media behavior can evolve over time.  Three levels of social media behavior can be identified.  The first level is the primitive level, which is characterized by the lack of network or opinion leaders and organized sub-networks.  In this first level, users visit or interact with a firm’s social media sites on a random and occasional basis.  In many cases, firms are simply setting up their social media sites and do not yet have clear direction or the intention of managing these sites.  The second level of social media behavior involves the transition from the primitive level.  This intermediate level exhibits the emergence of opinion leaders and the formation of sub-networks.  In this level, either self-designated or firm-influenced opinion leaders will emerge and act as opinion leaders in certain topics or on certain issues.  These leaders are not yet well established or clearly recognized as network leaders by the members or participants of the social network.  In the final advanced stage of social media behavior, multiple network leaders are recognized by members or participants of the network.  These leaders have established themselves as the leader through their expertise, popularity, or active participation.  In addition, well-organized sub-networks are typically formed within the social media network.  These sub-networks are led by one or more network leaders and create unique interaction patterns among themselves.\n\n")
                        Text("One of the key components of active, prosperous, and successful virtual communities within these social sites is the presence of active network leaders.  These network leaders should have access to large social networks and be in the role of a key influencer.  The role of network leaders as advice provider, influencer, hub, and information search facilitator is not the same role as traditionally exhibited in marketing communications.  These online virtual community leaders are providing global influence to potentially unlimited numbers of users who are seeking advice, information, and opinions regarding a firm’s products, brands, and services.\n\nThe role of network leader has become a co-influencing interactive role.  Network leaders are participating in conversations, generating content, and occupying important positions in the virtual communities of many online social media sites.  The influence of a user’s social ties and how they affect the commitment of the user toward the use of the social media sites is important for understanding, explaining, and predicting social media site usage and acceptance behavior.  In addition, the influence associated with social ties plays an important role in determining the acceptance and usage behavior of other participants in virtual communities.\n\n")
                        Text("Expanding the leader’s influence requires access to the firm’s website, social media sites, and the virtual community.  Access to the social media site or virtual community is affected by the connectedness or structure of the social network as well as the position that the social media site or virtual community has within the social network.  This makes it possible for the network leaders to still conform to the various expectations or norms of the various virtual communities they are associated with while sharing ideas.  Also, participants in those virtual communities that have strong social ties tend to share group norms and beliefs so strongly that little effort is required by the network leader to share ideas and determine the intentions of participants in the group, since all of the participants in the virtual community are alike.\n\nNetwork leaders are also information providers to users, online virtual communities, and various social groups.  Network leadership is important as network leaders span the social boundaries among various virtual communities and social media site groups.  Their influence comes from across the social context rather than solely from within a specific social group or virtual community.  Thus, network leaders act as bridges or conduits between social groups gaining access to and providing valuable information from one social group and informing others in another social group.  Because of their unique situation, the network leaders are often among the earliest adopters of brands, products, and services.\n\n")
                        Text("In an online, interactive environment, users can influence and be influenced by other participants in their social network.  Network leaders are those users who can influence the attitudes, behaviors, beliefs, motivations, and opinions of other users in the online virtual community.  Thus, network leaders emerge as trusted users with access to a large social network and possess the ability to diffuse innovations and information.\n\nThe network leader, in the role of a social hub, can exercise influence to affect the virtual community’s information and innovation adoption.  Based upon the group influences, the users in the virtual community are willing to be influenced by network leaders as the network leaders are in a desirable social position and are viewed by the virtual community members as competent, unbiased sources of accurate and trustworthy information.\n\nThe identification of a network leader is focused on how often a user posts comments, information, pictures, videos, and opinions to a virtual community and thereby provides sought after information to other users.  Therefore, network leaders are considered as influential members by other users and used as a primary source for information and advice.  Members seeking advice usually follow the advice.  By providing this advice, network leaders play a crucial role in forming the opinions of others in the group.  They bring in new information and ideas and then disseminate that information via blogs, podcasts, videos, and wikis in their role as influential members of virtual communities.  Network leaders are viewed as active co-producers of value and meaning.\n\nThus, information access has become a function of searching; whereas access to knowledge has become a function of the social network or virtual community.  Given the growing importance of this uncontrolled, indirect communication involving social media sites, it is critical for the firm to understand the various roles played by network leaders.  Leaders are viewed as advice providers, influencers, and hubs in focusing the flow of comments, ideas, information, and opinions throughout the virtual community.  Therefore, firms need to perform a detailed social network analysis to understand e-WOM behavior as well as the nature and structure of sub-networks and communities within their online and social media sites.\n\nMarketing managers can have many analytic questions that can provide answers to achieve the firm’s digital goals and objectives.  The analytic questions include which unique composition of social media platforms is required for the firm to deliver the right message to the right audience at the right time, how to build and maintain online community of brand advocates, and what are the drivers for a user to participate and interact with the community.  Marketing managers can generate and apply social media analytics to get answers to these analytic questions.  The next section discuss how marketing managers can generate social media analytics related to social network.")
                        } // Section 1
                        .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.4000)))
                    .navigationBarTitle("12.2 Social Media Network Analytics", displayMode: .inline)
                // ----------------------
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("12.2.1 Social Media Task ")
                } else {
                    Image(systemName: "pencil")
                    Text("12.2.1 Social Media Task")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // Start: Topic 2 - Social Media Network Analytics Generation
            // ----------------------
            VStack {
                NavigationView {
                    List {
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("12.2.2 Social Media Network Analytics Generation")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("To answer the analytic questions generated for the analytic task, marketing managers can choose social network analysis from the analytics toolbox and generate social network analytics.  To generate social network analytics, marketing managers need to generate input data.  In addition, marketing managers should be familiarized with terms used to describe social networks, types of social networks, and different algorithms used to visualize the networks.  The next section provides the basic information regarding the network analysis terms, types, and algorithms.\n\nThe two basic terms used in social network analysis are nodes and ties.   A node represents a discrete participant of the social media sites.  A tie is a link between nodes.  A tie shows an interaction between participants of social media sites.  A tie is also called an edge representing a relationship.  There exist two types of ties representing the nature of relationship such as role-based relationship or interaction such as communications or transactions.  Ties can also be reciprocated or unreciprocated.  Reciprocated ties occur when two participants indicate the other as their best friend or send messages to the other.  Unreciprocated ties occur when one participant send messages to the other but the other did not return the message.  The strength of the tie can be strong or weak depending on the nature of the relationship.\n\nThe number of participants or nodes involved at one time determines the type of node structure.  A dyad refers to the relationship between two nodes.  Triad refers to the relationship among three nodes.  When one network node is routed through for most ties, this node is considered as central to a network.  The participant represented by this node can be considered as a network leader in a social network.  Outlying nodes in a network are referred to be peripheral to the network.\n\n")
                    Text("A component in a network represents a node or collection of nodes isolated from the rest of a network.  A component can be a single node, a dyad, or a triad, or a complex network structure.  Typically, a component is connected through a node or nodes to the rest of the network.  The connecting node represents a participant who is important in diffusing information throughout the network.\n\nThe metrics used to describe the social networks represent the nature of connections and the degree of distributions of relational ties in a social network.  The nature of connections is characterized by homophily, multiplexity, propinquity, reciprocity, and transivity.  These factors promote tie formation in social network.  Homophily is the extent to which participants form ties based on similarity with others.  Similarity can be defined by demographic or other forms of similarity such as gender, race, age, status, or other salient characteristics.  Multiplexity refers to the number of shared characteristics in a tie.  For example, two participants are friends and also have the same occupation.  This multiplexity can influences strength of a relationship.  Propinquity refers to physical proximity.  Participants tend to connect closely to proximate others.  Reciprocity refers to the extent to which two participants mutually share the interaction or ties in the social network.  Transivity is the tendency of participants forming a fully connected network called network closure.\n\nThere are two primary types of social networks which are the directed and undirected networks.  In a directed network, a tie is not reciprocated in the network.  On the other hand, in an undirected network, all ties are reciprocated and mutual.  In graphs of undirected networks, reciprocated times will appear as a two-way arrow, while unreciprocated ties will appear as a one-way arrow.  Graphs depict tie strength in the weight of edges.\n\n")
                    } // Section 1
                        .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                        // ----------------------
                        Section(header: Text("Table 12-4: Adjacency Matrix Example")) {
                            Image(uiImage: UIImage(named: "Table-12-4.jpg")!)
//                            Image(name: "Table-12-4.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        
                        Text("In analyzing and visualizing social networks, marketing managers need to create and capture the social network data.  While different analytical tools require different input data format, two most common input data formats are adjacency matrix and edge lists.  Adjacency matrix is dataset up as n x n matrix, where n is the number of nodes in the dataset.  This square matrix is a symmetric matrix of participants.  Table 2-4 shows an example of adjacency matrix of social media site users of a firm.\n\nEdge lists are lists of connected node pairs.  The list contains a direct connection between two nodes (participants) in a firm’s social media site users.  The edge list for an undirected network will have a row for each 1 in the lower or upper half of the adjacency matrix.  The edge list for a directed network will have a row for each 1 for both of the lower and upper half of the adjacency matrix.  That means the edge list will have as many rows as there are 1s in the adjacency metric.  Table 12-5 shows the edge list that contains the same information of the adjacency matrix shown in Table 12-4.\n\n")
                        .padding(10)
                        Button("Click for ... Table 12-4: Adjacency Matrix Example") {
                            self.showingTable124Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable124Sheet1) {
                            Table124View1()
                        }
                        }
                    .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    Section(header: Text("Table 12-5: Edge Lists Example ")) {
                        Image(uiImage: UIImage(named: "Table-12-5.jpg")!)
//                        Image(name: "Table-12-5.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Text("The input data can be used to visualize the network.  Visualization tools provide a number of layout algorithms to show the network in the form of a graph.  These algorithms include random, force-directed layout, and tree layout algorithms.  Different algorithms highlight different aspects of the network to enhance our understanding of the nature of the network.\n\nIn understanding the network, marketing managers can use the various graph metrics showing the properties of a given network.  Graph metrics include connected components, geodesic distance, density, modularity, centralization, structural holes, bridge, strength, and clustering.  Connected component represents a single node or multiple nodes connected among themselves that are disconnected or not reachable from the rest of the network.  They represent the distinct networks which are not connected to each other in any way.  A whole network can contain n number of distinct connected components.\n\nGeodesic distance refers to the shortest path between two nodes.  The maximum geodesic distance of a network is the largest of the shortest paths within a network.  Geodesic distance value shows communication efficiency and cohesion.  Smaller geodetic distance value indicates that the information moves through the network faster and the network is highly cohesive and not easily fragmented.\n\n")
                        .padding(10)
                        Button("Click for ... Table 12-5: Edge Lists Example") {
                            self.showingTable125Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable125Sheet1) {
                            Table125View1()
                        }
                        Text("The density of a network is the proportion of all possible ties that exist or are realized.  Density refers to the proportion of direct ties in a network relative to the total number of possible ties.  The density value rages from 0 to 1.  Density value of 1 indicates that the network is fully connected.  The network modularity shows the extent to which the network contains modules with dense connections.  Distance shows the minimum number of ties required to connect two distinct participants in a network.  The network centralization indicates the extent to which information or other resource flows move through one particular node.  Centrality centers on the behavior of individual participants in a network.  Centrality shows the importance or influence of a particular node within a network by measuring the extent to which a participant interacts with other participants in the network.  The typical metrics used to represent centrality include betweenness centrality, closeness centrality, degree centrality, and eigenvector centrality.  Betweenness centrality represents the number of indirect ties a node mediates showing the frequency with which a node acts as a bridge within its network.  Higher value indicates the importance of a node (participant) in the network.  Closeness centrality refers to a node’s geodesic distance from other nodes in the network.  Closeness centrality can be calculated by the inverse of the sum of a node’s geodesic distances from all other nodes in the network.  Degree centrality captures the count of a node’s direct connections showing which node is the most active in activity.  When degree centrality is adjusted by a node’s prominence based of the relative prominence of the nodes to which it is tied, it is called eigenvector centrality.\n\nStructural holes represent the absence of ties between two parts of a network.  Bridge refers to a participant whose weak ties can fill a structural hole.  The bridge participant can provide the only link between two nodes or two parts of a network.  Tie strength is defined by the linear combination of multiple factors such as intimacy and reciprocity of ties.  The clustering coefficient of a social network refers to the proportion of cluster members who are tied to each other.  The clustering coefficient for a network is the average clustering coefficients for its nodes.\n\nMarketing managers can use various analytic tools to generate a graph of network using the input data created by the firm’s social media sites.  The next section presents examples of social network analysis results.\n\n")
                    }
                    .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    } // List - text
                .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.4000)))
                .navigationBarTitle("12.2 Social Media Network Analytics", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 2
            // ----------------------
            // End: Topic 2
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("12.2.2 Social Media Network Analytics Generation ")
                    } else {
                        Image(systemName: "pencil")
                        Text("12.2.2 Social Media Network Analytics Generation ")
                    } // If-Else
            } // tabItem
            .tag("bookSection2")
//            // ----------------------
//            // Start: Topic 3 - Social Media Network Analytics Interpretation and Application
//            // ----------------------
            VStack {
                NavigationView {
                    List {
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("12.2.3 Social Media Network Analytics Interpretation and Application")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("Marketing managers can use any network analysis tools available in their firms.  Regardless of the software tools used, the network analysis can generate a graph and related graph metrics for the given graph.  Table 12-6 shows an example of a typical table of graph metrics generated by a network analysis software.\n")
                    } // Section 1
                    .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    Section(header: Text("Table 12-6: Graph Metrics from Network Analysis")) {
                        Image(uiImage: UIImage(named: "Table-12-6.jpg")!)
//                        Image(name: "Table-12-6.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale3, body: { (value, scale3, trans) in
                                scale3 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    }
                        Button("Click for ... Table 12-6: Graph Metrics from Network Analysis") {
                            self.showingTable126Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable126Sheet1) {
                            Table126View1()
                        }
                        .padding(10)
                    .listRowBackground(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    } // List - text
                .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.4000)))
                .navigationBarTitle("12.2 Social Media Network Analytics", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 2
            // ----------------------
            // End: Topic 3
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("12.2.3 Interpretation and Application")
                    } else {
                        Image(systemName: "pencil")
                        Text("12.2.3 Interpretation and Application")
                    } // If-Else
            } // tabItem
            .tag("bookSection3")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have three topics to complete.",
                        "-- Topic 1: Social Media Network Management Task \n\nThis is a reading only assignment",
                        "-- Topic 2: Social Media Network Analytics Generation\n\nThis is a reading only assignment",
                        "-- Topic 3: Social Media Network Analytics Interpretation and Application\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.4784, green: 0.5059, blue: 1.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// TABLE 12-4 VIEW
// ------------------------------
struct Table124View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-4: Adjacency Matrix Example ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-12-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 12-5 VIEW
// ------------------------------
struct Table125View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-5: Edge Lists Example ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-12-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 12-6 VIEW
// ------------------------------
struct Table126View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-6: Graph Metrics from Network Analysis")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-12-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Digital Marketing Site Analytics
### Table of Contents - _Chapter 12_
 1. [Section 1: Websites Clickstream Analytics](Ch12-Pg01)
 2. **[Section 2: Social Media Network Analytics](Ch12-Pg02)**
 3. [Section 3: AI Powered Digital Site Analytics](Ch12-Pg03)
 */

/*:
* Callout(Quote: Digital Marketing Site Analytics):
"Google only loves you when everyone else loves you first."
\
–Wendy Piersall
*/

/*:
 # Section 2: Social Media Network Analytics
 
 ## 2.1 Social Media Network Management Task
 
 ## 2.2 Social Media Network Analytics Generation
 
 ## 2.3 Social Media Network Interpretation and Application
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [AI for Social Media]: https://www.marketingaiinstitute.com/blog/ai-for-social-media
 
 ### Additional Information:
 For more information regarding **social media network analytics**, view the following ...
 * [AI for Social Media]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
