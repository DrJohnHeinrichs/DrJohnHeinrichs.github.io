/*:
 ## Text Mining Tools for Post-Purchase Behavior Analytics
 ### Table of Contents - _Chapter 11_
 1. [Section 1: Post-Purchase Behavior Analytics Task](Ch11-Pg01)
 2. [Section 2: Text Mining Analytics Generation Process](Ch11-Pg02)
 3. [Section 3: Text Mining Analytics Interpretation and Application](Ch11-Pg03)
 4. [Section 4: AI Powered Text Mining - Cases](Ch11-Pg04)
 */

/*:
  * Callout(Examples): Enhance your knowledge of text mining tools
 by completing these interactive exercises.
 1. **[Sentiment Analysis (Static Text)](SentimentAnalysis)**
 2. [Sentiment Analysis (Interactive)](SentimentAnalysisImage)
 */

/*:
# Interactive Playground
In this challenge, you'll practice your [Sentiment Analysis](glossary://Sentiment%20Analysis) - insight generation skills entering text then examining the comments (either positive or negative).
 * FIRST - "toggle" off **Enable Results** by selecting the icon that looks like a gauge
 * Click the **Run My Code** button
 * Enter text and note the change in sentiment
*/
//#-hidden-code
//
//  ContentView.swift
//  SwiftUI -- Sentiment Analysis
import SwiftUI
import PlaygroundSupport
import NaturalLanguage

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

@available(iOSApplicationExtension 13.0, *)
struct ContentView: View {
    
    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 30)!]
    } // init

    var sentimentAnswer: Double {

//
//#-end-hidden-code
//: Enter text that should be evaluated

let input = /*#-editable-code*/Hacking with Swift is awesome!  I have expanded my knowledge and skills.  I would recommend this course to everyone./*#-end-editable-code*/

//#-hidden-code
//

         // feed it into the NaturalLanguage framework
         let tagger = NLTagger(tagSchemes: [.sentimentScore])
         tagger.string = input
         // ask for the results
         let (sentiment, _) = tagger.tag(at: input.startIndex, unit: .paragraph, scheme: .sentimentScore)
         // read the sentiment back and print it
         let score = Double(sentiment?.rawValue ?? "0") ?? 0
         return score
    }
    
        var body: some View {
            NavigationView {
                VStack {
                    Spacer()
                    Text("LJL Industries")
                        .foregroundColor(.blue)
                        .font(.largeTitle)
                        .padding(.bottom, 30)
                    
                    if sentimentAnswer >= 0.001 {
                    Text("Positive Sentiment \(sentimentAnswer)")
                        .foregroundColor(.green)
                        .font(.headline)
                    } else {
                        Text("Negative Sentiment \(sentimentAnswer)")
                            .foregroundColor(.red)
                            .font(.headline)
                    }
                    Spacer()
                } // VStack
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0000))).edgesIgnoringSafeArea(.all)
                .navigationBarTitle("Text Mining Tools", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
        } // body
    } // struct - ContentView
    
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

PlaygroundPage.current.assessmentStatus = .pass(message: "Congratulations!\n\nYou are practicing 'Sentiment Analysis' by entering text then determining the rating.")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*: Setup and use a link reference.
 [Sentiment Analysis - monkeylearn.com]: https://monkeylearn.com/sentiment-analysis-examples/
 [Using Core ML and Natural Language for Sentiment Analysis]: https://heartbeat.fritz.ai/using-core-ml-and-natural-language-for-sentiment-analysis-on-ios-d9469ce6c0ef
 [Sentiment analysis : Machine-Learning approach]: https://medium.com/datadriveninvestor/sentiment-analysis-machine-learning-approach-83e4ba38b57
 
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 [Sentiment Analysis — A how-to guide]: https://towardsdatascience.com/sentiment-analysis-a-how-to-guide-with-movie-reviews-9ae335e6bcb2
 [Create a Text Classifier]: https://medium.com/better-programming/text-classifier-using-coreml-2-nlp-and-createml-6d5c9f456b35
 
 ### Additional Information:
For information regarding **sentiment analysis**, view the following ...
 * [Sentiment Analysis - monkeylearn.com]
 * [Sentiment analysis : Machine-Learning approach]
 * [Using Core ML and Natural Language for Sentiment Analysis]
 * [Create a Text Classifier]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
