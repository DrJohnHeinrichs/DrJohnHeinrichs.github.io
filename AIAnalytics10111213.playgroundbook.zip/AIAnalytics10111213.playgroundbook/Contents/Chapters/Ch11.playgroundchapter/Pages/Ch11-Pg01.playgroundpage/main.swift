//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on .")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.0000, green: 0.5882, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C05S01T00(topicTitle: "5.1 Market Segment Analytics Task")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.1.0 Overview")
            } else {
                Image(systemName: "pencil")
                Text("5.1.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Market Trend Analytics
            // -------------------------
            C05S01T01(topicTitle: "5.1 Market Segment Analytics Task")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("5.1.1 Customer Segment Analytics ")
                } else {
                    Image(systemName: "pencil")
                    Text("5.1.1 Customer Segment Analytics")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Market Segment Analytics Task section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Competitor Analytics\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.0000, green: 0.5882, blue: 1.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
## Clustering Tools for Market Segment Analytics
### Table of Contents - _Chapter 5_
 1. **[Section 1: Market Segment Analytics Task](Ch05-Pg01)**
 2. [Section 2: Clustering Analytics Generation](Ch05-Pg02)
 3. [Section 3: Clustering Analytics Interpretation and Application](Ch05-Pg03)
 4. [Section 4: AI Powered Clustering Analytics](Ch05-Pg04)
 */

/*:
 * Callout(Quote: Segment Analytics):
 "Hiding within those mounds of data is knowledge that could change the life of a patient, or change the world."
 \
 –Atul Butte
 */

/*:
 # Section 1: Market Segment Analytics Task
 
 # 1.1 Customer Segment Analytics
 * Finding the right customers involves developing both a [Profile](glossary://Profile) and [Segmenting](glossary://Segmenting) the market.
 * A personal profile can be developed based on personal information provided by each individual customer through traditional and web-based survey responses, product registration, and/or web click-stream activities.
 * A social profile can be developed by profiling the community to which that individual belongs.  
 */

/*: Setup and use a link reference.
 [Statistics]: https://github.com/evgenyneu/SigmaSwiftStatistics
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **marketing segment tasks**, view the following ...
 * [Statistics]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
