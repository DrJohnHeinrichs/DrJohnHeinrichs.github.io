//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "Firms can develop a competitive advantage by understanding customer needs.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}

@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0000)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
//            C11S01T00(topicTitle: "1.1 Post-Purchase Behavior Analytics Task")
//            .tabItem {
//                if understandSection {
//                    VStack{
//                        Image(systemName: "star.fill")
//                        Text("11.1.0 Overview")
//                    }
//                } else {
//                    Image(systemName: "pencil")
//                    Text("11.1.0 Overview")
//                }
//            } // tabItem
//            .tag("bookSection1")
            // -------------------------
            Ch11S01T01(topicTitle: "11.1 Post-Purchase Behavior Analytics Task")
//                .onTapGesture {
//                    self.selectedTab = "bookSection2"
//                } // onTapGesture
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("11.1.0 Overview")
            } else {
                    Image(systemName: "pencil")
                    Text("11.1.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            Ch11S01T02(topicTitle: "1.1 Post-Purchase Behavior Analytics Task")
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("11.1.nps Net Promoter Score")
            } else {
                    Image(systemName: "pencil")
                    Text("11.1.nps Net Promoter Score")
                } // if-else
                } // tabItem
            .tag("bookSection3")
            // -------------------------
        } // TabView
            // -------------------------
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the Customer Satisfaction topic.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Overview: Customer Satisfaction\n\nThis is a reading assignment.",
                        "-- Topic 2: Net Promoter Score\n\nThese are practical exercises to complete. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](Gestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 0.4000)))
    } // body
} // struct

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Text Mining Tools for Post-Purchase Behavior Analytics
 ### Table of Contents - _Chapter 11_
 1. **[Section 1: Post-Purchase Behavior Analytics Task](Ch11-Pg01)**
 2. [Section 2: Text Mining Analytics Generation Process](Ch11-Pg02)
 3. [Section 3: Text Mining Analytics Interpretation and Application](Ch11-Pg03)
 4. [Section 4: AI Powered Text Mining - Cases](Ch11-Pg04)
 */

/*:
  * Callout(Examples): Enhance your knowledge of text mining tools
 by completing these interactive exercises.
 1. [Sentiment Analysis (Static Text)](SentimentAnalysis)
 2. [Sentiment Analysis (Interactive)](SentimentAnalysisImage)
 */

/*:
 * Callout(Quote: Post-Purchase Behavior Analytics):
 "Without data you're just another person with an opinion."
 \
 –W. Edwards Deming
 */

/*:
 # Section 1: Post-Purchase Behavior Analytics Task

 ## [Customer Satisfaction](glossary://Customer%20Satisfaction): Key Points
 * Firms can develop a competitive advantage by understanding customer needs and providing value-added products and service to meet the identified needs.
 * Customer satisfaction has evolved from being simply an attitude to a multifaceted concept of expectation and perception.
 * Customer satisfaction is a function of how well the firm delivers on its promises given the expectations that the customer has.
 * With the emergence of social media and blog sites, customers are expressing their feelings through these digital information sites.
 * **Customer delight** is viewed as a long term, survival issue with the benefits associated with it occurring over time.
 
 * In this section, you will gain insights into [Customer Satisfaction Metrics](glossary://Customer%20Satisfaction%20Metrics) using tools to generate various metrics.
 */

/*: Setup and use a link reference.
 [Customer Satisfaction: The Ultimate Guide]: https://www.hubspot.com/customer-satisfaction
 [Guide to Net Promoter Score]: https://blog.hubspot.com/service/what-is-nps
 
 ### Additional Information:
 For more information regarding **post purchase behavior analytics**, view the following ...
 * [Customer Satisfaction: The Ultimate Guide]
 * [Guide to Net Promoter Score]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
