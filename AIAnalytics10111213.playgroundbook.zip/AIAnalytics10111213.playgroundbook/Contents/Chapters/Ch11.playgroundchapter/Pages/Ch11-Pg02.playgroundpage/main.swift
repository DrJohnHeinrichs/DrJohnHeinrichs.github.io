//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on the Text Mining Analytics Generation Process.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C11S02T00(topicTitle: "11.2 Text Mining Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("11.2.0 Overview")
            } else {
                    Image(systemName: "pencil")
                    Text("11.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Text Analytics Approaches
            // -------------------------
            C11S02T01(topicTitle: "11.2 Text Mining Analytics Generation")
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("11.2.1 Approaches")
                } else {
                    Image(systemName: "pencil")
                    Text("11.2.1 Approaches")
                } // if-else
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Customer Feedback Categorization and Topic Modeling
            // -------------------------
            C11S02T02(topicTitle: "11.2 Text Mining Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("11.2.2 Customer Feedback")
                } else {
                    Image(systemName: "pencil")
                    Text("11.2.2 Customer Feedback")
                } // if-else
                } // tabItem
            .tag("bookSection3")
            // -------------------------
            // TOPIC 3: Sentiment Analysis
            // -------------------------
            C11S02T03(topicTitle: "11.2 Text Mining Analytics Generation")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("11.2.3 Sentiment ")
                } else {
                    Image(systemName: "pencil")
                    Text("11.2.3 Sentiment")
                } // if-else
                } // tabItem
            .tag("bookSection4")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed Digital Marketing Content Analytics section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have four topic to complete.",
                        "-- Topic 0: Overview\n\nThis is a reading assignment.",
                        "-- Topic 1: Text Analytics Approaches\n\nThis is a reading assignment.",
                        "-- Topic 2: Customer Feedback Categorization and Topic Modeling\n\nThis is a reading assignment.",
                        "-- Topic 3: Sentiment Analysis\n\nThis is a reading assignment."
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Text Mining Tools for Post-Purchase Behavior Analytics
 ### Table of Contents - *Chapter 11*
 1. [Section 1: Post-Purchase Behavior Analytics Task](Ch11-Pg01)
 2. **[Section 2: Text Mining Analytics Generation Process](Ch11-Pg02)**
 3. [Section 3: Text Mining Analytics Interpretation and Application](Ch11-Pg03)
 4. [Section 4: AI Powered Text Mining - Cases](Ch11-Pg04)
 */

/*:
  * Callout(Examples): Enhance your knowledge of text mining tools
 by completing these interactive exercises.
 1. [Sentiment Analysis (Static Text)](SentimentAnalysis)
 2. [Sentiment Analysis (Interactive)](SentimentAnalysisImage)
 */

/*:
 * Callout(Quote: Post-Purchase Behavior Analytics):
 "Research is what I'm doing when I don't know what I'm doing."
 \
 –Werner von Braun
 */

/*:
 # Section 2: Text Mining Analytics Generation Process
 
 * Text analytics called text mining is used for processing the unstructured text data.
 * The selection of the appropriate text analytic steps depends on the analytic objectives and analytic questions developed by managers.
 * Text analytics is turning unstructured text data into actual information.
 * Text analytics covers information retrieval and extractions as well as data and web mining and supported by two primary technologies of Natural Language Processing (NLP) and machine learning using artificial intelligence (AI) system.
 * In order to use text analytics, managers need to follow several steps.  The steps are presented in the following figure.

 ## 2.1 Text Analytics Approaches
 ### Unstructured Input Data
 ### Input Text Editing and Preprocessing
 * Text Reduction
 * Tokenization 
 * In this challenge, you'll practice your [Sentiment Analysis](glossary://Sentiment%20Analysis)-finding skills by finding and rearranging.

 ## 2.2 Customer Feedback Categorization and Topic Modeling

 ## 2.3 Sentiment Analysis
 Sentiment analysis is performed when managers have analytic question of what do customers feel about our product or service.  Other analytic questions are related to understanding customer complaints and praises, knowing what customers say about our firm and competitors, customers’ posts on social media, their opinion about e-commerce sites and digital advertising, etc.  Sentiment analysis can provide analytic solutions by assessing favorable and unfavorable feelings or opinions toward specific products or services.
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **text mining analytics generation**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
