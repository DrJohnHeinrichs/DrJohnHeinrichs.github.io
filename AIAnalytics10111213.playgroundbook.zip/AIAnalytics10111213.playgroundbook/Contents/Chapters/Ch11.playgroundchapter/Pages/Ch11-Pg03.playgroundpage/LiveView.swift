//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 3: TText Mining Analytics Interpretation and Application
//
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter11
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Text Mining Tools for Post-Purchase Behavior Analytics")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero

    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .lineLimit(nil)
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                Image(uiImage: UIImage(named: "Post-Purchase-Behavior-Analytics.jpg")!)
//                Image(name: "Post-Purchase-Behavior-Analytics.jpg")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 350, height: 350)
                    .watermarked(with: "Photo by Pixabay from pexels.com")
                    .mask(RoundedRectangle(cornerRadius: 10.0))
                Spacer()
            // ---------------------
                C11S03T01Instructions()
            // ---------------------
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
struct Watermark: ViewModifier {
    var text: String

    func body(content: Content) -> some View {
        ZStack(alignment: .bottomTrailing) {
            content
            Text(text)
                .font(.caption)
                .foregroundColor(.white)
                .padding(5)
                .background(Color.black)
        }
    }
}
// ---------------------
// ---------------------
extension View {
    func watermarked(with text: String) -> some View {
        self.modifier(Watermark(text: text))
    }
}
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC11S03 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC11S03
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!!\n\nYou are taking the 'Text Mining Analytics Interpretation and Application' section.")
} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
