//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on Text Mining Analytics Interpretation and Application.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}

@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0000)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            C11S03T00(topicTitle: "11.3 Text Mining Analytics Interpretation and Application")
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("11.3.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("11.3.0 Overview")
                }
            } // tabItem
            .tag("bookSection1")
            // -------------------------
        } // TabView
            // -------------------------
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: "Congratulations!!!\n\nYou have successfully completed the Text Mining Analytics Interpretation topic.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Overview: Text Mining Analytics Interpretation and Application."
                    ], solution: "Try this to get it to work. \n\n ![Swipes](Gestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 0.4000)))
    } // body
} // struct

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Text Mining Tools for Post-Purchase Behavior Analytics
 ### Table of Contents - _Chapter 11_
 1. [Section 1: Post-Purchase Behavior Analytics Task](Ch11-Pg01)
 2. [Section 2: Text Mining Analytics Generation Process](Ch11-Pg02)
 3. **[Section 3: Text Mining Analytics Interpretation and Application](Ch11-Pg03)**
 4. [Section 4: AI Powered Text Mining - Cases](Ch11-Pg04)
 */

/*:
  * Callout(Examples): Enhance your knowledge of text mining tools
 by completing these interactive exercises.
 1. [Sentiment Analysis (Static Text)](SentimentAnalysis)
 2. [Sentiment Analysis (Interactive)](SentimentAnalysisImage)
 */

/*:
 * Callout(Quote: Post-Purchase Behavior Analytics):
 "Imagination is the highest form of research."
 \
 –Albert Einstein
 */

/*:
 # Section 3: Text Mining Analytics Interpretation and Application
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **text mining interpretation and application**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
