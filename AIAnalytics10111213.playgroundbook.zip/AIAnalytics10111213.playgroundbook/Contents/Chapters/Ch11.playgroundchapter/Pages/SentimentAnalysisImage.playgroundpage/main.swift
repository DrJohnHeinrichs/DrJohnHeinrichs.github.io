//#-hidden-code

import SwiftUI
import PlaygroundSupport
import NaturalLanguage

struct ContentView : View {
    
//    init() {
//        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0)
//        UINavigationBar.appearance().titleTextAttributes = [
//            .foregroundColor: UIColor.black,
//            .font : UIFont(name:"HelveticaNeue-Bold", size: 30)!]
//    } // init

    @State private var text: String = ""
    private var sentiment: String {
        return performSentimentAnalysis(for: text)
    }
    private let tagger = NLTagger(tagSchemes: [.sentimentScore])

    var body: some View {
//        NavigationView {
            VStack {
                Spacer()
                Text("Sentiment Analysis")
                    .font(.largeTitle)
                
                image(for: sentiment)
                    .animation(.default)

                TextField("Type text to be analyzed here.", text: $text)
                    .padding(.all)
                    .multilineTextAlignment(.center)
                    .lineLimit(nil)
                
                if sentiment == "Other" || sentiment == "" {
                    Text("Not enough information yet.")
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .animation(.default)
                    } else if sentiment >= "0.0001" {
                        Text("Positive sentiment of ... \(sentiment)")
                            .foregroundColor(.green)
                            .multilineTextAlignment(.center)
                            .animation(.default)
                    } else if sentiment <= "0.0001" {
                        Text("Negative sentiment of ... \(sentiment)")
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .animation(.default)
                    } else if sentiment == "-0.0000" {
                        Text("Neutral sentiment of ... \(sentiment)")
                            .foregroundColor(.blue)
                            .multilineTextAlignment(.center)
                            .animation(.default)
                    }
                Spacer()
            }
            //.frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 1.0000, green: 0.8314, blue: 0.4745, alpha: 1.0000))).edgesIgnoringSafeArea(.all)
            // VStack
//            .navigationBarTitle("Text Mining Tools", displayMode: .inline)
//        } // NavigationView
//        .navigationViewStyle(StackNavigationViewStyle())
    } // body

    private func performSentimentAnalysis(for string: String) -> String {
        tagger.string = string
        let (sentiment, _) = tagger.tag(at: string.startIndex,
                                        unit: .paragraph,
                                        scheme: .sentimentScore)
        return sentiment?.rawValue ?? ""
    } // func performSentimentAnalysis
    
    private func image(for sentiment: String) -> Image? {
        guard let value = Double(sentiment) else {
            return Image(systemName: "person.3.fill")
        }
     
        if value > 0.5 {
            return Image(systemName: "sun.max.fill")
        } else if value >= 0 {
            return Image(systemName: "gauge.badge.plus")
        } else if value > -0.5 {
            return Image(systemName: "gauge.badge.minus")
        } else {
            return Image(systemName: "cloud.fill")
        }
     
    } // func image
    
} // struct


if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

PlaygroundPage.current.assessmentStatus = .pass(message: "Congratulations!\n\nYou are practicing 'Sentiment Analysis' by interactively entering text.")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")

//#-end-hidden-code

/*:
## Text Mining Tools for Post-Purchase Behavior Analytics
### Table of Contents - _Chapter 11_
 1. [Section 1: Post-Purchase Behavior Analytics Task](Ch11-Pg01)
 2. [Section 2: Text Mining Analytics Generation Process](Ch11-Pg02)
 3. [Section 3: Text Mining Analytics Interpretation and Application](Ch11-Pg03)
 4. [Section 4: AI Powered Text Mining - Cases](Ch11-Pg04)
 */

/*:
  * Callout(Examples): Enhance your knowledge of text mining tools
 by completing these interactive exercises.
 1. [Sentiment Analysis (Static Text)](SentimentAnalysis)
 2. **[Sentiment Analysis (Interactive)](SentimentAnalysisImage)**
 */

/*:
# Interactive Playground
In this challenge, you'll practice your [Sentiment Analysis](glossary://Sentiment%20Analysis) - insight generation skills interactively by examining both positive and negative comments.
 * FIRST - "toggle" off **Enable Results** by selecting the icon that looks like a gauge
 * Click the **Run My Code** button
 * Enter text and note the change in sentiment
*/

/*: Setup and use a link reference.
 [Sentiment Analysis - Mood Detector]: https://martinmitrevski.com/2019/07/14/sentiment-analysis-with-natural-language-and-swiftui/
 [Using Core ML and Natural Language for Sentiment Analysis]: https://heartbeat.fritz.ai/using-core-ml-and-natural-language-for-sentiment-analysis-on-ios-d9469ce6c0ef
 [Natural Language Framework]: https://developer.apple.com/documentation/naturallanguage
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
For information regarding **sentiment analysis**, view the following ...
 * [Sentiment Analysis - Mood Detector]
 * [Natural Language Framework]
 * [Using Core ML and Natural Language for Sentiment Analysis]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
