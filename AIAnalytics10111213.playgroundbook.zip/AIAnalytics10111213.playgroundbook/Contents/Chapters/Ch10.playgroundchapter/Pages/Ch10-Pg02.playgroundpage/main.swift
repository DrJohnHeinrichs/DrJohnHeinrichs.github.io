//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses the uplift modeling analytics generation process.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    @State private var showingFigure101Sheet1 = false
    @State private var showingTable101Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("10.2.0 Overview")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("The A/B or split testing has become the standard method used to optimize marketing and advertising campaign.  A/B testing is common practice in many different marketing channels such as display ads, landing pages, and email marketing where copy, images, or placement can be adjusted.  The basic idea of A/B testing is splitting consumers into two groups (A and B) and showing each group a different version of the ad display.  The reactions of the consumers in each group are recorded and evaluated to see which version leads to the desired action.  In typical A/B testing, experimental design is utilized.\n")
                            .padding(.bottom, 380)
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("10.2 Uplift Modeling Analytics Generation Process", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("10.2.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("10.2.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
            // Start: Topic 1 - Experimental Design A/B Test
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("10.2.1 Experimental Design A/B Test")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("To evaluate causal effect, an experiment must have experimental manipulation, randomization, and multiple control or treatment groups.  Experimental manipulation involves varying an independent variable.  In promotional context, manipulation involves presenting different advertising copies to participants generating the experimental treatment.\n")

                        Text("For the scientific experiment, experimental participants are divided into different groups forming control groups and treatment groups.  Randomization refers to assigning participants randomly to control or treatment groups.  Experiment manipulates (varies) one or more factors while controlling all other factors and then measure the resulting output of interest such as sales or brand attitude.  In experiments, the timing of measuring the manipulated variables is important.  A measurement taken before treatment is called pretest and a measurement taken after treatment is called posttest.  The focus is testing the difference in posttest among control and treatment groups.  In order to evaluate the promotional effect, the experiment must include a specific call-to-action so that managers can trace the action such as a purchase to the presented promotional campaign advertising.  The two most commonly used experimental designs are posttest only with control group design and pretest-posttest with control group design.  Figure 10-1 shows these two experimental designs.\n")
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))

                        Section(header: Text("Figure 10-1 Control Group Design")){
                            Image(uiImage: UIImage(named: "Figure-10-1.jpg")!)
//                            Image(name: "Figure-10-1.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Button("Click for ... Figure 10-1: Control Group Design") {
                                self.showingFigure101Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingFigure101Sheet1) {
                                Figure101View1()
                            }
                            .padding(10)
                            Text("For example, an experiment with a posttest only with control group can be designed following the design shown in Figure 10-1.  Managers can recruit 500 customers and assign a randomly selected 250 customers to the control group and the remaining 250 customers to the treatment group.  A new advertisement is pretested to treatment group and the current advertisement is presented to control group.  The difference in sales between treatment group sales (O1) and control group sales (O2) indicate the potential sales increase using the new advertisement.\n")
                            Text("The presence of pretest in the pretest-posttest with control group design can provide more accurate assessment of the treatment effect than post-test only with control group design.  The pretest can eliminate preexisting differences between the control and treatment groups.  However, in certain situation, pretest measurement may not the feasible or too expensive.  These experiments can be conducted in laboratory or field settings.  Recently web experiments are increasingly used due to their speed and low cost.")
                            .padding(.bottom, 300)
                        }.listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("10.2 Uplift Modeling Analytics Generation Process", displayMode: .inline)

                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("10.2.1 Experimental Design")
                } else {
                    Image(systemName: "pencil")
                    Text("10.2.1 Experimental Design")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // Start: Topic 2 - Uplift Modeling and Campaign Optimization
            // ----------------------
            VStack {
                NavigationView {
                    List {
                    Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("10.2.2 Uplift Modeling and Campaign Optimization")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                        Text("Uplift modeling can answer the analytic question of the impact of promotional campaign on customers.  The effect of a promotion can be modeled at the individual level as well as the campaign level.  Uplift is defined as the increase in propensity of a customer purchase after receiving or being exposed to a promotional campaign.  Uplift models estimates the change in propensity of product purchase or other positive outcome that is the result of receiving the treatment as compared to the control group in A/B testing.  Managers need to conduct A/B testing using control and treatment groups and then record the observation that is either the intended outcome or purchase.  Within A/B test results, uplift is estimated for each customer by the probability of success with treatment minus the probability of success with no treatment.  Table 10-1 shows the uplift that is the change in propensities from receiving the promotional campaign versus not receiving the promotional campaign.  The probabilities shown in Table 10-1 are obtained from a logistic regression run of the A/B test data.")
                    .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                    }
                    Section(header: Text("Table 10.1: Uplift from Receiving the Promotional Campaign")) {
                        Image(uiImage: UIImage(named: "Table-10-1.jpg")!)
//                        Image(name: "Table-10-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 10-1: Uplift from Receiving the Promotional Campaign") {
                            self.showingTable101Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable101Sheet1) {
                            Table101View1()
                        }
                        .padding(10)
                    } .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
            } // List - text
                .padding(30)
                        .font(.system(size: 22))
                        .font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                .navigationBarTitle("10.2 Uplift Modeling Analytics Generation Process", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 2
            // ----------------------
            // End: Topic 2
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("10.2.2 Uplift Modeling")
                    } else {
                        Image(systemName: "pencil")
                        Text("10.2.2 Uplift Modeling")
                    } // If-Else
            } // tabItem
            .tag("bookSection2")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topics to complete.",
                        "-- Topic 1: Experimental Design A/B Test\n\nThis is a reading only assignment",
                        "-- Topic 2: Uplift Modeling and Campaign Optimization\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// FIGURE 10-1 VIEW
// ------------------------------
struct Figure101View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 10-1: Control Group Design")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-10-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 10-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 10-1 VIEW
// ------------------------------
struct Table101View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 10-1: Uplift from Receiving the Promotional Campaign")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-10-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 10-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")

//
//#-end-hidden-code
/*:
## Uplift Modeling Tools for Integrative Marketing Communication Analytics
### Table of Contents - _Chapter 10_
 1. [Section 1: Integrative Marketing Communication Analytics Task](Ch10-Pg01)
 2. **[Section 2: Uplift Modeling Analytics Generation Process](Ch10-Pg02)**
 3. [Section 3: Uplift Modeling Analytics Interpretation and Application](Ch10-Pg03)
 4. [Section 4: AI Powered A/B Testing and Optimization](Ch10-Pg04)
 */

/*:
 * Callout(Quote: Integrative Marketing Communication Analytics):
 "Content marketing is the only marketing left."
 \
 –Seth Godin
 */

/*:
 # Section 2: Uplift Modeling Analytics Generation Process

 ## 2.1 Experimental Design A/B Test
 
 ## 2.2 Uplift Modeling Campaign Optimization
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **uplift modeling analytics interpretation**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
