//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//
//  Chapter 10: Uplift Modeling Tools for Integrative Marketing Communication Analytics
//  Section 2: Uplift Modeling Analytics Generation Process
//
//
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter10
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct ContentView: View {
    let letters = Array("Uplift Modeling Tools for Integrative Marketing Communication Analytics")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero

    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .lineLimit(nil)
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                Image(uiImage: UIImage(named: "Integrative-Communication-Analytics.jpg")!)
//                Image(name: "Integrative-Communication-Analytics.jpg")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 350, height: 350)
                    .watermarked(with: "Photo by Marley Clovelly from pexels.com")
                    .mask(RoundedRectangle(cornerRadius: 10.0))
                Spacer()
            // ---------------------
                C10S02T01Instructions()
            // ---------------------
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
struct Watermark: ViewModifier {
    var text: String

    func body(content: Content) -> some View {
        ZStack(alignment: .bottomTrailing) {
            content
            Text(text)
                .font(.caption)
                .foregroundColor(.white)
                .padding(5)
                .background(Color.black)
        }
    }
}
// ---------------------
// ---------------------
extension View {
    func watermarked(with text: String) -> some View {
        self.modifier(Watermark(text: text))
    }
}
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC10S02 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC10S02
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!!\n\nYou are taking the 'Uplift Modeling Analytics Generation Process' section.")
} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
