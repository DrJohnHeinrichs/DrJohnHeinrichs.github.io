//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Uplift Modeling Analytics Interpretation and Application.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false
    @State private var showingFigure102Sheet1 = false
    @State private var showingFigure103Sheet1 = false
    @State private var showingTable102Sheet1 = false
    @State private var showingTable103Sheet1 = false
    @State private var showingTable104Sheet1 = false
    
    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0
    @GestureState var scale5: CGFloat = 1.0

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // ----------------------
            // Start: Topic 0 - Overview
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("10.3.0 Overview")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Uplifting modeling at the campaign level can also be built with some additional information such as response rate, sales per customer, cost of products or services, and marketing cost.  Again, the design is an A/B test with control and treatment groups.  Return on investment for the A/B tested campaign is presented in Table 10-2.\n")
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))

                        
                        Section(header: Text("Table 10-2 Return on Investment (ROI) of the A/B Tested Campaign")){
                            Image(uiImage: UIImage(named: "Table-10-2.jpg")!)
//                            Image(name: "Table-10-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
//                                .padding(.bottom, 30)
                            Button("Click for ... Table 10-2: Control Group Design") {
                                self.showingTable102Sheet1.toggle()
                            }
                            .font(.caption)
//                            .italic()
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable102Sheet1) {
                                Table102View1()
                            }
                            .padding(10)
                            Text("Table 10-2 results show how the promotional campaign received by the treatment group produce incremental positive outcome of various lifts when campaign to the control group without the promotional campaign.  Return on investment is calculated by:\n")
                            Image(uiImage: UIImage(named: "Equation-10-1.jpg")!)
//                            Image(name: "Equation-10-1.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            Text("In this example, incremental profit is 8.20 - 6.0 = $2.20.  Return on investment is 58.8% [(2.2 - 0.32)/0.32].  In calculating campaign profitability good test design with the sampling plans using the appropriate sampling frame is necessary to minimize the level of chance surrounding the test outcome.\n")
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
 //                       .padding(.bottom, 300)
                    } // List -- text
//                    .padding(30)
                    .font(.system(size: 22))
//                    .font(.headline)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("10.3 Uplift Modeling Analytics Interpretation and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 0
            // ----------------------
            // End: Topic 0
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("10.3.0 Overview")
                } else {
                    Image(systemName: "pencil")
                    Text("10.3.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection0")
            // ----------------------
            // Start: Topic 1 - Optimizing Campaign Profitability
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("10.3.1 Optimizing Campaign Profitability")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("Marketing campaigns record response rates for A/B testing using control and treatment groups.  Response models identify customers who are more likely to respond to a promotional campaign.  A response model can sort the prospect list by the likelihood to respond.  This ordered list is used to select the prospects for promotional campaigns with a fixed budget.  This typical model has the characteristics of lift and benefit shown in Figure 10 2.\n")
                        } // Section
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))

                        
                        Section(header: Text("Figure 10-2: Concentration Chart Showing the Benefit of Using a Response Model")){
                            Image(uiImage: UIImage(named: "Figure-10-2.jpg")!)
//                            Image(name: "Figure-10-2.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale2)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                            Text("Table 10-3 shows the data representing Figure 10-2.  In this table, 10% penetration shows the highest lift of 2.50.  While a smaller better targeted campaign can be more profitable at the campaign level, the absolute revenue is not optimized with a smaller campaign.  With a smaller campaign, the number of respondents will be smaller.  As a result, the total absolute revenue may be small too.\n")
                            .padding(.bottom, 10)
                        }.listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                        
                        
                        Section(header: Text("Table 10-3: Lift and Cumulative Gains")){
                            Image(uiImage: UIImage(named: "Table-10-3.jpg")!)
//                            Image(name: "Table-10-3.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale3)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale3, body: { (value, scale3, trans) in
                                    scale3 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 10)
                        Button("Click for ... Table 10-3: Lift and Cumulative Gains") {
                            self.showingTable103Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingTable103Sheet1) {
                                Table103View1()
                            }
                            .padding(10)

                            Text("Marketing managers are more interested in optimizing the profitability of a campaign using the response model.  The profitability may depend on the campaign cost, the response rate, revenue per response.  Managers need to make the best estimates of the information to optimize campaign profitability.  Figure 10-3 shows possible campaign profitability as a function of penetrations and 10% variation model.  This chart can be used to make campaign optimization decision by managers with different levels of situation assessment.\n")
                            .padding(.bottom, 30)
                        }.listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                        
                        
                        Section(header: Text("Figure 10-3: Campaign Profitability as a Function of Penetration and 10% Variation Model")){
                            Image(uiImage: UIImage(named: "Figure-10-3.jpg")!)
//                            Image(name: "Figure-10-3.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale4)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale4, body: { (value, scale4, trans) in
                                    scale4 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 10)
                        Button("Click for ... Figure 10-3: Campaign Profitability as a Function of Penetration and 10% Variation Model") {
                                self.showingFigure103Sheet1.toggle()
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                            .sheet(isPresented: $showingFigure103Sheet1) {
                                Figure103View1()
                            }
                            .padding(10)
                        }.listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
                        
                    } // List -- text
                    .padding(30)
                    .font(.system(size: 22))
//                    .font(.headline)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                    .navigationBarTitle("10.3 Uplift Modeling Analytics Interpretation and Application", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack - 1
            // ----------------------
            // End: Topic 1
            // ----------------------
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("10.3.1 Optimizing Campaign Profitability ")
                } else {
                    Image(systemName: "pencil")
                    Text("10.3.1 Optimizing Campaign Profitability ")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // ----------------------
            // Start: Topic 2 - Optimizing Total IMC Effectiveness
            // ----------------------
            VStack {
                NavigationView {
                    List {
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("10.3.2 Optimizing Total IMC Effectiveness")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("The linear optimization model can be used to develop a total IMC budget allocation model.  The optimization model maximizes the objective function to achieve optimal IMC budget allocation for a firm.  Marketing managers achieve maximization of customer contact and frequency using the optimization model.  IMC budget allocation can be made optimally using the model.  Considering the firm's marketing strategy, available budget, and selected touchpoint and media availability, the linear optimization modeling can maximize the marketing objective set by marketing managers.  Table 10-4 shows an example of a firm’s IMC mix table.  This table provides information regarding the touchpoint media type, expected number of customers reached, cost of campaign, time availability, and exposure quality rating.")
                        Text("Table 10-4 can be subjected to the linear optimization model to maximize the objective function of exposure quality or expected campaign profit.  As each touchpoint media type effectiveness diminishes with increased exposure to the same type of campaign, the maximum number of effective campaigns becomes the constraint.  For the total available IMC budget, marketing managers can optimally allocate the resources and determine the number of campaigns to be used for each of the touchpoint media types available for the firm.")
                        }
                        .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))

                        Section(header: Text("Table 10.4: IMC Mix Table")) {
                            Image(uiImage: UIImage(named: "Table-10-4.jpg")!)
//                            Image(name: "Table-10-4.jpg")
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale5)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale5, body: { (value, scale5, trans) in
                                    scale5 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 10)
                        Button("Click for ... Table 10-4: IMC Mix Table") {
                                    self.showingTable104Sheet1.toggle()
                                }
                                .font(.caption)
                                .foregroundColor(.blue)
                                .sheet(isPresented: $showingTable104Sheet1) {
                                    Table104View1()
                                }
                                .padding(10)

                        } .listRowBackground(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.2000)))
            } // List - text
                        
                .padding(30)
                        .font(.system(size: 22))
                        .frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
                .navigationBarTitle("10.3 Uplift Modeling Analytics Generation Process", displayMode: .inline)
                } // NavigationView
                .navigationViewStyle(StackNavigationViewStyle())
            } // VStack 2
            // ----------------------
            // End: Topic 2
            // ----------------------
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("10.3.2 Optimizing Total IMC Effectiveness ")
                    } else {
                        Image(systemName: "pencil")
                        Text("10.3.2 Optimizing Total IMC Effectiveness ")
                    } // If-Else
            } // tabItem
            .tag("bookSection2")
            // ----------------------
        } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topics to complete.",
                        "-- Topic 1: Optimizing Campaign Profitability\n\nThis is a reading only assignment",
                        "-- Topic 2: Optimizing Total IMC Effectiveness \n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)
                
        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------
// FIGURE 10-2 VIEW
// ------------------------------
struct Figure102View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 10-2: Concentration Chart Showing the Benefit of Using a Response Model")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-10-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 10-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 10-3 VIEW
// ------------------------------
struct Figure103View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 10-3: Campaign Profitability as a Function of Penetration and 10% Variation Model")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-10-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 10-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 10-2 VIEW
// ------------------------------
struct Table102View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 10-2: Return on Investment (ROI) of the A/B Tested Campaign")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-10-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 10-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 10-3 VIEW
// ------------------------------
struct Table103View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 10-3: Lift and Cumulative Gains")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-10-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 10-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 10-4 VIEW
// ------------------------------
struct Table104View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 10-4: IMC Mix Table ")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-10-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 10-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Uplift Modeling Tools for Integrative Marketing Communication Analytics
 ### Table of Contents - _Chapter 10_
 1. [Section 1: Integrative Marketing Communication Analytics Task](Ch10-Pg01)
 2. [Section 2: Uplift Modeling Analytics Generation Process](Ch10-Pg02)
 3. **[Section 3: Uplift Modeling Analytics Interpretation and Application](Ch10-Pg03)**
 4. [Section 4: AI Powered A/B Testing and Optimization](Ch10-Pg04)
 */

/*:
 * Callout(Quote: Integrative Marketing Communication Analytics):
 "The aim of marketing is to know and understand the customer so well the product or service fits him and sells itself."
 \
 –Peter F. Drucker
 */

/*:
 # Section 3: Uplift Modeling Analytics Interpretation and Application

 ## 3.1 Optimizing Campaign Profitability
 
 ## 3.2 Optimizing Total IMC Effectiveness
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **uplift modeling analytics**, view the following ...
 * [The Swift Programming Language]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
