//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//
//  Chapter 4: Visualization Tools for Marketing Environment Analytics
//  Section 1: Marketing Environment Analytics Task
//
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter4

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
struct Flower: Shape {
    var petalOffset: Double = -20
    var petalWidth: Double = 100
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        for number in stride(from: 0, to: CGFloat.pi * 2, by: CGFloat.pi / 8) {
            let rotation = CGAffineTransform(rotationAngle: number)
            let position = rotation.concatenating(CGAffineTransform(translationX: rect.width / 2, y: rect.height / 2))
            let originalPetal = Path(ellipseIn: CGRect(x: CGFloat(petalOffset), y: 0, width: CGFloat(petalWidth), height: rect.width / 2))
            let rotatedPetal = originalPetal.applying(position)
            path.addPath(rotatedPetal)
        } // for
        return path
    } // func - path
} // struct - Flower
// -----------------------
struct Arc: InsettableShape {
    var startAngle: Angle
    var endAngle: Angle
    var clockwise: Bool
    var insetAmount: CGFloat = 0
    
    func path(in rect: CGRect) -> Path {
        let rotationAdjustment = Angle.degrees(90)
        let modifiedStart = startAngle - rotationAdjustment
        let modifiedEnd = endAngle - rotationAdjustment
        
        var path = Path()
        
        path.addArc(center: CGPoint(x: rect.midX, y: rect.midY), radius: rect.width / 2 - insetAmount, startAngle: modifiedStart, endAngle: modifiedEnd, clockwise: !clockwise)
        
        return path
    } // func - path
    
    func inset(by amount: CGFloat) -> some InsettableShape {
        var arc = self
        arc.insetAmount += amount
        return arc
    } // func - inset
} // struct - Arc
// -----------------------
struct ContentView: View {
    let letters = Array("Visualization Tools for Marketing Environment Analytics")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero
    @State private var petalOffset = -20.0
    @State private var petalWidth = 100.0

    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                VStack{
                    Flower(petalOffset: petalOffset, petalWidth: petalWidth)
                    .fill(Color.yellow, style: FillStyle(eoFill: true))
                    Spacer()
                    HStack{
                        Text("Offset -->")
                        Slider(value: $petalOffset, in: -40 ... 40)
                            .padding(.bottom)
                    } // HStack
                    HStack{
                        Text("Width -->")
                        Slider(value: $petalWidth, in: 0 ... 100)
                            .padding(.horizontal)
                    } // HStack
                } // VStack
                .frame(width: 400, height: 400)
                C04S01T01Instructions()
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC04S01 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC04S01
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!\n\nYou are taking the 'Market Environment Analytics Task' section.")

} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
