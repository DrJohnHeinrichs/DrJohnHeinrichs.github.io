//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on Integrative Marketing Communication Analytics Tasks.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C10S01T00(topicTitle: "10.1 Integrative Marketing Communication Analytics Task")
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("10.1.0 Overview")
            } else {
                    Image(systemName: "pencil")
                    Text("10.1.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed the **Integrative Marketing Communication Analytics Task** section.")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have one topic to complete.",
                        "-- Topic 1: Integrative Marketing Communication Analytics Task\n\nThis is a reading assignment. "
                    ], solution: "Try this to get it to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5804, green: 0.3216, blue: 0.0000, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 ## Uplift Modeling Tools for Integrative Marketing Communication Analytics
 ### Table of Contents - _Chapter 10_
 1. **[Section 1: Integrative Marketing Communication Analytics Task](Ch10-Pg01)**
 2. [Section 2: Uplift Modeling Analytics Generation Process](Ch10-Pg02)
 3. [Section 3: Uplift Modeling Analytics Interpretation and Application](Ch10-Pg03)
 4. [Section 4: AI Powered A/B Testing and Optimization](Ch10-Pg04)
 */

/*:
 * Callout(Quote: Integrative Marketing Communication Analytics):
 "In order to be effective, marketers need to have credibility. Because they have to do a lot of leading by influence, they have to do a lot of aligning and engaging and evangelizing, and that only works when people trust you. They only trust you if you deliver the goods and are accountable; you do what you say and you say what you mean."
 \
 –Peter Horst
 */

/*:
 # Section 1: Integrative Marketing Communication Analytics Task

 * Finding the right customers involves developing both a [Profile](glossary://Profile) and [Segmenting](glossary://Segmenting) the market.
 * A social profile can be developed by profiling the community to which that individual belongs.  
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/

 ### Additional Information:
 For more information regarding **integrative marketing communication analytics**, view the following ...
 * [The Swift Programming Language] 
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
