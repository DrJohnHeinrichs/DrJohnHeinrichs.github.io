//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ---------------------
// ---------------------
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section focuses on describing the market environment analytics tasks.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ---------------------
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
            
        TabView(selection: $selectedTab) {
            // -------------------------
            // TOPIC 0: Overview
            // -------------------------
            C04S01T00(topicTitle: "4.1 Market Environment Analytics Task")
            .tabItem {
                if understandSection {
                    Image(systemName: "star.fill")
                    Text("4.1.0 Overview")
            } else {
                    Image(systemName: "pencil")
                    Text("4.1.0 Overview")
                } // if-else
                } // tabItem
            .tag("bookSection1")
            // -------------------------
            // TOPIC 1: Market Trend Analytics
            // -------------------------
            C04S01T01(topicTitle: "4.1 Market Environment Analytics Task")
            .tabItem {
                if understandSection {
                        Image(systemName: "star.fill")
                        Text("4.1.1 Market Trend Analytics")
                } else {
                    Image(systemName: "pencil")
                    Text("4.1.1 Market Trend Analytics")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Competitor Analytics
            // -------------------------
            C04S01T02(topicTitle: "4.1 Market Environment Analytics Task")
                .tabItem {
                    if understandSection {
                            Image(systemName: "star.fill")
                            Text("4.1.2 Competitor Analytics")
                } else {
                        Image(systemName: "pencil")
                        Text("4.1.2 Competitor Analytics")
                    }
                    } // tabItem
                .tag("bookSection3")
            // -------------------------
            } // TabView
            // -------------------------
            // ASSESSMENT
            // -------------------------
            HStack {
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!\n\nYou have successfully completed 'Market Environment Analytics Task' section.")
                } )
                {
                    Text("I understand these topics")
                } // button - understand
                    .foregroundColor(.green)
                    .padding(10)
                    .background(Color.white)
                    .mask(RoundedRectangle(cornerRadius: 7.0))
                // -------------------------
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topic to complete.",
                        "-- Topic 1: Market Trend Analytics\n\nThis is a reading assignment.",
                        "-- Topic 2: Competitor Analytics\n\nThis is a reading assignment. "
                    ], solution: "Try this to get this section material to work. \n\n ![Swipes](C01S03HintGestures_Swipe.mp4)")
                } )
                {
                    Text("I need a 'Hint' on these topics")
                } // button - need help
                    .foregroundColor(.red)
                    .padding(10)
                    .background(Color.white)
                    .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
            } // HStack
                // -------------------------
                .padding (.top, 15)
                .padding (.bottom, 15)
            // -------------------------
        } // Group
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
//
//#-end-hidden-code
/*:
 # Visualization Tools for Marketing Environment Analytics
### Table of Contents - _Chapter 4_
 1. **[Section 1: Market Environment Analytics Task](Ch04-Pg01)**
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart - Interactive](BarChart2)
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. [Pie Chart](PieChart)
 6. [Scatter Chart](ScatterChart)
 */

/*:
 * Callout(Quote: Visualization):
 "An intelligent person is never afraid or ashamed to find errors in his understanding of things."
 \
 –Bryant H. McGill
 */

/*:
 ## Section 1: Market Environment Analytics Task
 
 ## 1.1 Market Trend Analytics
 
 ## 1.2 Competitor Analytics

 * In this topic, you'll focus on identifying the [Market Scope](glossary://Market%20Scope).
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Data Analytic Cartoons]: http://cartertoons.com/product-category/data-analytics-cartoons/
 [Data Visualization: What it is and how it adds value]: https://sproutsocial.com/insights/data-visualization/

 ### Additional Information:
 For more information regarding **marketing environment analytics tasks**, view the following ...
 * [Data Analytic Cartoons]
 * [Data Visualization: What it is and how it adds value]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
