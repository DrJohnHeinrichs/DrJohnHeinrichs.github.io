//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVFoundation
// ----------------------
// ----------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ----------------------
// ----------------------
extension Image {
    public init(name: String){
        self.init(uiImage: #imageLiteral(resourceName: name))
    } // init
} // extension
// ----------------------
// ----------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This section discusses Digital Sites Rating Analytics.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
// ---------------------
public func console(message: String) {
    PlaygroundPage.current.assessmentStatus = .pass(message: message)
}

public func console(hints: [String]) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
}

public func console(hints: [String], solution: String?) {
    PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
}
// ----------------------
// ----------------------
@available(iOSApplicationExtension 13.0.0, *)
struct ContentView: View {
    
    @State private var selectedTab = "bookSection0"
    @State private var backgroundColor = Color.yellow
    @State private var understandSection = false

    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 1.0)
        UINavigationBar.appearance().titleTextAttributes = [
        .foregroundColor: UIColor.black,
        .font : UIFont(name:"HelveticaNeue-Bold", size: 24)!]
        } // init
    
    var body: some View {
        Group {
        TabView(selection: $selectedTab) {
            // -------------------------
            // Start: Topic 1 - Digital Sites Management Task
            // ----------------------
            C13S02T01(topicTitle: "13.1 Digital Marketing Content Analytics")
            .tabItem {
                if understandSection {
                    VStack{
                        Image(systemName: "star.fill")
                        Text("13.1.1 Digital Marketing Content Management Task")
                    }
                } else {
                    Image(systemName: "pencil")
                    Text("13.1.1 Digital Marketing Content Management Task")
                }
                } // tabItem
            .tag("bookSection2")
            // -------------------------
            // TOPIC 2: Digital Sites Analytics Generation, Interpretation, and Application
            // -------------------------
            C13S02T02(topicTitle: "13.1 Digital Marketing Content Analytics")
                .tabItem {
                    if understandSection {
                        Image(systemName: "star.fill")
                        Text("13.2.2 Generation, Interpretation, and Application")
                    } else {
                        Image(systemName: "pencil")
                        Text("13.2.2 Generation, Interpretation, and Application")
                    } // If-Else
            } // tabItem
            .tag("bookSection3")
            // -------------------------
            } // TabView
            HStack {
                Spacer()
                Button(action: {
                    self.understandSection = true
                    console(message: " Congratulations!!!!!")
                } )
                {
                        Text("I understand these topics")
                    } // button - understand
                        .foregroundColor(.green)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                Spacer()
                Button(action: {
                    self.understandSection = false
                    console(hints: [
                        "You have two topics to complete.",
                        "-- Topic 1: Digital Sites Management Task\n\nThis is a reading only assignment",
                        "-- Topic 2: Digital Sites Analytics Generation, Interpretation, and Application\n\nThis is a reading only assignment"
                    ])
                } )
                {
                        Text("I need a 'Hint' on these topics")
                    } // button - need help
                        .foregroundColor(.red)
                        .padding(10)
                        .background(Color.white)
                        .mask(RoundedRectangle(cornerRadius: 7.0))
                    Spacer()
            } // HStack
                .padding (.top, 15)
                .padding (.bottom, 15)

        } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.4000)))
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}
// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
## Digital Marketing Content and User Interactivity Analytics
### Table of Contents - _Chapter 13_
 1. [Section 1: Digital Marketing Content Analytics](Ch13-Pg01)
 2. **[Section 2: Digital Sites Rating Analytics](Ch13-Pg02)**
 3. [Section 3: Digital Sites User Engagement Analytics](Ch13-Pg03)
 4. [Section 4: AI Powered Digital Content and User Interactivity Analytics](Ch13-Pg04)
 */

/*:
* Callout(Quote: Digital Marketing Content and User Interactivity Analytics):
"Instead of one-way interruption, Web marketing is about delivering useful content at just the right moment that a buyer needs it."
\
–David Meerman Scott
*/

/*:
 # Section 2: Digital Sites Rating Analytics
 
 ## 2.1 Digital Sites Rating Management Task
 ### 2.2 Digital Sites Rating Analytics Generation, Interpretation, and Application

 ### Marketing.Grader.com
 For more information on WebSite Grader, see [How Strong is Your Website?](https://website.grader.com/)
 
 ### Nibbler.com
 For more information on Nibbler, see [How ](https://website.grader.com/)

 ### Woorank.com
 For more information on Woorank, see [How ](https://website.grader.com/)
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [AI Score for Marketers]: https://score.marketingaiinstitute.com/
 [Website Traffic Analysis Tools]: https://blog.hubspot.com/website/website-traffic-analysis-tools
 
 ### Additional Information:
 For more information regarding digital site rating analytics, view the following ...
 * [AI Score for Marketers]
 * [Website Traffic Analysis Tools]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
