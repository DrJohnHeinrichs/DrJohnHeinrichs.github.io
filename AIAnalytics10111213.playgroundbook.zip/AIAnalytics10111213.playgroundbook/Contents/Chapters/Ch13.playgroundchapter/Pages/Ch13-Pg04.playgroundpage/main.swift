//#-hidden-code
//
import SwiftUI
import UIKit
import PlaygroundSupport
import AVKit
import AVFoundation
import WebKit
import Combine
// ---------------------
public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}
// ---------------------
let speakTalk   = AVSpeechSynthesizer()
let speakMsg    = AVSpeechUtterance(string: "This is the AI Powered Classification Analytics section.")

speakMsg.voice  = AVSpeechSynthesisVoice(language: "en-US")
speakMsg.pitchMultiplier = 1.2
speakMsg.rate   = 0.5
speakTalk.speak(speakMsg)
// ---------------------
@available(iOSApplicationExtension 13.0.0, *)
//
// ---------------------
// This is an extension to Image
// -- it appears that PlaygroundBooks cannot handle the Image object correctly -- this is a workaround
//
extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ----------------------
// This saves data for indicating if the topic is understood or completed
//
class SavedBookCases: ObservableObject {
    // the actual bookCases the user has favorited
    private var bookCases: Set<String>
    
    // the key we are using to read/write in UserDefaults
    private let saveKey = "Chapter-6-Cases-1"

    init() {
        // load our saved data
        if let savedSet = UserDefaults.standard.array(forKey: saveKey) as? [String] {
            bookCases = Set(savedSet)
            return
        } // if
        // still here? Use an empty array
        self.bookCases = []
    } // init
    
    // returns true if our set contains this bookCase
    func contains(_ bookCase: BookCase) -> Bool {
        bookCases.contains(bookCase.id)
    } // func - contains
    
    // adds the bookCase to our set, updates all views, and saves the changes
    func add(_ bookCase: BookCase) {
        objectWillChange.send()
        bookCases.insert(bookCase.id)
        save()
    } // func - add
    
    // removes
    func remove(_ bookCase: BookCase) {
        objectWillChange.send()
        bookCases.remove(bookCase.id)
        save()
    } // func - remove
    
    func total() -> Int {
        bookCases.count
    } // func - total
    
    // saves
    func save() {
        // write out our data
        UserDefaults.standard.set(Array(bookCases), forKey: saveKey)
    } // func - save
} // class - SavedBookCases
// ----------------------
// This defines the JSON file
//
struct BookCase: Codable, Identifiable {
    let id: String
    let name: String
    let country: String
    let description: String
    let decisiontask: String
    let aisolution: String
    let aiapplication: String
    let industry: Int
    let urlVideo: String
    let imageCredit: String
    let price: Int
    let size: Int
    let snowDepth: Int
    let elevation: Int
    let runs: Int
    var highlightTypes: [Highlight] {
        highlights.map(Highlight.init)
    }
    let highlights: [String]
}
// ----------------------
// This sets up the JSON file
//
extension Bundle {
    func decode<T: Decodable>(_ file: String) -> T {
        guard let url = self.url(forResource: file, withExtension: nil) else {
            fatalError("Failed to locate \(file) in bundle.")
        }

        guard let data = try? Data(contentsOf: url) else {
            fatalError("Failed to load \(file) from bundle.")
        }

        let decoder = JSONDecoder()

        guard let loaded = try? decoder.decode(T.self, from: data) else {
            fatalError("Failed to decode \(file) from bundle.")
        }

        return loaded
    }
}
// ----------------------
// This is a child view -- IndustryDetailsView --
//
struct IndustryDetailsView: View {
    
    @EnvironmentObject var settings: CaseSettings

    let bookCase: BookCase
    
    var industry: String {
        switch bookCase.industry {
            case 1:
                return "Automotive"
            case 2:
                return "Banking"
            case 3:
                return "Education"
            case 4:
                return "Media & Entertainment"
            default:
                return "Industries"
        } // switch - industry
    } // industry

    var body: some View {
        Group {
            Text("Industry: \(industry)").layoutPriority(1)
        } // Group
            .padding(.trailing, 20)
    } // body
} // struct
// ----------------------
// This is a child view -- CompanyDetailsView
//
struct CompanyDetailsView: View {
    let bookCase: BookCase
    var size: String {
        switch bookCase.size {
            case 1:
                return "Small"
            case 2:
                return "Average"
            default:
            return "Large"
        } // switch - size
    } // size

    var price: String {
        String(repeating: "$", count: bookCase.price)
    } //var - price
    
    var body: some View {
        Group {
            Text("Firm Size: \(size)").layoutPriority(1)
            Spacer().frame(height: 0)
            Text("Market Valuation: \(price)").layoutPriority(1)
        } // Group
        .padding(.leading, 20)
    } // body
} // struct
// ----------------------
// This is the detail view -- BookCaseView --
// -- it is called by ContentView
// -- it has two child views -- CompanyDetailsView and IndustryDetailsView
//
struct BookCaseView: View {
//    var urlVideo1: String = "https://youtube.com/watch?v=T_aFqEmL5JI&t=1s&rel=0&autoplay=1"
//    http://www.youtube.com/Bdx5kTFLF4o?enablejsapi=1
    let bookCase: BookCase
    @Environment(\.horizontalSizeClass) var sizeClass
    @EnvironmentObject var favorites: SavedBookCases
    @State private var selectedHighlight: Highlight?
    var screenSize: CGRect = UIScreen.main.bounds
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Group {
                    VStack {
                        Text("AI Powered Classification Analytics")
                        .font(.largeTitle)
                            .padding(.top, 80)
                        WebView(request: URLRequest(url: URL(string: bookCase.urlVideo)!))
                        .frame(width: screenSize.width/2.0, height: screenSize.height/2.5)
                        .background(Color.red)
                        .padding(.horizontal, 10)
                        Spacer()
                    } // VStack
                    Text(bookCase.description)
                        .padding(.vertical, 20)
                        .padding(.leading, 40)
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)

                    VStack {
                        Text("Decision Task")
                            .font(.headline)
                            .padding(20)
                        Text(bookCase.decisiontask)
                            .padding(.leading, 40)
                            .padding(.trailing, 20)
                            .padding(.bottom, 20)
                    }
                    
                    VStack {
                        Text("AI Powered Solution")
                            .font(.headline)
                            .padding(20)
                        Text(bookCase.aisolution)
                            .padding(.leading, 40)
                            .padding(.trailing, 20)
                            .padding(.bottom, 20)
                    }
                    
                    VStack {
                        Text("AI Powered Solution Application")
                            .font(.headline)
                            .padding(20)
                        Text(bookCase.aiapplication)
                            .padding(.leading, 40)
                            .padding(.trailing, 20)
                            .padding(.bottom, 20)
                    }

                    HStack {
                        if sizeClass == .compact {
                        Spacer()
                            VStack{ CompanyDetailsView(bookCase: bookCase) }
                            VStack{ IndustryDetailsView(bookCase: bookCase) }
                            
                        Spacer()
                        } else {
                            CompanyDetailsView(bookCase: bookCase)
                            Spacer().frame(height: 0)
                            IndustryDetailsView(bookCase: bookCase)
                        } // if-else
                    } // HStack
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding(.top)
                    
                    Text("Case Comments")
                        .font(.headline)
                        .padding(20)
                    
                    HStack{
                        ForEach(bookCase.highlightTypes) { highlight in
                            highlight.icon
                            .font(.title)
                            .onTapGesture {
                                self.selectedHighlight = highlight
                            } // onTapGesture
                        } // ForEach
                    } // HStack
                    //Text(ListFormatter.localizedString(byJoining: bookCase.highlights))
                    
                        .padding(.vertical)
                } // Group
                .padding(.horizontal)
            } // VStack
            Button(favorites.contains(bookCase) ? "Remove from ... Understand/Completed" : "Add to ... Understand/Completed") {
                if self.favorites.contains(self.bookCase) {
                    self.favorites.remove(self.bookCase)
                } else {
                    self.favorites.add(self.bookCase)
                } // if-else
            } // Button
                .padding(.bottom, 50)
        } // ScrollView
            .padding(.bottom, 150)
            .edgesIgnoringSafeArea(.all)
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            .navigationBarTitle(Text("Application Case: \(bookCase.name)"), displayMode: .inline)
            .background(Color(UIColor(red: 1.0000, green: 0.1843, blue: 0.5725, alpha: 0.7000)))
        .alert(item: $selectedHighlight) { highlight in
            highlight.alert
        } // .alert
    } // body
} // struct
// ----------------------
struct Highlight: Identifiable {
    let id = UUID()
    var name: String
    
    //static func icon(for highlight: String) -> some View {
    var icon: some View {

    let icons = [
            "Headquarters": "house",
            "Training": "circle",
            "Culture": "map",
            "Eco-friendly": "leaf.arrow.circlepath",
            "Human-Resources": "person.3"
        ]
        
        if let iconName = icons[name] {
            let image = Image(systemName: iconName)
                .accessibility(label: Text(name))
                .foregroundColor(.secondary)
            return image
        } else {
            fatalError("Unknown highlight type: \(name)")
        } // if-let
    } // var-icon

    var alert: Alert {
    let messages = [
            "Headquarters": "This firm has an expansive headquarters.",
            "Training": "This firm offers online and onsite training options.",
            "Culture": "This firm has a positive work culture.",
            "Eco-friendly": "This firm has won awards for environmental friendly actions.",
            "Human-Resources": "This firm has HR friendly options."
        ]
        
        if let message = messages[name] {
            return Alert(title: Text(name), message: Text(message))
        } else {
            fatalError("Unknown highlight type: \(name)")
        } // if-else
    } // var - alert
} // struct
// ----------------------
class CaseSettings: ObservableObject {
    @Published var industryName = "John"
    let objectWillChange = ObservableObjectPublisher()

       var industryName1 = "" {
           willSet {
               objectWillChange.send()
           }
       }
}
// ----------------------
// This is the main screen -- ContentView --
// -- the master view for the List -- using the json file
//
struct ContentView: View {
    let bookCases: [BookCase] = Bundle.main.decode("bookCases.json")
    @ObservedObject var favorites = SavedBookCases()
    
    // Each Chapter has a different color
    init() {
        UINavigationBar.appearance().backgroundColor = UIColor(red: 1.0000, green: 0.1843, blue: 0.5725, alpha: 0.7000)
        UINavigationBar.appearance().titleTextAttributes = [
            .foregroundColor: UIColor.blue,
            .font : UIFont(name:"HelveticaNeue-Bold", size: 22)!]
    } // init
    
    var body: some View {
        NavigationView {
            List(bookCases) { bookCase in
                NavigationLink(destination: BookCaseView(bookCase: bookCase)) {
                    Image(name: bookCase.country)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 40, height: 25)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 5)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(Color.black, lineWidth: 1)
                        )

                    VStack(alignment: .leading) {
                        Text(bookCase.name)
                            .font(.headline)
                    } // VStack
                    .layoutPriority(1)
                    if self.favorites.contains(bookCase){
                        Spacer()
                        Image(systemName: "checkmark.circle.fill")
                            .accessibility(label: Text("I understand this case"))
                            .foregroundColor(.green)
                    } // if
                    
                } // Navigation Link
                
            } // List
            .navigationBarTitle("Classification Analytics Cases")
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                .background(Color(UIColor(red: 1.0000, green: 0.1843, blue: 0.5725, alpha: 0.7000)))

            WelcomeView()
        } // Navigation View
        .environmentObject(favorites)
        //.navigationViewStyle(StackNavigationViewStyle())
    } // body
} // struct
// ----------------------
// This is the first screen -- the WelcomeView -- it provides instructions on how to run the playground
//
struct WelcomeView: View {
    
    var body: some View {
        VStack {
            Divider().frame(height: 5).background(Color.blue)
            HStack {
                Spacer()
                Text("Welcome to ...")
                    .font(.largeTitle)
                Spacer()
            } // HStack 1
            HStack {
                Spacer()
                Text("AI Powered Classification Analytics Cases!")
                    .font(.largeTitle)
                Spacer()
            } // HStack 2
            Divider().frame(height: 5).background(Color.blue)
            Text("-- Please select a case from the left-hand menu;")
            .foregroundColor(.secondary)
            Text("-- Swipe from the left edge to show the menu;")
            .foregroundColor(.secondary)
        } // VStack
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            .background(Color(UIColor(red: 1.0000, green: 0.1843, blue: 0.5725, alpha: 1.0000)))
    } // body
} // struct
// ----------------------
struct WebView: UIViewRepresentable {
    let request: URLRequest
    
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        
        let webView = WKWebView(frame: .zero, configuration: configuration)
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context){
        uiView.load(request)
    }
}
// ----------------------
struct player: UIViewControllerRepresentable {
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<player>) -> AVPlayerViewController {
        
        let controller = AVPlayerViewController()
        let url = "http://s3.amazonaws.com/vids4project/sample.mp4"
        let player1 = AVPlayer(url: URL(string: url)!)
        controller.player = player1
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: UIViewControllerRepresentableContext<player>){
    
    }
}
// ----------------------
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

 PlaygroundPage.current.assessmentStatus = .pass(message: "Congratulations!\n\nYou are taking the 'AI Powered Classification Analytics' topic.")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code
/*:
 ## Classification Tools for Market Targeting Analytics
 ### Table of Contents - _Chapter 6_
 1. [Section 1: Market Targeting Analytics Task](Ch06-Pg01)
 2. [Section 2: Classification and Prediction Analytic Solution Generation](Ch06-Pg02)
 3. [Section 3: Classification Analytic Solution Interpretation and Application](Ch06-Pg03)
 4. **[Section 4: AI Powered Classification Analytics](Ch06-Pg04)**
 */

/*:
 * Callout(Quote: Classification Analytics):
 "Most of the world will make decisions by either guessing or using their gut. They will be either lucky or wrong"
 \
 –Suhail Doshi
 */

/*:
 ## 4. AI Powered Classification Analytics
 * The classification and prediction models can be developed by marketing managers and analysts within the firm.  These user driven analytics can be used effectively for targeting decisions.  Additionally, firms can utilize AI powered classification algorithms for targeting decisions.
 */

/*:
 ## 4.1 AI Powered Classification Algorithm
 * One form of directed learning algorithm is the classification model.  In this directed AI learning model, the algorithm can be developed to map an input and output.  Directed classification models map a set of input features to a discrete class label.  The input can take many different forms such as numerical values, categorical values, text, image, video, and others and is then converted to some meaningful features.  The output can be a discrete class from a pre-defined set of labels.  In AI powered classification algorithms, input can be a binary variable such as purchase versus no-purchase and the output can be interpreted as the probability of target class.  AI classification algorithms can use the user-generated classifiers to build the AI model.  In this case, typical user-generated classifiers are rule-based classifier or the classification results generated from the user-generated classification tools such as k-means clustering or neural networks.  As the AI algorithm updates the classification model with new data and learns new knowledge, the model can be improved to achieve higher efficiency, updated to reflect the customer changes, or reformulated to gain different insights.  AI algorithms can identify which customer segments need to be targeted and find better match customers for the firm’s products and brands.  In business-to-business marketing, an important task is identifying and qualifying potential leads for further action.  AI can make the target account selection process more efficient by building a model that identifies accounts of existing and new customers based on the predefined attributes.  The AI-driven model can help salespeople give access to a large number of ideal prospects and make more accurate choices when prospecting based on fact-based decisions.
 * Marketing managers can develop and train machine learning algorithms based on the user driven classification models, the firm’s big data, and other external data.  AI powered classification algorithms can build actionable customer segments by using an advanced machine-learning engine and develop personas based on big data that includes past and current real-time customer interactions of the firm’s all touch points, typical segmentation variables such as psychographic and demographic variables, macro trends, and geo-specific events.  AI algorithms can crunch huge amount of data and generate marketing insights customizable to customers’ behavioral patterns of various customer segments.  Using these AI generated insights, marketing managers can identify more clearly which customer segments to target, better match products with customer segments, and increase revenue for various customer segments with more effective customer relationship management.
 * Marketing managers can use AI powered classification algorithms to reach their customers with the level of personalization and targeting at the granular level.  With AI and machine learning, marketing managers can develop and implement dynamic segmentation.  Dynamic segmentation applies AI to a firm’s segmentation and targeting tasks in order to consider the fact that customers’ behaviors are changing and take different personas.  Dynamic segmentation can group potential customers with real-time data instead of outdated data for targeting driven using AI powered algorithms.  For business-to-business marketing firms, AI can be used by marketing managers to filter out customer firms from its list of prospects and help firms for effective targeting and customization.
 */

/*:
 ## 4.2 AI Powered Targeting Application Case: WisdomTree Investments Inc.
 * WisdomTree's Decision Task
 * WisdomTree's AI Powered Solution
 * WisdomTree's AI Powered Solution Application and Outcome
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [WindomTree Investments Case Study]: https://www.ibm.com/case-studies/wisdomtree-investments-inc

 ### Additional Information:
 For more information regarding **classification analytics**, view the following ...
 * [WindomTree Investments Case Study]
*/

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
