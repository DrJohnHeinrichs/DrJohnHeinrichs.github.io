//
//  C10S01T00.swift
//  Book_Sources
//
//  Chapter 10: Uplift Modeling Tools for Integrative Marketing Communication Analytics
//  Section 1: Integrative Marketing Communication Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C10S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("10.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer-oriented Approach")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing based on a customer-oriented approach calls for more than developing a good product, pricing attractively, and making accessible to target markets.  Firms also need to position products in their target customers’ mind by promoting them effectively.  Marketing managers manage a complex system of promotion.  Firms promote their products throughout the value chain.  Customers engage in word-of-mouth communication with other customers and the general public providing feedback to these groups.  Traditionally, promotion mix consists of four major tools: advertising, sales promotion, publicity, and personal selling.  Recently, firms have begun adopting a variety of web-based promotions as a part of their overall promotional mix.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Advertising")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Advertising is one of the promotional mixes that firms use to direct persuasive communications to target buyers.  It is characterized by non-personal, one way, and paid form of marketing communication.  It is quite effective in influencing customer attitude, purchase intention, and purchasing behavior.  An advertising program is developed using a five-step procedure: objectives setting, budget decisions, message decision, media decision, and advertising evaluation.  In developing advertising programs, these five decisions should start with the target market.  The most difficult step for most marketing managers to understand and perform is the advertising evaluation.  Advertising effectiveness is hard to accurately measure especially on sales.  This difficulty can be attributed to various characteristics of advertising effects.  Advertising effects occur over time and can exhibit a long-term carryover influence.  In addition, advertising effects may be non-linear and interact with other marketing mix variables.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Relationship Driven")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Under customer relationship-driven marketing, firms need to manage the firm-customer interface effectively.  In managing this interface, firms first find out how and what customers want to hear from the firm.  A firm’s promotional campaign must target customer who both want to hear about the firm’s particular offer as well as are qualified buyers.  A firm sends promotional offers or messages only to those who are more likely to respond to them.  This will increase hit rates and promotional effectiveness.  In addition, this targeted approach can minimize the disturbance to customers.  Firms also send messages only to those who are qualified for the offer.  This would minimize the customers’ disappointments when they receive an offer and find out that they are not simply qualified for the offer.  This will also save the cost of sending the offer to unqualified customers.  The use of customer analytics and insights provide a win-win promotional strategy.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Integrative Marketing Communication")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The integrative marketing communication (IMC) efforts are directly linked to various touchpoints or channels utilized by marketing campaigns.  Touchpoints include traditional touchpoints such as television and newspaper, online touchpoints such as websites, and social media touchpoints such as Twitter and other social network services.  In understanding the ongoing customer interactions and marketing communications, it is important to evaluate the nature of interaction and the type of messages exchanged in the interaction process.  In the traditional touchpoints, the interaction is characterized as primarily direct from and controlled by the marketer.  The main component is the marketer-generated contents in the form of advertising and publicity.  Traditional word of mouth (WOM) communication enters in this context.  The traditional WOM communication involves inter-consumer communications pertaining to the organic exchange of product and brand-related marketing messages with or without direct influence by marketers through traditional means such as advertising and promotion.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Online Touchpoints")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("For the online touchpoints, the interaction is mixed and less controllable by marketers.  Along with marketer generated contents and traditional WOM communication, online touchpoint interaction generates e-WOM communication that includes online product evaluations and comments by marketing firms and customers.  For the social media touchpoints, the nature of interaction is completely different.  The interaction can be characterized as primarily indirect and uncontrollable by the marketing manager.  The message and contents are also becoming more diverse.  In addition to the firm-generated content, traditional WOM, and e-WOM, user-generated content in the form of comments, blog postings, and video are increasingly dominant and important.  These new user-generated contents offer an opportunity for firms as they provide a new source of information and an avenue of interacting with customers.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Direct Causes")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers are facing a significant challenge of finding direct causes of sales increase.  It is a difficult task to isolate the effect of any specific marketing activity on brand, customer, and sales.  It is a difficult task of identifying the influence of specific marketing action on customer behavior.  One of the specific actions that has received significant attention is promotional campaign effect.  Promotional campaign can be a component of integrated marketing communication and can be done through various promotional mode including traditional media of newspaper, T.V., and digital media of web, social media, and mobile.  Regardless of the media used by firms, marketing managers need to evaluate campaign effectiveness.  Analytic questions that marketing managers can generate depend on the promotional context and level.  These analytic questions include the effectiveness of whole promotional campaign, specific advertising, or different advertising copy.  At each customer level, analytic question can be whether to send a promotional message to a particular customer, and which message to be sent if managers decide to send a message to that customer.  In addition, they would ask which customers a firm should not send the message as that customer would purchase our product anyway.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Tool")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("To answer the analytic questions of understanding, what is the impact of promotional campaign and advertising on sales, brand and customers, managers need to choose the right analytic tool from the analytic toolbox.  The analytic tool selected is A/B testing with uplift modeling.  A/B testing refers to standard scientific experiment conducted to track responses of participants.  Experiment allows managers to evaluate the direct cause of customer responses and product sales.  Managers need to design an experiment that will provide accurate results.  The next section describes fundamentals of experimental design.\n").padding(10)
                    } // Section 7
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("10.1 Integrative Marketing Communication Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
