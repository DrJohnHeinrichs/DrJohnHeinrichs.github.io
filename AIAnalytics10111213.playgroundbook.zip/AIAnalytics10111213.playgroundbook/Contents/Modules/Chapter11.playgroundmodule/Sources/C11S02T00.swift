//
//  C11S02T00.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 2: Text Mining Analytics Generation
//
//  Created by SBAMBP on 04/26/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S02T00: View {
    var topicTitle: String = "Topic Title"

    @State private var showingFigure111Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Tools")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("With the identified analytic task and analytic questions, managers need to select the right analytic tool from the toolbox.  Text analytics called text mining is used for processing the unstructured text data.  These text analytic tools exist in the form of commercial analytic software, freeware, or AI firms such as IBM Watson or Google Analytics.  Regardless of the software selection, the appropriate text analytic steps are required.  The selection of the appropriate text analytic steps depends on the analytic objectives and analytic questions developed by managers.  Text analytics is turning unstructured text data into actual information.  Text analytics covers information retrieval and extractions as well as data and web mining and supported by two primary technologies of Natural Language Processing (NLP) and machine learning using artificial intelligence (AI) system.  Natural language processing builds on artificial intelligence (AI) and computational linguistics.  It focuses on transforming the natural human language into more formal form of numeric and symbolic data for analysis.  Its objective is to understand and process natural language considering both grammatical semantics and the context.  NLP can perform many different tasks that include question answering, natural language generation and understanding speech recognition.  NLP enables generation of formalized data that can be used by data mining tools for knowledge discovery.  The formalized data can be used for information extraction, topic tracking, categorization, and clustering.\n").padding(10)
                            Text("In order to use text analytics, managers need to follow several steps.  The steps are presented in Figure 11-1.").padding(10)
                    } // Section 1
                    // ----------------------
                    Section(header: Text("Figure 11-1: Text Analytics Steps")) {
                        Image(uiImage: UIImage(named: "Figure-11-1.jpg")!)
//                        Image(name: "Figure-11-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        // ----------------------
                        Button("Click for ... Figure 11-1: Text Analytics Steps") {
                            self.showingFigure111Sheet1.toggle()
                        } // button
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure111Sheet1) {
                            Figure111View1()
                        } // sheet
                    } // Section 2
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.2 Text Mining Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 11-1 VIEW
// ------------------------------
struct Figure111View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 11-1: Text Analytics Steps")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-11-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 11-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// ------------------------------
