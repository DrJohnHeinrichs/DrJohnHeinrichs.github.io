//
//  C11S02T02.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 2: Text Mining Analytics Generation
//  Topic 2: Customer Feedback Categorization and Topic Modeling
//
//  Created by SBAMBP on 04/26/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S02T02: View {
    var topicTitle: String = "Topic Title"
    
    @State private var showingTable111Sheet1 = false
    @State private var showingTable112Sheet1 = false
    @State private var showingTable113Sheet1 = false
    @State private var showingTable114Sheet1 = false
    @State private var showingTable115Sheet1 = false
    @State private var showingTable116Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0
    @GestureState var scale5: CGFloat = 1.0
    @GestureState var scale6: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Customer Feedback Categorization and Topic Modeling
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.2.2 Customer Feedback Categorization and Topic Modeling").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Matrices")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In categorizing customer feedback, managers need to take the word-count approach.  With pre-processing, the structured data matrix can be generated.  They are Term-by Document Matrices (TDM) and Term Frequency-Inverse Document Frequency (TF-IDF) matrix.  Term-by Document matrix is the data matrix with tokens (terms) in the column headers and rows of presence or absence (0 or 1) or frequency (1, 2, ..., etc.).  Table 11-1 shows a TDM with presence or absence and Table 11-2 shows a TDM with term frequency.  TF-IDF is the data matrix with tokens (terms) in the column headers and rows of TF x IDF values.  TF is the number of times the term appears in a document.  IDF is the log of the inverse of the frequency with which documents have that term.  In the TF-IDF matrix, documents that have frequent occurrences of rare terms will show high values.  Occurrences of terms that are absent from most documents or present in most documents are regarded as less important and given little value.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section(header: Text("Table 11-1: Term Document Matrix (TDM) with Presence or Absence")) {
                        Image(uiImage: UIImage(named: "Table-11-1.jpg")!)
//                        Image(name: "Table-11-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-1: Term Document Matrix (TDM) with Presence or Absence") {
                            self.showingTable111Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable111Sheet1) {
                            Table111View1()
                        }
                    } // Section 2
                    // ----------------------
                    Section(header: Text("Table 11-2: Term Document Matrix (TDM) with Term Frequency")) {
                        Image(uiImage: UIImage(named: "Table-11-2.jpg")!)
//                        Image(name: "Table-11-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-2: Term Document Matrix (TDM) with Term Frequency") {
                            self.showingTable112Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable112Sheet1) {
                            Table112View1()
                        }
                    } // Section 3
                    // ----------------------
                    Section(header: Text("Table 11-3: TF (Term Frequency) – IDF (Inverse Document Frequency) Matrix")) {
                        Text("Table 11-3 shows an example of TF-IDF matrix.  This TF-IDF matrix is subjected to clustering analysis to categorize the input documents.\n").padding(10)
                        Image(uiImage: UIImage(named: "Table-11-3.jpg")!)
//                        Image(name: "Table-11-3.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale3, body: { (value, scale3, trans) in
                                scale3 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-3: TF (Term Frequency) – IDF (Inverse Document Frequency) Matrix") {
                            self.showingTable113Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable113Sheet1) {
                            Table113View1()
                        }
                    } // Section 4
                    // ----------------------
                    Section(header: Text("Table 11-4: Cluster Centers / Table 11-4: Inter-cluster Distances / Table 11 6: Cluster Summary")) {
                        Text("An example of the clustering analysis results is presented in Table 11-4 through Table 11-6.\n").padding(10)
                        Image(uiImage: UIImage(named: "Table-11-4.jpg")!)
//                        Image(name: "Table-11-4.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale4)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale4, body: { (value, scale4, trans) in
                                scale4 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-4: Cluster Centers") {
                            self.showingTable114Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable114Sheet1) {
                            Table114View1()
                        }
                        Image(uiImage: UIImage(named: "Table-11-5.jpg")!)
//                        Image(name: "Table-11-5.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale5)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale5, body: { (value, scale5, trans) in
                                scale5 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-5: Inter-cluster Distances") {
                            self.showingTable115Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable115Sheet1) {
                            Table115View1()
                        }
                        Image(uiImage: UIImage(named: "Table-11-6.jpg")!)
//                        Image(name: "Table-11-6.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale6)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale6, body: { (value, scale6, trans) in
                                scale6 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                        Button("Click for ... Table 11-6: Cluster Summary") {
                            self.showingTable116Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingTable116Sheet1) {
                            Table116View1()
                        }
                    } // Section 5
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.2 Text Mining Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 11-1 VIEW
// ------------------------------
struct Table111View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-1: Term Document Matrix (TDM) with Presence or Absence")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-2 VIEW
// ------------------------------
struct Table112View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-2: Term Document Matrix (TDM) with Term Frequency")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-3 VIEW
// ------------------------------
struct Table113View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-3: TF (Term Frequency) – IDF (Inverse Document Frequency) Matrix")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-4 VIEW
// ------------------------------
struct Table114View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-4: Cluster Centers")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-5 VIEW
// ------------------------------
struct Table115View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-5: Inter-cluster Distances")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-6 VIEW
// ------------------------------
struct Table116View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-6: Cluster Summary")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// ------------------------------
