//
//  C11S03T00.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 3: Text Mining Analytics Interpretation and Application
//
//  Created by SBAMBP on 04/26/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S03T00: View {
    var topicTitle: String = "Topic Title"

    @State private var showingTable117Sheet1 = false
    @State private var showingTable118Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.3.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Customer Sentiment")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Whether marketing managers decide to use lexicons or training documents in text analysis, they need to identify customer sentiment of documents.  The most basic list-based sentiment measure example is shown in Table 11-7.  This table is generated using a lexicon of words listed as positive and negative in a specific domain.  Managers can also create manually a list of words with positive sentiments and negative sentiments.\n").padding(10)
                    } // Section 1
                // ----------------------
                Section(header: Text("Table 11-7: List of Sentiment Measure")) {
                    // ----------------------
                    Image(uiImage: UIImage(named: "Table-11-7.jpg")!)
//                    Image(name: "Table-11-7.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale1)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale1, body: { (value, scale1, trans) in
                            scale1 = value.magnitude
                            })
                        )
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    // ----------------------
                    // ----------------------
                    Button("Click for ... Table 11-7: List of Sentiment Measure") {
                        self.showingTable117Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingTable117Sheet1) {
                        Table117View1()
                    }
                } // Section 2
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Opinion Strength")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("With the sentiment measures and customer feedback documents, managers can understand how many customers have positive and negative opinions and their level of opinion strength.  When dealing with large number of documents to evaluate the accuracy of sentiment classification, the input data are divided into the training set and the testing set.  The training set is used to develop the classification model and the testing set is used to evaluate the model accuracy.  Confusion matrix for the testing set is used to evaluate the classification accuracy.  Table 11-8 shows an example of confusion matrix.  For further analysis, precision and recall can be calculated.  Precision is 0.804 (250 / (250 + 61)) and recall is 0.947 (250 / (250+14)).  Precision and recall are important indicators of classification accuracy and relevance of results obtained from sentiment analysis of text documents.\n").padding(10)
                } // Section 3
                // ----------------------
                Section(header: Text("Table 11-8: Confusion Matrix")) {
                    // ----------------------
                    Image(uiImage: UIImage(named: "Table-11-8.jpg")!)
//                    Image(name: "Table-11-8.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale2)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale2, body: { (value, scale2, trans) in
                            scale2 = value.magnitude
                            })
                        )
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    // ----------------------
                    // ----------------------
                    Button("Click for ... Table 11-8: Confusion Matrix") {
                        self.showingTable118Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingTable118Sheet1) {
                        Table118View1()
                    }
                } // Section 4
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.3 Text Mining Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 11-7 VIEW
// ------------------------------
struct Table117View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-7: List of Sentiment Measure")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-7.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 11-7 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 11-8 VIEW
// ------------------------------
struct Table118View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 11-8: Confusion Matrix")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-11-8.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 11-8 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// ------------------------------
