//
//  C11S01T00.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 1: Post-Purchase Behavior Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The customer is the reason for business; they are the most important individual in any business; they are the purpose of work.  Customers are flesh-and-blood human beings with desires, feelings, and emotions.  They come to firms with their needs and wants and they deserve to be treated in the most courteous and attentive manner that the firm can provide.  They are not a statistic or a non-entity, for if the customer is not satisfied, the rest of the firm’s performance is moot.  Determining what customer satisfaction is, understanding why it is important, and, ultimately, how to measure it, can be a daunting task.  Yet, firms can develop a competitive advantage by understanding customer needs and providing value-added products and service to meet the identified needs.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Although the concept of customer satisfaction is fundamental, it has been the subject of considerable debate and controversy in the marketing literature.  Customer satisfaction has evolved from being defined as simply an attitude to a multifaceted concept of expectation and perception.  It must be remembered, however, that customer satisfaction involves both the customer of the product and/or service and the provider of that product and/or service.  Products speak louder than any other communication or advertising message and surveys have shown that a dissatisfied customer will tell up to seven other people of their problems and a dissatisfied customer is unlikely to purchase the product or service again.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Achieving customer delight is in the details of the product, business processes, and interaction with the employees.  It must be viewed as a long term, survival issue with the benefits associated with it occurring over time.  It is in demonstrating the importance of customer satisfaction and in listening to the customer and customer contact personnel.  It is in making the customer say “WOW!” that customer satisfaction is ultimately achieved.  Customer satisfaction must be performed in customer’s terms and must emphasize the intangible aspect.  This is a simple concept to highlight that customer satisfaction is a function of how well the firm delivers on its promises given the expectations that the customer has.  It is important to remember that customer satisfaction is not about achieving “happy scores”; it is about understanding wants and needs and exceeding customer expectations.  To completely understand the variety of customer wants and needs, it is important to measure everyone’s satisfaction in the value chain – all direct and indirect customers – and all members of the distribution channel – dealers, retailers, and wholesalers.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers need to understand how customers are expressing their opinions after product purchase and know the level of satisfaction the customers have.  In the past, customer satisfaction measures were obtained by structured survey.  With the emergence of social media and blog sites, customers are expressing their feelings through these digital information sites.  The digital information are text data and provide valuable information and insight for marketing managers.  The big data generated through online website as well as social media sites contain a large amount of text data.  The objective of this type of analytics is to understand the frequency and sentiment of these text postings.  The key questions marketing managers have are: Who are generating these online postings? What types of postings are generated by whom? Which social media platforms are generating what type of postings? All these questions can be answered by performing text analysis.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("A")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Increasingly, marketing managers have to deal with unstructured data as a part of big data firms are gathering and analyzing.  Unstructured data can be in many forms such as text, audio, and video.  Among these sources, text comprises the largest amounts of unstructured data.  Most common text data are customer feedback provided as their post-purchase behavior.  The traditional sources are responses in survey, focus group transcripts, customer complaints received in call center and customer service operations or emails received from customers.  Recently, text data are obtained from website, blog site, social media platforms such as Twitter or Facebook.  Customers are also providing text data through various communities where interactions among participants are exchanging opinions and information.  Firms are encouraging their customers to engage with various touchpoints of the firm to provide product or service feedback in their own words.  Managers are facing the task of processing unstructured text and derive meaningful insights for better decision making.  When marketing managers receive the large amount of text-based feedback from their customers, they need to figure out what customers are talking about and whether their feedback is positive or negative.  Managers have to answer the analytic questions such as what are the main themes or issues discussed in customers’ complaints or praises and how often these complaints or praises are made for which products or services.  In addition, managers need to evaluated the nature of sentiment and understand the degree of positive or negative comments and responses.  Firms need to effectively utilize text data sources to generate the necessary knowledge to make better decisions.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.1 Post-Purchase Behavior Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
