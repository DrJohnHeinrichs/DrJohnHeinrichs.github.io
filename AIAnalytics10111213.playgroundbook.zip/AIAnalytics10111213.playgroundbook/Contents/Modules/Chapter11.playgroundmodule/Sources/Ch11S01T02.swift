//
//  Chapter 11: Section 01: Topic 02: Customer Delight
//
import SwiftUI

public struct Ch11S01T02: View {
    var topicTitle: String = "Topic Title"
    @State public var promoters: Int = 0
    @State public var passive: Int = 0
    @State public var detractors: Int = 0
    var totalNPS: Double {
        let totalNPS = Double(promoters) + Double(passive) + Double(detractors)
        return totalNPS
    }
    var netPromoterScore: Double {
        let netPromoterScore = ((Double(promoters) / totalNPS) - (Double(detractors) / totalNPS)) * 100
        if netPromoterScore >= 0 {
            return netPromoterScore
        } else {
            return 0
        }
    } // var
    
    public init(topicTitle: String) {
        self.topicTitle = topicTitle
        promoters = 0
        passive = 0
        detractors = 0
    }
    
    public var body: some View {
        // ----------------------
        // TOPIC 2: Start
        // ----------------------
        NavigationView {
            List {
                Section(header: Text("Net Promoter Score")){
                    Text("Consider surveying existing customers.  Using a 1-10 scale, ask them to rate 'How likely would you be to recommend our product or service to a friend or colleague'.\n")
                    VStack{
                        HStack{
                            Stepper(value: $promoters, in: 0 ... 100) {
                                Text("Promoters (9&10) ... \(promoters)")
                            } // Stepper
                        } // HStack - Promoters
                        HStack{
                            Stepper(value: $passive, in: 0 ... 100) {
                                Text("Passive (7&8) ... \(passive)")
                            } // Stepper
                        } // HStack - Passive
                        HStack{
                            Stepper(value: $detractors, in: 0 ... 100) {
                                Text("Detractors (1&6) ... \(detractors)")
                            } // Stepper
                        } // HStack - Detractors
                        HStack{
                            Text("NPS Score ... \(netPromoterScore, specifier: "%.2f")")
                        } // HStack - NPS Score
                    } // VStack NPS
                    .padding(.bottom, 30)
                } // Section - NPS
    //            .listRowBackground(Color(UIColor(red: 0.9804, green: 0.9216, blue: 0.9000, alpha: 0.2000)))
            } // List -- text
            .padding(30)
            .font(.system(size: 22))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
         //   .background(Color(UIColor(red: 0.9804, green: 0.9216, blue: 0.0000, alpha: 0.4000)))
            .navigationBarTitle("11.1 Post-Purchase Behavior Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ---------------------
        // TOPIC 2: End
        // ----------------------
    } // body
} // struct
