//
//  C11S02T03.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 2: Text Mining Analytics Generation
//  Topic 3: Sentiment Analysis
//
//  Created by SBAMBP on 04/26/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S02T03: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 3: Start --- Sentiment Analysis 
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.2.3 Sentiment Analysis").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Questions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Sentiment analysis is performed when managers have analytic question of what do customers feel about our product or service.  Other analytic questions are related to understanding customer complaints and praises, knowing what customers say about our firm and competitors, customers' posts on social media, their opinion about e-commerce sites and digital advertising, etc.  Sentiment analysis can provide analytic solutions by assessing favorable and unfavorable feelings or opinions toward specific products or services.  With increased textual data sources of customer feedback, text analytics becomes a critical business analytics tool for marketers.  The textual data sources include web posting, call center scripts, tweets, and blog posts.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Positive and Negative Classes")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Sentiment analysis involves identifying positive and negative classes, strength of opinion, and level of polarity.  This sentiment classification focused on sentiment toward products, services, brands, and firms.  Sentiment expressed in customer feedback text can be either explicit or implicit.  Explicit sentiment is an opinion expressed directly while implicit sentiment is when the text implies an opinion.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Evaluate Documents")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("After the text editing and pre-processing, the customer feedback documents need to be evaluated whether the documents contain opinions rather than facts.  This evaluation of text objectivity leads to numerical value called objectivity-subjectivity polarity that ranges from 0 to 1 where the value close to 1 is considered as objective meaning facts.  In this case, no sentiment analysis is needed for the particular customer feedback document.  Then, the analysis proceeds to the next document.  Only non-fact opinion containing documents are subjected to sentiment analysis.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Classify Opinions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("With opinion containing documents, sentiment analysis is performed to classify opinions as positive or negative.  The sentiment polarity can be viewed as a binary or a positive on the continuum between two positive and negative polarities.  In addition to polarity classification, managers would be interested in the strength of the sentiment.  The most important task in sentiment analysis is identifying polarity of a text.  Polarity identification can be done using two dominant methods of using a lexicon as a reference library and using a collection of training documents as a source of domain specific term polarity.  One method is using a lexicon.  A lexicon is the catalog of words, their synonyms, and meanings for a given language.  There exist general purpose lexicons such as WordNet and a variety of special lexicons.  The other method is using a collection of training documents.  This method utilizes existing document resources such as Amazon, IBM Watson, Rotten Tomatoes, etc. developed using statistical analysis and AI driven machine learning tools.  Managers can use a variety of predictive modeling and machine-learning algorithms to evaluate the customer feedback documents or other new documents for their negative-positive polarity and strength of opinions.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.2 Text Mining Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 3: End
        // ------------------------------
    } // body
} // struct
