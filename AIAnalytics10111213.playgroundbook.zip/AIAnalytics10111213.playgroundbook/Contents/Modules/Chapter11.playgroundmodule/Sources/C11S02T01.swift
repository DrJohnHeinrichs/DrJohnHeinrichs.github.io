//
//  C11S02T01.swift
//  Book_Sources
//
//  Chapter 11: Text Mining Tools for Post-Purchase Behavior Analytics
//  Section 2: Text Mining Analytics Generation
//  Topic 1: Text Analytics Approaches
//
//  Created by SBAMBP on 04/26/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C11S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Text Analytics Approaches
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("11.2.1 Text Analytics Approaches").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Choices")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Considering the analytic task and analytic question, managers can choose one of the two text analytics approaches.  The two text approaches are word count-based approach and dictionary-based approach.\n").padding(10)
                        Text("Word count-based approach can be used when managers are interested in identifying the key theme, topic, or concepts expressed in the customers’ feedback, complaints, or Twitter posts.  Managers are also interested in the relative salience of different themes or concepts expressed by customers or participants.  This approach calculates basic word frequency statistics that include a list of words that appears in the customers’ post, their frequency counts, and the relative frequency calculated by dividing the frequency by total word count.  This approach also graphically represents word frequency with images that shows the frequency with which words appear in a customer’s feedback post.  This image is called word clouds that provide a quick view of relative word frequency or importance.  Another form of frequency count is word concordance which represents counts of the co-occurrence of word pairs.  Word concordance indicates semantic proximity of word pairs contextualizing the concepts.\n").padding(10)
                        Text("Dictionary-based approach is appropriate when analytic question is related to understanding, feelings, emotions, and motives of customer responses.  When marketing managers are interested in evaluating sentiment of customers, dictionary-based approach needs to be utilized.  Dictionary-based approach analyzes text based on a dictionary that is a set of concepts or categories of the specific words.  Dictionary-based is also called lexicons that are pre-defined in software or can be customized by users.  Dictionary approach calculates aggregated counts matching each dictionary category in the text.  The pre-defined software dictionaries contain typically two categories of words that are functional words category and sentiment -related word category.  Functional category allows marketing managers evaluated a customer's identity, status, and social hierarchy.  Sentiment related word category provides information about the opinions and affect expressed in a text by customers.  This approach can capture positive and negative emotion as well as motives of customers.  After selection the text analytics approach, next step is preparing input text data.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Text("Unstructured Input Data").fontWeight(.black).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    Section (header: HStack {
                        Text(" ")
                        } )
                        {
                        // ----------------------
                        Text("In this process, managers need to identify and compile the unstructured input text data.  As indicated earlier, the input text data can be obtained from internal or external sources such as social media sites.  The unstructured input text data is the initial text corpus in natural language.  Unstructured data is stored in the form of textual document for humans to process and understand.  In text analytics, initial text corpus needs to be edited for input.  One customer’s response or feedback becomes a document.  A document can be a separated text file or row of the excel file that contains all customers' response.  For example, if managers obtain 10,000 Twitter posts for text analysis, these 10,000 posts can be converted to 10,000 text files for software input.  Alternatively, these 10,000 posts become 10,000 rows of a single excel file for input data for text analysis.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Text("Input Text Editing and Preprocessing").fontWeight(.black).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    Section (header: HStack {
                        Text(" ")
                        } )
                        {
                        // ----------------------
                        Text("With the input text file or excel file, text preparation and pre-processing should be performed.  To generate text analytics, the unstructured text must be structured such that computers can understand them.  Using bag of words method and natural language processing, the original texts of corpus are transformed to some form of indices, matrices, or keys that can be processed by computer.  In this conversion process, text pre-processing can occur.  This pre-processing is done by managers using computer software.  In order to perform and understand text analytics, managers need to be familiarized with the common words used in text analysis.  A term refers to a single word or multi-word phrase taken from the corpus of the input documents.  Concepts are features or attributes of higher level of abstraction derived from categorization of the input documents.  These concepts can be generated manually, statistically, or using rules.  The pre-processing involves reducing common unstructured document to more structural set of data by elimination terms that are no use and simply add volume.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Text("Text Reduction").fontWeight(.black).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                        Image(systemName: "pencil")
                        Text(" ")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("A token (term) is a categorized block of text comprising the basic unit of analytics.  Tokenization is a process of converting a text into separate tokens or terms with assigned meaning.  These tokens become the column headers in the data matrix and are a useful part of the structured data.  The pre-processing can produce a matrix of a 0 or 1(absence or presence).  With pre-processed data, managers can proceed to generate the desired text analytics, or term frequency.  More detailed discussion will be provided in the next section.\n").padding(10)

                            VStack (alignment: .leading, spacing: 5) {
                                HStack {
                                Text("\u{2022} ")
                                Text("Stop Words: ").underline().bold().italic()
                                Text("Stop words are words occurring frequently that are removed before or after processing the input text.  Typical stops word list includes articles (the, of, a), auxiliary verbs (is, are, was), and other context-specific words.  Managers can customize the stop words list by adding or removing words.").padding(5)
                                } // HStack 1
                                HStack {
                                Text("\u{2022} ")
                                Text("Stemming:").underline().bold().italic()
                                Text("Stemming is reducing the variants of words to their stem (base or root) form or common core.").padding(5)
                                } // HStack 2
                                HStack {
                                Text("\u{2022} ")
                                Text("Synonyms and Polysemes: ").underline().bold().italic()
                                Text("Synonyms with identical or similar meanings can be consolidated.  Polysemes are words with different meanings.").padding(5)
                                } // HStack 3
                                HStack {
                                Text("\u{2022} ")
                                Text("Normalization:").underline().bold().italic()
                                Text("Normalization involves replacing a variety of specific terms in a category with the category name.").padding(5)
                                } // HStack 4
                                } // VStack
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Text("Tokenization").fontWeight(.black).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                        Text(" ")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Common words or less meaningful words can be removed from the input document.  This process of text reduction involves stop words, stemming, synonyms and polysemes, and normalization.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("11.2 Text Mining Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
