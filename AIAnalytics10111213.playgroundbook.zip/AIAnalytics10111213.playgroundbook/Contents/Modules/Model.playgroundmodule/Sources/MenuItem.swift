import UIKit
public let badImage = UIImage(systemName: "x.circle")

public func intFormat(value:Int,style:NumberFormatter.Style)->String {
    return NumberFormatter.localizedString(from: NSNumber(value: value), number: style)
}

public func dollarFormat(value:Double)->String{
    return NumberFormatter.localizedString(from: NSNumber(value: value), number: .currency)
}

public struct MenuItem:Codable,Identifiable {
    public var id: Int
    public var name:String
    public var description:String
    public var price:Double
    public init(id:Int,name:String,description:String,price:Double){
        self.id = id
        self.name = name
        self.description = description
        self.price = price
    }
     public init(id:Int){
        self.id = id
        self.name = intFormat(value: id, style: .spellOut)
        self.description = "Menu Item " + intFormat(value: id, style: .spellOut)
        self.price = 9.99
    }
    
}
