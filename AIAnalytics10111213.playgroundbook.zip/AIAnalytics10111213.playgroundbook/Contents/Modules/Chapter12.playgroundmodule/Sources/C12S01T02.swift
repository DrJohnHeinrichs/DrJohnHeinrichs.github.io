//
//  C12S01T02.swift
//  Chapter 12 Section 01: Topic 02: Website Clickstream Analytics Generation
//
//  Created by SBAMBP on 04/22/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C12S01T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable121Sheet1 = false
    @State private var showingTable122Sheet1 = false
    @State private var showingTable123Sheet1 = false
    @State private var showingFigure122Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start ---
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("12.1.2 Website Clickstream Analytics Generation").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Web Analytics")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Web analytics offers a viable method for evaluating marketing performance by assessing customer reactions, proving value, and predicting success.  Firms, then, should be using web analytics as a means to understand user behavior, which is constantly shifting.\n").padding(10)
                    Text("To generate web analytics for the firm, marketing managers need to capture the right type of clickstream data together with other related data.  The input data for clickstream analysis is clickstream data.  A clickstream is the path a user requests to get to a desired web page or information.  Clickstream data can determine the most popular links in a web page, how users navigate through website, the users’ sequence of visits to a website, and search patterns.").padding(10)
                Text("The input data for clickstream analysis is the website log information that contains data elements such as a date and time stamp, the visitor’s IP address, the referrer, the destination URLs of the pages visited, and a user ID that uniquely identifies the website visitor.  Marketing managers need to capture step-by-step a user’s web activity showing details on how each customer visited the website and what is clicked and what is not clicked.  The clickstream data may be in the firm’s data warehouse provided by external vendors or generated internally.  In many cases, these clickstream data are set up such that they are collected and stored consistently into a database.\n").padding(10)
                } // Section 1
                    // ----------------------
                    Section(header: Text("Table 12-1: Clickstream Data Example")) {
                        Image(uiImage: UIImage(named: "Table-12-1.jpg")!)
//                        Image(name: "Figure-12-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        Text("Before performing clickstream analysis, marketing managers need to combine clickstream data with other existing data sources if the user ID or other identifying attributes can be matched.  This data integration can provide more meaningful clickstream analytics rather than analyzing the clickstream data alone.  Clickstream data can have varying length for different session and users.  Marketing managers need to identify events or actions performed by the same user and group them together.  This process can be repeated further by identifying more detailed segments of events or actions.  These data processing results in the dataset include multiple sessions of a particular user.\n").padding(10)
                        // ----------------------
                        Button("Click for ... Table 12-1: Clickstream Data Example") {
                            self.showingTable121Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingTable121Sheet1) {
                            Table121View1()
                        }
                        // ----------------------
                        Text("Clickstream data contains the most common and useful event called a ‘click’ which indicates what the user has viewed.  Clickstream is a sequence of events that represents visitor actions or behavior on the website.  In addition, other information captured includes impressions, purchases, and any other events relevant to the marketing managers.  Good clickstream data defines a full set of events which allows managers to get a complete picture of customer behavior.  Traditionally, user events are collected using a JavaScript tracker that is loaded with the page on every request.  The tracker sends a request to a collector website which stores, validates, and enriches it with additional data, and sends it to the data warehouse.  Clickstream data can be collected through paid vendors, free vendors, self-hosted or managed sites.\n").padding(10)
                    } // Section 2
                // ----------------------
                Section(header: Text("Figure 12.2: Transition Diagram Example")) {
                    Image(uiImage: UIImage(named: "Figure-12-2.jpg")!)
//                    Image(name: "Figure-12-2.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale2)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale2, body: { (value, scale2, trans) in
                            scale2 = value.magnitude
                            })
                        )
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                // ----------------------
                Text("Many different analytic tools can be used to analyze the captured clickstream data.  From the analytic toolbox, marketing managers can select analytic tools considering the analytic task to generate.  A Markov chain can be used to analyze the clickstream data.  Markov processes a stochastic process representing a transition diagram along with the corresponding probabilities.  For example, Figure 12-2 shows such a transition diagram.\n").padding(10)
                // ----------------------
                Button("Click for ... Figure 12-2: Transition Diagram Example") {
                    self.showingFigure122Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure122Sheet1) {
                        Figure122View1()
                    }
                } // Section 3
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Markov Chain Model")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                    {
                // ----------------------
                Text("By fitting the Markov chain model, marketing managers can identify the start and end probabilities for a specific event.  With this type of clickstream analytics, marketing managers can predict the next click or final click of a user given the pattern that user followed up to that point.  Along with the click prediction, the probability of transition to the next stage can be calculated.  Marketing managers can predict the next behaviors based on those performed so far.  Another common analysis approach for clickstream data is clustering procedure.  As the user clickstream patterns vary widely and may be complex, a large number of clickstream data makes the analysis complicated and difficult.  Therefore, marketing managers need to perform cluster analysis to identify visitors with similar interests.\n").padding(10)
                Text("The sequence clustering mining model provides marketing managers with information regarding the cluster diagram, the cluster profile attributes, the cluster characteristics, the discrimination between various clusters, and the state transitions.  The cluster diagram graphically portrays the various clusters generated by the algorithm.  Marketing managers can examine a particular item and filter the node to determine which cluster has the greatest density of cases for that item.  The cluster profiles display the sequences of items that exist in each cluster and the overall distribution of items in that particular cluster.  The cluster characteristics describe the transitions between the various states located in that particular cluster.  The cluster discriminations compare two clusters.  The various states that favor one cluster over the other cluster are shown by a bar associated with the state.  Therefore, marketing managers can generate a profile of the various users associated with a particular cluster.  Finally, the state transitions describe the movement through the various states for a particular cluster.  Each state transition has a probability associated with it.  Therefore, marketing managers can develop a probabilistic movement pattern for a user as that user moves through the various states.\n").padding(10)
                    Text("Another analysis approach is identifying common pattern sequences of behaviors performed by the users.  For extracted pattern sequences, a support level can be calculated.  This support level is the concept used in the affinity analysis discussed earlier in Chapter 8.  The support level is between 0 and 1 where 1 indicates the identified sequence occurs in 100% of the clickstreams.  This analysis provides marketing managers the frequent sequential patterns of clickstream of the users.\n").padding(10)
                    Text("Many different analyses can be performed using clickstream data.  Traffic analysis shows where a website is getting its traffic.  Traffic analysis also provides marketing managers with which keywords are most popular, the different conversion rate from various traffic sources, or which marketing campaign brought in the most traffic.  Sales funnel analysis shows marketing managers how well the website is working for converting visitors into sales.  Clickstream analytics can provide a drop off percentage in each stage of sales funnel.  Clickstream analysis provides information on shopping cart abandonment and recovery information for the e-commerce site.  \n").padding(10)
                    } // Section 3
                // ----------------------
                // ----------------------
                Section(header: Text("Table 12-2: Terms Used in Clickstream Analysis")) {
                    Text("The clickstream analysis results can generate information about the user’s website click actions and behaviors.  In understanding the website behavior patterns, marketing managers need to be familiarized with various terms used to describe the user’s click behavior.  Table 12-2 describes the unique terms used to identify the user’s web click behavior.\n").padding(10)
                    // ----------------------
                    Image(uiImage: UIImage(named: "Table-12-2.jpg")!)
//                    Image(name: "Table-12-2.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale3)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale3, body: { (value, scale3, trans) in
                            scale3 = value.magnitude
                            })
                        )
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    // ----------------------
                    Button("Click for ... Table 12-2: Terms Used in Clickstream Analysis") {
                        self.showingTable122Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingTable122Sheet1) {
                        Table122View1()
                    }
                } // Section 4
                // ----------------------
                // ----------------------
                Section(header: Text("Table 12-3: Terms to Describe the User’s Click Behavior")) {
                    Text("The terms listed in Table 12-3 are commonly used in assessing web usage in general clickstream analysis.\n").padding(10)
                    // ----------------------
                    Image(uiImage: UIImage(named: "Table-12-3.jpg")!)
//                    Image(name: "Table-12-3.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale4)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale4, body: { (value, scale4, trans) in
                            scale4 = value.magnitude
                            })
                        )
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    // ----------------------
                    Button("Click for ... Table 12-3: Terms to Describe the User’s Click Behavior") {
                        self.showingTable123Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingTable123Sheet1) {
                        Table123View1()
                    }
                } // Section 5
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("User's Click Behavior")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                    {
                // ----------------------
                Text("The next section describes various metrics used to describe the user’s click behavior.  The “average visit duration” is a metric that marketers commonly use to gauge visitor engagement.  However, online visitors may spend extended periods of time on a website not because they are engaged by the content, but because they are unable to find what they are looking for.  Other important metrics include unique visitors, page views, visits, return visits, time on site, bounce rate, referrers and referring domains, search engine keywords, and geographic location.  Note that a visitor can have multiple visits to a website.  During a visit, the visitor can view multiple pages.  On a subsequent visit, the visitor may view pages previously viewed.  A page view is incremented each time a user visiting the website views a page.  Page views can be used to see recent traffic patterns and is helpful in measuring visits to promotional, sign-up, or order pages.  So, the metrics of visitors, visits, and page views are related. \n").padding(10)
                Text("Additional metrics used by firms include revenue per visit rates and customer profitability.  Revenue-per-visit refers to the financial outcome of each unique website visit.  Conversion rates refer to the number of online visitors who perform an intended action.  Click through rate is the number of users clicking on a link out of the total number who see the link (calculated as a percentage).  It is particularly useful in measuring the success of an online advertising campaign.  Clickstream data tells you where users are clicking (or going to) immediately before, during and after leaving the website.  This is useful in determining visitor behavior and optimizing the website’s content to improve the conversion rate.\n").padding(10)
                } // Section 6
                // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("12.1 Websites Clickstream Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 12-1 VIEW
// ------------------------------
struct Table121View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-1: Clickstream Data Example")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-12-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 12-2 VIEW
// ------------------------------
struct Table122View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-2: Terms Used in Clickstream Analysis")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-12-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 12-3 VIEW
// ------------------------------
struct Table123View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 12-3: Terms to Describe the User’s Click Behavior")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 12-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-2 VIEW
// ------------------------------
struct Figure122View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-2: Transition Diagram Example")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
