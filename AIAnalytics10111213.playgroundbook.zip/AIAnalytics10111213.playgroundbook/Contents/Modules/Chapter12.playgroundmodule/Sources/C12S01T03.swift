//
//  C12S01T03.swift
//  Book_Sources
//
//  Chapter 12 Section 01: Topic 03: Website Clickstream Analytics Interpretation and Application
//
//  Created by SBAMBP on 04/23/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C12S01T03: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure123Sheet1 = false
    @State private var showingFigure124Sheet1 = false
    @State private var showingFigure125Sheet1 = false
    @State private var showingFigure126Sheet1 = false
    @State private var showingFigure127Sheet1 = false
    @State private var showingFigure128Sheet1 = false
    @State private var showingFigure129Sheet1 = false
    @State private var showingFigure1210Sheet1 = false
    @State private var showingFigure1211Sheet1 = false
    @State private var showingFigure1212Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0
    @GestureState var scale4: CGFloat = 1.0
    @GestureState var scale5: CGFloat = 1.0
    @GestureState var scale6: CGFloat = 1.0
    @GestureState var scale7: CGFloat = 1.0
    @GestureState var scale8: CGFloat = 1.0
    @GestureState var scale9: CGFloat = 1.0
    @GestureState var scale10: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start ---
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("12.1.3 Website Clickstream Analytics Interpretation and Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    // ----------------------
                    Section(header: Text("Figure 12-3: Generated Insights")) {
                        Text("After the data-mining model is created, processed, and understood, marketing managers can view the results.  Many software tools can analyze clickstream data and generate reports for the marketing managers.  The analytic tools can generate reports using the web logs as well as other related information such as transaction, campaign, user, and catalog data stored in the firm’s data warehouse.  These reports can contain general statistics of web activities or special statistics focusing on a certain web page or product-related activities as well as user activity on the firm’s website.  Marketing managers can then analyze specific information regarding registered users and can analyze user behavior during their visits or assess which links they followed.  The insights generated can be used to make more informed decisions regarding the pricing of products and services, marketing strategy, as well as promotion and advertising location and timing.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-3.jpg")!)
//                        Image(name: "Figure-12-3.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                    // ----------------------
                    // ----------------------
                    Button("Click for ... Figure 12-3: Generated Insights") {
                        self.showingFigure123Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure123Sheet1) {
                        Figure123View1()
                    }
                    } // Section 1
                    // ----------------------
                    Section(header: Text("Figure 12-4: An Example of Advertising Click-Through Rate Report")) {
                        Text("The advertising reports used by marketing managers can include analytics related to advertisement placement, advertisement reach and frequency per day, per campaign item, and per campaign, as well as campaign item summary, and campaign event summary information.  From this information, marketing managers can generate insights such as the effectiveness of the advertising campaign at the program and item level.  Marketing managers can assess which advertisement items and campaign programs are most effective.  These insights generated from the analytics solutions can be applied to various management decisions.  For example, if the analytics shows a successful early spring advertising campaign for the younger market segments, the firm can develop additional campaign items for the spring season the following year.  The organization can add additional items that appeal to this identified younger market segment with the goal of increasing revenue.  These insights can also be applied to developing campaign item pricing and customizing advertising content and product items for the identified target market segments.  Figure 12-4 shows the advertising click through rate analytics report.  This report shows which digital advertising generates clicks.  Advertising clicks are the number of the ad was clicked on by a visitor.  The report shows the click through rate that is the percentage of ads that were clicked on.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-4.jpg")!)
//                        Image(name: "Figure-12-4.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-4: An Example of Advertising Click-Through Rate Report") {
                            self.showingFigure124Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure124Sheet1) {
                            Figure124View1()
                        }
                    } // Section 2
                    // ----------------------
                    Section(header: Text("Figure 12-5: An Example of Advertising View Report")) {
                        Text("Figure 12-5 shows the ad views for the ads run by the firm.  This report shows the number of times the specified ad was displayed on a page viewed by a visitor.  Marketing managers can get information on how often specific ads were viewed by visitors.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-5.jpg")!)
//                        Image(name: "Figure-12-5.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale3, body: { (value, scale3, trans) in
                                scale3 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-5: An Example of Advertising View Report") {
                            self.showingFigure125Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure125Sheet1) {
                            Figure125View1()
                        }
                    } // Section 3
                    // ----------------------
                    Section(header: Text("Figure 12-6: An Example of Shopping Event Report")) {
                        Text("Product sales analytic reports show product sales data.  These analytics reports include patterns, graphs, and charts showing buyer browse-to-purchase, customer sales, customer spending summary, order events, product sales, and shopping basket events.  These analytics reports are useful for assessing sales and transaction performance.  From this information, diverse insights can be generated such as who are the e-customers and what products they purchase.  The sales pattern by customer segments can be valuable insights in developing product assortment decision as well as e-store front redesign decision.  These insights can be applied to other e-business decision areas as well.  Figure 12-6 shows the number of shopping basket events by product line over time.  Marketing managers can evaluate which products visitors are putting into shopping basket.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-6.jpg")!)
//                        Image(name: "Figure-12-6.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale4)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale4, body: { (value, scale4, trans) in
                                scale4 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-6: An Example of Shopping Event Report") {
                            self.showingFigure126Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure126Sheet1) {
                            Figure126View1()
                        }
                    } // Section 4
                    // ----------------------
                    Section(header: Text("Figure 12-7: An Example of Top Pages by Views Report")) {
                        Text("Web usage reports provide information to facilitate an assessment of the firm’s website usage, referring URLs, requests for data, and other website related data.  These reports include analytics outputs showing entry path analysis, top referring domains by request, top requested pages, usage summary by day of week, hour of day, week of year, usage trends, and visits by browser, version, and operating system.  These reports facilitate insight generation related to usability, quality, and effectiveness of a firm’s website.  The insights generated can be used to change the web link, redesign the website map, redefine the entering page, and improve the content.  Additionally, they can be used to develop the most effective ways and places to attract new visitors.  Figure 12-7 identifies the most popular website pages.  It shows marketing managers how often the popular web pages are viewed and the average length of time the page is viewed.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-7.jpg")!)
//                        Image(name: "Figure-12-7.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale5)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale5, body: { (value, scale5, trans) in
                                scale5 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-7: An Example of Shopping Event Report") {
                            self.showingFigure127Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure127Sheet1) {
                            Figure127View1()
                        }
                    } // Section 5
                    // ----------------------
                    Section(header: Text("Figure 12-8: An Example of Visits by Day of the Week Report ")) {
                        Text("Figure 12-8 shows the activity for each day of the week within the reporting period.  Unsuccessful hits are not included.  Days of less activity should be considered good days for maintenance and content improvement.\n").padding(10)
                        Text("User reports provide analytic solutions resulting from analysis of user data.  The user analytics shows patterns, charts, and models that are related to distinct users and visits by week, distinct users by day, new registered users, registered user properties, registered users by date registered, user days to register, user registration rate, and user trends.  The user analytics can offer insights regarding how users use the website and how many new and returning users are registered.  For example, user trend analytics can provide the ratio between new and returning visitors over a period of time.  This ratio can offer insight regarding how well and what type of returning visitors the organization’s website is attracting.  The generated insight can be applied to tailor the organization’s website to the interest and needs of the returning registered visitors.  The firm can also find out what the returning visitors like and why visitors are not returning to the site.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-8.jpg")!)
//                        Image(name: "Figure-12-8.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale6)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale6, body: { (value, scale6, trans) in
                                scale6 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-8: An Example of Visits by Day of the Week Report ") {
                            self.showingFigure128Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure128Sheet1) {
                            Figure128View1()
                        }
                    } // Section 6
                    // ----------------------
                    Section(header: Text("Figure 12-9: An Example of Visits by Day of the Week Report ")) {
                        Text("Figure 12-9 shows the number of first time and returning visitors to your site.  Only visitors identified by cookies are counted.  New visitors are those who didn't have a cookie from the firm’s site on their first hit, but had one on later hits.  Returning visitors are those who already had a cookie from your site when they visited.  A visit is a series of actions that begins when a visitor views their first page from the server, and ends when the visitor leaves the site or remains idle beyond the idle-time limit.  The default idle-time limit is thirty minutes.  This time limit can be changed by the system administrator.  By tracking the ratio between new and returning visitors over a period of time, you can determine if your site is attracting enough returning visitors.\n").padding(10)
                        Text("Visit reports generate analytics related to visit data.  The analytics provided in the visit reports shows how and where the website visitors are coming as well as when and where they exit the website.  The analytics includes patterns, charts, and patterns related to entry pages, exit pages, general activity statistics, and user visit trends.  Insights generated from using these analytics outputs are useful in understanding how well the website is perceived by visitors and their navigation patterns.  For example, top entry pages show where visitors are entering the website.  This information can be used to generate insights regarding how to optimize the architecture of the web site.  These insights can lead the web site revision decision such as external link determination and updating meta-tag and links.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-9.jpg")!)
//                        Image(name: "Figure-12-9.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale7)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale7, body: { (value, scale7, trans) in
                                scale7 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-9: An Example of New and Returning Visitors Report") {
                            self.showingFigure129Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure129Sheet1) {
                            Figure129View1()
                        }
                    } // Section 7
                    // ----------------------
                    Section(header: Text("Figure 12-10: An Example of Top Entry Pages by Visits Report")) {
                        Text("Figure 12-10 identifies the first page viewed when a visitor visits your site.  The most common entry page is usually the home page, but other common entry pages include specific URLs that visitors will type, pages that have been bookmarked, or pages referred to by other sites.  This information can indicate how you might want to optimize the architecture of the firm’s website based on where visitors are entering.  It can also help marketing managers determine which external links are most effective and help updating meta tags and links.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-10.jpg")!)
//                        Image(name: "Figure-12-10.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale8)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale8, body: { (value, scale8, trans) in
                                scale8 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-10: An Example of New and Returning Visitors Report") {
                            self.showingFigure1210Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure1210Sheet1) {
                            Figure1210View1()
                        }
                    } // Section 8
                    // ----------------------
                    Section(header: Text("Figure 12-11: An Example of Top Exit Pages by Visits Report")) {
                        Text("Figure 12-11 shows top exit pages by visits.  This figure identifies the last page visitors viewed before they left your site.  Exit page is the last page viewed during a visit to your website.  If a visit consists only of hits to non-page files, that visit has no exit page.  This can cause the total number of exit pages to be less than the total number of visits.  Marketing managers can use this information to determine your visitors’ satisfaction with their visits.  Visitors may have left this page because they found what they were looking for, lost interest, determined the content didn’t apply to them, or for many other reasons.  If your top exit page is your home page, this may be an indication that you are alienating a lot of first-time visitors.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-11.jpg")!)
//                        Image(name: "Figure-12-11.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale9)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale9, body: { (value, scale9, trans) in
                                scale9 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-11: An Example of New and Returning Visitors Report") {
                            self.showingFigure1211Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure1211Sheet1) {
                            Figure1211View1()
                        }
                        Text("Diagnostic reports use the reports analytics module to analyze diagnostic data.  The analytics assesses how well the website server satisfies the needs of visitors.  The analytics includes pattern analysis results regarding bandwidth summary, bandwidth trends, and hits by http status.  These analytics can be used to provide insights regarding server capacity and usage.  For example, the analytics provides information regarding the average time to serve dynamic pages and forms of the website by day.  This insight reveals how long the visitors in average have to wait to get web page response after they click.  If the average time to serve is too long, a firm may be losing potential visitors due to slow web response and wait time.  In this case, marketing managers might initiate the increase of bandwidth for peak time.\n").padding(10)
                        Text("Figure 12-12 shows the average time to serve documents analytics.  This analytics report displays the average amount of time it takes to serve pages classified as documents.  Marketing managers can consider increasing the available bandwidth if the times to serve spike at rates disproportionate to the number of documents served during the same time interval.  If marketing managers see this problem and have enough bandwidth, the firm’s server power may be a factor.\n").padding(10)
                        // ----------------------
                        Image(uiImage: UIImage(named: "Figure-12-12.jpg")!)
//                        Image(name: "Figure-12-12.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale10)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale10, body: { (value, scale10, trans) in
                                scale10 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        // ----------------------
                        // ----------------------
                        Button("Click for ... Figure 12-12: An Example of Average Time to Serve Documents Report") {
                            self.showingFigure1212Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure1212Sheet1) {
                            Figure1212View1()
                        }
                        VStack {
                        Text("Mobile Web Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                        Text("One of the most exciting opportunities for firms is the emergence of rich digital experiences through increasingly mobile devices.  Mobile web analytics refers to the use of data collected as visitors access a website from a mobile phone and provide information regarding the behavior of mobile website visitors.  Mobile analytics captures and report metrics that include page views, visits, visitors, countries, and information specific to mobile devices (e.g., device model, manufacturer, screen resolution, device capabilities, service provider, and preferred user language).  Mobile web analytics helps firms determine which aspects of the website work best for mobile traffic and which mobile marketing campaigns work best for the firm, including mobile advertising, mobile search marketing, text campaigns, and desktop promotion of mobile sites and services.\n").padding(10)
                        Text("As firms are striving to provide the best customer relationship possible, regardless of the type of device or channel the customer uses, developing a strategy for mobile analytics should be a part of full-blown multi-channel data integration and multi-channel marketing strategy.  Mobile web analytics studies the behavior of mobile website visitors, in a similar way to traditional web analytics.  \n").padding(10)
                        Text("Collecting mobile web analytics data is not as straight forward as traditional web analytics since many of the common methods for data collection either do not work or are at best unreliable.  Using traditional tools such as Google Analytics may still appear to work but will actually provide misleading data that represents only a percentage of actual mobile traffic.  For example, when applying traditional analytics software on a mobile website you may only see page views and visits counted only for cellular wireless (mobile phone) HTTP requests coming from the most advanced mobile browsers such as those found in the iPhone and other smart phones and PDAs rather than all the mass market devices actually browsing your site from a cellular mobile network.  Also, traditional web analytics software that uses server log parsing and associates different IPs with ‘unique visitors’ may fail miserably in identifying unique visitors, since the IPs from which cellular wireless network HTTP requests originate from are the gateway IPs of the network access providers (carriers).\n").padding(10)
                        Text("Note that mobile websites are usually open to access from any kind of network (fixed, Wi-Fi, cellular wireless, satellite wireless) so depending on where the HTTP requests are coming from, a traditional web analytics solution could be from pretty much accurate to mostly inaccurate.  In addition, mobile web analytics involves metrics and KPIs associated with mobile device information (model, manufacturer, screen resolution) which can be usually assembled by combining device identification information taken from special HTTP headers (such as user-agent) with device capabilities stored in a device information registry.  This is not provided by traditional web analytics solutions since it is only related to the mobile web.\n").padding(10)
                        }
                    } // Section 9
//                    // ----------------------
//                    Section(header: Text("Figure 12-12: An Example of Average Time to Serve Documents Report")) {
//                        Text("Diagnostic reports use the reports analytics module to analyze diagnostic data.  The analytics assesses how well the website server satisfies the needs of visitors.  The analytics includes pattern analysis results regarding bandwidth summary, bandwidth trends, and hits by http status.  These analytics can be used to provide insights regarding server capacity and usage.  For example, the analytics provides information regarding the average time to serve dynamic pages and forms of the website by day.  This insight reveals how long the visitors in average have to wait to get web page response after they click.  If the average time to serve is too long, a firm may be losing potential visitors due to slow web response and wait time.  In this case, marketing managers might initiate the increase of bandwidth for peak time.\n").padding(10)
//                        Text("Figure 12-12 shows the average time to serve documents analytics.  This analytics report displays the average amount of time it takes to serve pages classified as documents.  Marketing managers can consider increasing the available bandwidth if the times to serve spike at rates disproportionate to the number of documents served during the same time interval.  If marketing managers see this problem and have enough bandwidth, the firm’s server power may be a factor.\n").padding(10)
//                        // ----------------------
//                        Image(name: "Figure-12-12.jpg")
//                            .resizable()
//                            .scaledToFit()
//                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
//                            .padding(.top, 20)
//                            .padding(.bottom, 30)
//                        // ----------------------
//                        // ----------------------
//                        Button("Click for ... Figure 12-12: An Example of Average Time to Serve Documents Report") {
//                            self.showingFigure1212Sheet1.toggle()
//                        }
//                        .sheet(isPresented: $showingFigure1212Sheet1) {
//                            Figure1212View1()
//                        }
//                    } // Section 10

//                // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("12.1 Websites Clickstream Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // -----------------------------
        //        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 12-3 VIEW
// ------------------------------
struct Figure123View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-3: Generated Insights")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-4 VIEW
// ------------------------------
struct Figure124View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-4: An Example of Advertising Click-Through Rate Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-4.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-5 VIEW
// ------------------------------
struct Figure125View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-5: An Example of Advertising View Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-5.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-6 VIEW
// ------------------------------
struct Figure126View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-6: An Example of Shopping Event Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-7 VIEW
// ------------------------------
struct Figure127View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-7: An Example of Top Pages by Views Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-7.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-7 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-8 VIEW
// ------------------------------
struct Figure128View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-8: An Example of Visits by Day of the Week Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-8.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-8 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-9 VIEW
// ------------------------------
struct Figure129View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-9: An Example of New and Returning Visitors Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-9.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-9 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-10 VIEW
// ------------------------------
struct Figure1210View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-10: An Example of Top Entry Pages by Visits Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-10.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-10 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-11 VIEW
// ------------------------------
struct Figure1211View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-11: An Example of Top Exit Pages by Visits Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-11.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-11 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 12-12 VIEW
// ------------------------------
struct Figure1212View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-12: An Example of Average Time to Serve Documents Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-12.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-12 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
