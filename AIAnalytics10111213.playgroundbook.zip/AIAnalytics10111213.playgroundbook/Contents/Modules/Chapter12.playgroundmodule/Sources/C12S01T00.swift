//
//  C12S01T00.swift
//  Chapter 12 Section 01: Topic 00: Website Clickstream Management Task
//
//  Created by SBAMBP on 4/08/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C12S01T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure121Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("12.1.1 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Digital Marketing Activity")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("With the increased importance and influence of digital marketing, marketing managers are facing a not so familiar task of managing digital marketing activity.  With the dramatic growth of e-commerce, online advertising, and social media, marketing managers must understand the nature and process of a firm’s digital presence and how to manage digital marketing activities.  To understand the digital marketing task and generate the right analytic questions, marketing managers need to have the basic knowledge of the components and technologies driving the digital marketing activities.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Digital Presence")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Using websites and social media can be an effective way for firms to reach significant numbers of individuals.  However, in order for firms to gain value by using digital presence through websites and social media to reach these potentially interested individuals, the firms should do more than having a mere digital presence.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    // ----------------------
                    Section(header: Text("Figure 12.1: Digital Marketing Management Framework")) {
                        Image(uiImage: UIImage(named: "Figure-12-1.jpg")!)
//                        Image(name: "Figure-12-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.top, 20)
//                            .padding(.bottom, 30)
                        Button("Click to highlight ... Figure 12-1: Digital Marketing Management Framework") {
                            self.showingFigure121Sheet1.toggle()
                        } // button
                        .font(.caption)
                        .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure121Sheet1) {
                            Figure121View1()
                        } // sheet
                        Text("Firms can enhance their digital presence by specifically focusing on monitoring digital marketing activities and managing their digital presence.  With increased use of digital marketing, firms must discover ways to critically evaluate the effectiveness of their digital marketing activities.  Figure 12-1 presents digital marketing management areas that marketing managers are using for managing digital marketing.  The framework in Figure 12-1 shows how a firm’s digital marketing goals and investments, digital marketing strategies and plans, and digital marketing activities and tactics can influence the digital marketing presence and outcome.  Digital marketing activity and its effectiveness is the results of a firm’s plans and tactics for digital marketing which fosters the engagement of users for the firm’s websites and social media sites.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Totality of Activities")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("A firm’s digital marketing activity comprises the totality of activities generated by both internal and external users of the firm’s websites and social media platforms (e.g., Facebook, Instagram, Pinterest, Twitter, YouTube).  Digital marketing activities and tactics have the three key components of breadth, depth, and intensity.  Digital marketing breadth, the first digital marketing activity component, refers to how many different types of digital marketing activity tools a firm utilizes.  It will be necessary to help firms understand which types of digital marketing tools and social media platforms to engage and allocate resources.\n").padding(10)
                        } // Section 4
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Digital Marketing Depth")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Digital marketing depth, the second digital marketing activity component, refers to the number of digital marketing tools and social media platforms a firm supports.  A firm can support multiple digital marketing activities and tools.  The firm must determine which digital marketing activities to invest and allocate resources to, as digital marketing tools and various social media platforms have become important components in the firm’s marketing communications process.  A firm’s websites and social media platforms are permitting firms to engage with an individual or to dialog with various individuals without the restrictions of time, place, or medium.\n").padding(10)
                        } // Section 5
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("Digital Marketing Intensity")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("Digital marketing intensity, the third component of digital marketing activity, refers to the degree of activities generated in a given digital marketing activity tool and social media platform.  Intensity represents the number of occurrences or frequencies of the commonly identified user and firm activities relevant to each selected digital marketing effort.  Some firms concentrate on specific digital marketing activities such as blogs and generate significant number of activities while other firms choose to spread their efforts on several digital marketing activities to generate average activity.  Firms are using digital marketing tools and social media platforms to support various strategic areas such as brand management, sales, new product development, customer service/support, and customer relationship management.\n").padding(10)
                        } // Section 6
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Digital Components")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("A firm’s three digital marketing components (breadth, depth, and intensity) determine the firm’s digital marketing presence through its websites and social media sites.  Marketing managers need to manage the firm’s e-commerce sites as well as social media sites.  This digital network management task is becoming critical for a firm’s marketing success.  In managing the digital network, marketing managers need to understand and effectively manage a firm’s websites as well as social media sites. This chapter focuses on digital site management issues.  The digital content and user interactivity outcome resulting from digital marketing presence will be discussed in the next chapter.  For effective digital marketing presence, marketing managers face the challenging task of generating and evaluating a firm’s website clickstream analytics and social media network analytics.\n").padding(10)
                    } // Section 7
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("1. Business Analytics Tasks", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 12-1 VIEW
// ------------------------------
struct Figure121View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 12-1: Digital Marketing Management Framework")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-12-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 12-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
