//
//  C12S01T01.swift
//  Chapter 12 Section 01: Topic 01: Website Clickstream Management Task
//
//  Created by SBAMBP on 4/08/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C12S01T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start ---
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("12.1.1 Website Clickstream Management Task").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Understand Nature of Web Traffic")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The first task of marketing managers in managing digital marketing is to understand the structure and nature of web traffic.  Web structure analytics provides the structure of websites.  Marketing managers have the task of evaluating the clickstream of website users of the firm’s sites.  Managers need to understand how visitors reach the firm’s websites and their visitor behavior patterns.  Marketing managers need to understand whether the firm’s online web and e-commerce sites are performing adequately and provide the desired outcomes.  It is important to assess that the web and e-commerce sites are generating the amount of traffic of the right type of visitors and that the firm’s web and e-commerce sites are providing the expected customer experiences using desktop, tablets, and mobile devices.  Thus, managers should ensure that their sites are optimized for both desktop and mobile devices.  Marketing managers need to understand how visitors come to their sites and what the traffic and navigation patterns of the visitors of their website and e-commerce sites are.\n").padding(10)
                    } // Section 1
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Web Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                    {
                // ----------------------
                Text("Web analytics can be defined as the measurement, collection, analysis, and reporting of internet data for purposes of understanding and optimizing web usage.  A survey result shows that in-house web analytics expertise is more valuable than the technology itself.  Web analytics can help firms better understand and manage their customers with the insights generated from web data analytics.  Web analytics can provide a wide variety of insights related to shopping behaviors, customer purchase paths and preferences, research behaviors, and feedback behaviors.\n").padding(10)
                } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Online Purchases")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Web analytics can provide information regarding how customers make online purchases.  This information includes what search engine they use, what specific terms they enter, the use of bookmark, the referring sites, and many others.  Web analytics can provide information on how customers arrive at their buying decisions, how they navigate a site, their preferences in purchasing, and search patterns regarding weekend deals.  Understanding how customers use a site’s research content can provide insights into how to interact with a customer.  This can provide insights regarding which aspects or features of the site can add value to customers thus driving sales as well as which type of information such as product specifications or customer reviews is ultimately valued by customers.  Web analytics can provide information regarding customers’ feedback on product and services.\n").padding(10)
                    } // Section 3
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Clickstream Data")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                    {
                // ----------------------
                Text("Clickstream data allows managers to see what actions customers are taking on their websites.  As online purchase and e-commerce is becoming increasingly important, marketing managers must capture and evaluate clickstream data to stay competitive.  Managers can analyze customers’ behavior with the clickstream data.  Managers can combine the individual visitor level information with any other data source.  With clickstream data, personalization can be done on different customer touchpoints.  Marketing managers can recommend relevant products or content tailored specifically to the customer who is browsing their website.  Marketing managers can ensure that all customers can have consistent customer experience across all touchpoints.\n").padding(10)
                } // Section 4
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Patterns")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                    {
                // ----------------------
                Text("Patterns can be used by the marketing managers to segment or cluster the firm’s customers into those that perform a similar sequence of navigation to locate information or purchase products and services.  The marketing manager can develop a series of analytic questions to perform the analytics task.  Clickstream analytics can answer many different analytic questions including which pages are most frequently visited, which will be subsequently visited, which pages yield results, and the order in which these pages were visited by the consumer.  Additional analytic questions marketing managers can ask include: where the visitor comes from, which webpage the visitor first accesses and in what sequence the visitor accessed the pages on the website, how much time the visitor spends on each page and from which page the visitor exits the website, and what items the visitor adds to his/her shopping cart.\n").padding(10)
                } // Section 5
                // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("12.1 Websites Clickstream Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
