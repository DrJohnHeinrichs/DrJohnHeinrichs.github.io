//
//  C13S01T01.swift
//  Chapter 13 Section 01: Topic 0: Website Clickstream Management Task
//
//  Created by SBAMBP on 4/08/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
////    // usage: Image(name: "imageNameHere.jpg"
////    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S01T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure131Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("13.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Digital Marketing Activities")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Firms are increasingly supporting more diverse digital marketing activities that encompass entertainment, information sharing, promotion, and crowd sourcing.  For effective management, marketing managers need to generate and evaluate a firm’s website analytics and social media network analytics.  This chapter focuses on the digital site management issues.  The key topical areas covered in this chapter are how firms manage their digital marketing presence.  A firm’s digital marketing presence can be achieved through digital sites including websites and social media sites.\n\nFigure 13-1 presents a digital marketing management framework that describes three key components of digital marketing management.  Figure 13-1 conceptual model shows three key areas of digital marketing outcome.  This chapter focuses on the last component of the framework that is the digital content and user interactivity management.  This component represents the digital marketing outcome encompassing the digital content generated internally and externally, users’ digital site ratings, and user engagement activities in those digital sites.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: Text("Figure 13-1: Digital Marketing Management Framework"))
                        {
                        Image(uiImage: UIImage(named: "Figure-13-1.jpg")!)
//                        Image(name: "Figure-13-1.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Figure 13-1: Digital Marketing Management Framework") {
                        self.showingFigure131Sheet1.toggle()
                    } // Button
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure131Sheet1) {
                        Figure131View1()
                    } // sheet
                    } // Section 3
                    // ----------------------
                    // ----------------------
                    Text("The first important digital presence outcome is digital content.  Through the firm’s websites and social media sites, digital content is created by the firm and its customers and other stakeholders.  Marketing managers face the task of evaluating and managing the digital content.  This digital content management task is increasingly important in every aspect of marketing especially customer service and brand management.  Marketing managers need to generate and evaluate the appropriate digital content analytics to assess the quality and impact of a firm’s digital content.\n").padding(10)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Rating Management")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("The second important task marketing managers are facing is digital sites rating management.  While users are being engaged with the firm’s websites, e-commerce sites, and social media sites, marketing managers need to understand how well the digital sites are performing and whether these sites are providing the kind of user experience the firm is pursuing.  It is important for marketing managers to assess how a firm’s websites as well as social media sites are rated by customers.  Marketing managers need to generate and assess a firm’s sites rating analytics for effective management of digital sites.\n").padding(10)
                    } // Section 4
                        // ----------------------
                        Section (header: HStack {
                            Image(systemName: "pencil")
                            Text("User Engagement")
                                .font(.system(size: 20, weight: .heavy, design: .default))
                                } )
                            {
                        // ----------------------
                        Text("The final task of marketing managers is evaluating digital site user engagement.  It is important to understand how customers interact and engage with a firm’s websites and social media sites.  Although the vividness and interactiveness of user engagements may be different, it is the activities generated and the individual engagement that make specific types of digital marketing initiatives valuable to the firm.  Marketing managers need to generate and understand user engagement analytics for a firm’s websites as well as social media sites.  The next section describes how marketing managers generate, interpret, and apply digital content analytics, website rating analytics, and user engagement analytics.\n").padding(10)
                        } // Section 5
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("13.1 Websites Clickstream Analytics", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 13-1 VIEW
// ------------------------------
struct Figure131View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 13-1: Digital Marketing Management Framework")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-13-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 13-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
