//
//  C13S01T02.swift
//  Book_Sources
//
//  Chapter 13 Section 01: Topic 02: Digital Marketing Content Analytics Generation, Interpretation and Application
//
//  Created by SBAMBP on 4/11/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
////    // usage: Image(name: "imageNameHere.jpg"
////    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S01T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure132Sheet1 = false
    //    @State private var showingTable31Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
         // ------------------------------
         // SECTION 1.2: Start --- Digital Marketing Content Analytics Generation, Interpretation and Application
         // ------------------------------
            NavigationView {
                List {
                    Text("13.1.2 Digital Marketing Content Analytics Generation, Interpretation and Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Text("This section focuses on text analytics, video analytics, and image analytics.")
                    NavigationLink(destination: TextAnalytics()){
                        Text("Text Analytics")
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    NavigationLink(destination: VideoAnalytics()){
                        Text("Video Analytics")
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    NavigationLink(destination: ImageAnalytics()){
                        Text("Image Analytics")
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                // ----------------------
                } // List -- text
                .padding(20)
                .font(.system(size: 18))
                .font(.headline)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .navigationBarTitle("13. Digital Marketing Content and User Interactivity Analytics", displayMode: .inline)
            } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1.2: End
        // ------------------------------
        } // body
    } // struct
// ------------------------------
// TOPIC: TEXT ANALYTICS
// ------------------------------
public struct TextAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
        NavigationView {
            // ----------------------
            List {
//            VStack{
                // ----------------------
                Text("Text Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Analytics Toolbox")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("For the digital marketing content analytics, marketing managers can choose many different analytic tools from the analytics toolbox.  One of the most significant developments in analytics field is text analytics.  The text analytics is particularly important as digital marketing content exist in the form of unstructured data such as text.  In order to generate content text analytics, marketing managers need to capture any online content in text form.  Digital content that exist in text form include blog post, customer comments, product and brand evaluations, and Twitter text.  The captured text can be the input format for text analysis discussed in an earlier chapter.  With the captured text, marketing managers can find answers to analytic questions such as what are the common issues or problems mentioned in the posts, what are the sentiments of the posted contents, and for which contents the participants’ sentiments are positive or negative.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
//            } // VStack - inner
            // ----------------------
                NavigationLink(destination: UserDrivenTextAnalytics()){
                    Text("User Driven Text Analytics")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
                NavigationLink(destination: AIDrivenTextAnalytics()){
                    Text("AI Driven Text Analytics ")
                    .italic()
                    .foregroundColor(.blue)
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    .padding(10)
                }
              //  .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, height: 650, maxHeight: .infinity)
            // ----------------------
        } // List
            .navigationBarTitle("13.1.2 Analytics Generation, Interpretation, and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
    } // body
} // struct
// ------------------------------
// TOPIC: USER DRIVEN ANALYTICS
// ------------------------------
public struct UserDrivenTextAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
        List {
            // ----------------------
            VStack{
                // ----------------------
                Text("User Driven Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Types of  Text Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Marketing managers can use two types of text analytics for marketing decisions.  These two types are the user generated text analytics and AI generated text analytics.  The user generated text analytics can be created by marketing managers using analytic tools and processes.  Text mining tools can evaluate the tone, intent, and topic of a customer’s feedback on a firm’s brand.  Organizations can evaluate which customers post reviews of what they buy and how these reviews are read or viewed by other customers and influence their purchase decisions.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
        } // List
    } // body
} // struct
// ------------------------------
// TOPIC: AI DRIVEN ANALYTICS
// ------------------------------
public struct AIDrivenTextAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
        List {
            // ----------------------
            VStack{
                // ----------------------
                Text("AI Driven Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("AI Generated Text Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("AI generated text analytics can be generated using various AI analytics tools and services offered by many different firms.  One such AI generated text analytics is provided by IBM Watson.  IBM Watson provides a number of AI-driven text analytics tools that can be used by marketing managers.  Watson “Natural Language Classifier” allows marketing managers to classify short text input into predicted classes using machine learning algorithms.  This tool can categorize text with custom labels or categories to automate workflows, extract insights, and improve search and discovery using natural language processing and machine learning.  Marketing managers can create and train a classifier to classify texts into predefined classes.  Watson knowledge component also offers “Natural Language Understanding” function that offers advanced text analysis using natural language processing.  In addition, Watson “knowledge studio” can discover meaningful insights from non-structured text.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                    Text("Sentiment analysis can be also performed by AI analytics tools.  AI-driven tools can provide sentiment analytics using natural language processing capabilities.  For example, IBM Watson “Empathy” tool can provide marketing managers tone, emotional state, and personality characteristics using text information.  AI generated sentiment analytics can be combined with the user generated sentiment analysis results to evaluate customers’ positive and negative feelings and emotions toward a firm’s brands and products.  These insights can be used in making marketing decisions related to a firm’s products and brands.  In addition, Watson offers “Tone Analyzer” to conduct social listening.  Watson “Tone Analyzer” analyzes emotions and tones in what people write online, like tweets or reviews, and predict whether they are happy, sad, confident, etc.  Using this tool and service, marketing managers can monitor customer service and support conversations and respond to customers appropriately at scale.  Marketing managers can assess whether customers are satisfied, frustrated, and if agents are polite and sympathetic.  Marketing managers can integrate these results with chatbot.  Firms can enable chatbot to detect customer tones and build effective dialogue strategies to adjust the conversation accordingly.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
        } // List
    } // body
} // struct
// ------------------------------
// TOPIC: VIDEO ANALYTICS
// ------------------------------
struct VideoAnalytics: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingFigure132Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0

    var body: some View {
        List {
            // ----------------------
            VStack{
                // ----------------------
                Text("Video Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Online Video Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                Text("Another important form of digital marketing content is video.  The digital content of video can be generated by the firm or by users and customers.  The increased popularity of social media video platform such as YouTube makes the video analytics a critical component of marketing analytics that marketing managers must understand utilize in marketing decision making.  Video is a key element of the website promotion.  Online video analytics is way of measuring how viewers get to an online video and what they do when they watch it.  A video is any length of video stream, such as a movie clip, video advertisement, movie trailer, television show or full-length video.  Web video analytics attempts to answer various analytic questions.  These analytic questions include:\n").fixedSize(horizontal: false, vertical: true).padding(10)
                VStack (alignment: .leading, spacing: 2) {
                    Text("\u{2022}  How long did the viewer watch a particular video?").padding(5)
                    Text("\u{2022}  Did they pass it along to a friend?").padding(5)
                    Text("\u{2022}  Did they embed it in their home page?").padding(5)
                    Text("\u{2022}  If there was an advertising overlay with the video, did they watch it?").padding(5)
                    Text("\u{2022}  If so, for how long?").padding(5)
                    Text("\u{2022}  Did they click through to complete a sale proposed by the ad? and").padding(5)
                    Text("\u{2022}  Where do the viewers come from that watch videos on a particular site?").padding(5)
                } // Section 1
                } // VStack
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Web Video Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                Text("Online video analytics also known as web video analytics is becoming increasingly important in understanding customer behaviors.  This analytics is the measurement, analysis, and reporting of videos viewed online.  Using the census-based method, web video analytics can capture and report every event that a viewer does while watching a video online.  The purpose of video analytics is to evaluate whether videos help firms reach their goals.  Depending on the goal of video marketing, different types of measures are utilized.  The following are list of video analytics and related goals.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                VStack (alignment: .leading, spacing: 5) {
                    HStack {
                    Text("\u{2022} ")
                    Text("View Count").underline().bold().italic()
                    Text("View count is the first measure of video analytics showing whether your video is drawing customers to the posted video reflecting the goal of ‘reach’.  It is important to focus on the deeper story of how videos are performing and resonating for your goals.").padding(5)
                    } // HStack 1
                    HStack {
                    Text("\u{2022} ")
                    Text("Quality").underline().bold().italic()
                    Text("The percent of a video that a viewer watched shows a firm’s video ‘quality’ of views.  This analytic indicate whether viewers find it helpful, stick around to watch the entire video, or lose them to a slow hook, or start wrapping up too soon.  Although the level of engagement is important, firms need to consider whether viewers leave videos satisfied (e.g., get what they wanted or feel more educated).").padding(5)
                    } // HStack 2
                    HStack {
                    Text("\u{2022} ")
                    Text("Play Rate").underline().bold().italic()
                    Text("The percent of page visitors who clicked play and started watching, shows the ‘relevance’ of video indicating whether your video is in the best possible context.").padding(5)
                    } // HStack 3
                    HStack {
                    Text("\u{2022} ")
                    Text("Site Metrics").underline().bold().italic()
                    Text("Site metrics can reveal user experience with your videos.  Site metrics showing user experience include bounce rate (the number of viewers who enter your site and then leave without viewing other pages), time spent on page (visitors will spend more time on the page where a good video is embedded), and sign-ups, subscriptions and conversions (with embedded video, viewers' activity in your analytics showing how they're converting).").padding(5)
                    } // HStack 4
                    HStack {
                    Text("\u{2022} ")
                    Text("Word of mouth with social media").underline().bold().italic()
                    Text("Keeping track of how viewers are sharing and discussing your content on social media and what people are saying about your video content.").padding(5)
                    } // HStack 5
                    HStack {
                    Text("\u{2022} ")
                    Text("Comments").underline().bold().italic()
                    Text("Comments can be a great way to measure how strongly your content resonated in the user community.").padding(5)
                    } // HStack 6
                    HStack {
                    Text("\u{2022} ")
                    Text("Type of Conversation").underline().bold().italic()
                    Text("When firms create a video to help answer a common question or solve a common problem, tracking how many support emails or calls you receive about that topic, or, the quality of questions you receive over time can indicate the ‘clarity’ of videos posted.").padding(5)
                    } // HStack 7
                    HStack {
                    Text("\u{2022} ")
                    Text("Trust").underline().bold().italic()
                    Text("The level of trust customers put on your firm or brand can be indicative of the level of success of posted videos.").padding(5)
                    } // HStack 8
                    } // VStack
                } // Section 1
                // ----------------------
                Section (header: Text("Figure 13-2: Sample Video Analytic Report") )
                    {
                // ----------------------
                Image(uiImage: UIImage(named: "Figure-13-2.jpg")!)
//                Image(name: "Figure-13-2.jpg")
                    .resizable()
                    .scaledToFit()
                    .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                    .aspectRatio(contentMode: .fit)
                    // .frame(width: geo.size.width)
                    // .frame(width: UIScreen.main.bounds.width, height: 200)
                    .frame(width: 400, height: 200)
                    .scaleEffect(self.scale1)
                    .gesture(MagnificationGesture()
                    .updating(self.$scale1, body: { (value, scale1, trans) in
                        scale1 = value.magnitude
                        })
                    )
                    .padding(.bottom, 30)
                Text("Video analytics can be generated using various video analytic softwares.  The popular software tools include Quantcast, Visible Measures, Wistia, and Blue Kai.  These tools measure in-video ad metrics.  Figure 13-2 shows a sample video analytic report.  Figure 13-2 provides a sample video analytic report showing playtime per view, completion rates, number of views, and impressions.  This information can be used to begin to generate insights and the effective use of videos in customer engagement and interaction.  It is not primarily about views (but rather, it is) more about engagement, brand impact, social word-of-mouth, and sales.  These video metrics can provide useful insights to marketing managers in understanding viewer behaviors and quality of experience.  Managers can make adjustment on their network infrastructure, encoding requirement, quality of source content for better ad placement, maximum viewer engagement, and improved user experience.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 13-2: Sample Video Analytic Report") {
                        self.showingFigure132Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure132Sheet1) {
                        Figure132View13()
                    }
                } // Section 2
            } // VStack - inner
            // ----------------------
        } // List
    } // body
} // struct
// ------------------------------
// TOPIC: IMAGE ANALYTICS
// ------------------------------
struct ImageAnalytics: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        List {
            // ----------------------
            VStack{
                // ----------------------
                Text("Image Analytics").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Image-Centric")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                Text("Image is another form of digital marketing content that can provide valuable marketing insights for marketing managers.  The growth of image-centric platforms like Instagram, Snapchat and Pinterest has pushed other social media platforms to include options for sharing images.  In addition, images in video can be also have marketing implications.  Image analytics is extracting meaningful information from photos and images in video for marketing decision making using digital image processing technology. As a huge number of images and videos are posted online, they contain brands and products.  Image analytics utilizes image recognition method that allows marketing managers to find images online containing a pre-defined search query or similar images.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                Text("The digital marketing content includes photos that include brand products and logos without any mention of them in the posted text.  In many posted images, a certain brand or brands are shown but they are not the main focus point of the post.  However, the natural appearance of those brands or products in photos can help marketing managers understand the lifestyles and passions of your target audience.  This information can be used by marketing managers for competitive intelligence, product development, influencer strategy, and organic reach.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                Text("Image analytics can complement text analytics as images can transcend language barriers, they can be more accurate than text, and they tend to be more personal. Images can be universal and expand geographically for global brands and allows marketing managers to glance users’ lives provided by the images they share.  Image analytics provides many benefits to marketing managers.  Image analytics offers deeper understanding of social media posts by providing the quality and context of social mentions.  It also makes sentiment analysis more complete by evaluating the expression of a user’s face with the posted text and context.  It allows marketing managers readily spot and analyze user-generated content.  Marketing managers can gain insights regarding how customers use products through lifestyle posts on social media.  Image analytics allows marketing managers to identify both celebrities and non-celebrities’ influencers sharing images of their lives revealing the firm’s products and brands.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                Text("Image analytics can identify the firm’s logo or brand image in social media posts.  This is an instance of visual mention of the firm’s products and brands.  A firm’s logo can be identified in many different photos such as selfies, a photo with a celebrity, a photo in a particular location, a photo of a specific display such as billboard, real-time digital sign, sponsorship banner, phone booths, transport ads in taxis, buses, subways, and trains.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                Text("Image analytics can provide all instance of image-based user-generated content that include the firm’s logo and product through visual listening of social media.  The user-generated content containing the firm’s logo and brands can build brand awareness.  This allows marketing managers the ability to monitor the actual brand exposure outside the channel and evaluate how much engagement and exposure the firm’s brand is receiving.  Image analytics can detect unauthorized use of the firm’s logo and counterfeit brands through identifying similar images of the firm’s logo and brands.  AI powered image analytics can capture the user reactions when shown certain advertisements and content by collecting real-life and spontaneous facial reactions and expressed emotions.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // VStack - inner
            // ----------------------
        } // List
    } // body
} // struct
// ------------------------------
// FIGURE 13-2 VIEW
// ------------------------------
struct Figure132View13: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 13-2: Sample Video Analytic Report")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-13-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 13-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
