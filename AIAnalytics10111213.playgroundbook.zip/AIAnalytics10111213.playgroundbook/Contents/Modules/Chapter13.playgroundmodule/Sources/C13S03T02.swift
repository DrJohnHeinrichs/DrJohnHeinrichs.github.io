//
//  C13S03T02.swift
//  Chapter 13 Section 03: Topic 02: Digital Sites User Engagement Analytics Generation, Interpretation and Application
//  Book_Sources
//
//  Created by SBAMBP on 05/04/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S03T02: View {
    var topicTitle: String = "Topic Title"

    @State private var showingTable131Sheet1 = false
    @State private var showingTable132Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ----------------------
        // Start: Topic 2 - Digital Sites User Engagement Analytics Generation, Interpretation and Application
        // ----------------------
        VStack {
            NavigationView {
                List {
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("13.3.2 Digital Sites User Engagement Analytics Generation, Interpretation, and Application")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                } )
                {
                Text("Engagement comprises online conversion, activities, satisfaction representing both an internal mental state and external activity.  Firms are using various metrics of online engagement such as the individual session-based indices.  These indices include click-depth index, recency index, duration index, brand index, feedback index, and interaction index.  Click-depth index is the percentage of sessions having more than n page views divided by all sessions. Recency index refers to the percentage of sessions having more than n page view that occurred in the past n weeks divided all sessions.  Duration index shows the percentage of sessions longer than n minutes divided by all sessions.  Brand index is the percentage of sessions that either began directly or were initiated by an external search for a “branded” term divided by all sessions.  Feedback index refers to the percentage of sessions where the visitor gave direct feedback divided by all sessions.  Finally, interaction index is the percentage of sessions where the visitor completed one of any specific, tracked events divided by all sessions.  In each of these indices, the n value can be set by the managers.\n")
                }
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Outcome Measures")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                } )
                {
                Text("In addition to these indices, social media activity outcome measures related to the social networking platforms can be utilized by marketing managers.  These relevant social media outcome measures are listed for various types of social media.  Social media metrics are organized by the social media objectives of brand awareness, brand engagement, and word-of-mouth.  For blogs sites, metrics such as number of unique visits, return visits, number of times bookmarked as well as search ranking are useful for evaluating the brand awareness effect.  Metrics such as number of members, RSS feed subscribers, comments, user generated content, responses to polls, contests, and surveys as well as average length of time on the site can be used for evaluating brand engagement impact.  Metrics such as number of references to blog in other media, badge displayed on other sites, and “likes” are useful to evaluate word of mouth activities.\n")
                } // Section 2
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Example Metrics")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                } )
                {
                Text("For microblogging sites such as Twitter, metrics such as number of tweets, valence of tweets, and followers are important for brand awareness evaluation; metrics such as number of followers and replies are important for brand engagement; metrics such as number of retweets are important for evaluating word-of-mouth activities.  For social networking sites such as Facebook and LinkedIn, metrics such as number of membership/fans, installed applications, impressions, bookmarks, and reviews/ratings/valence need to be monitored to enhance brand awareness.  Metrics such as number of comments, active users, “likes”, user generated items, usage metrics, impressions-to-interactions ratio, and rate of activity are relevant for assessing brand engagement.  Metrics such as number of posts on wall, reposts/shares, and responses to friend referral invites are useful to evaluate word of mouth activities.  \n\nFor video and photo sharing sites such as YouTube and Flickr, metrics such as number of views and valance of video/photo ratings are useful for assessing brand awareness; metrics such as number of replies, page views, comments, and subscribers are important for brand engagement evaluation; and number of embeds, incoming links, references in mock-ups, times republished in other social media and offline, and “likes” are useful for evaluating word of mouth activities.  These metrics can provide guidelines for managers regarding which metrics they should focus on in evaluating their social media activities and what tools or tactics need to be used to achieve the desired social media contribution to CRM goals.\n")
            } // Section 3
//            .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Status of Fortune 500")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                } )
                {
                Text("A recent study reports the social media activity outcome measures for Fortune 500 firms.  The first type of social media platform encompassed the social networking platforms of Facebook, Google+, and LinkedIn.  The social networking activity outcome measures include the number of Facebook likes, offline visits, Google+ followers, LinkedIn number of employees and followers.  The second type of social media platform is micro-blogs, which included Twitter with the micro-blog activity outcome measures as the number of Twitter followers and feeds.  The third type, content communities, includes Flickr, Instagram, Pinterest, and YouTube with the content community’s activity outcome measures of number of Flickr photos posted, Instagram followers, Pinterest followers, YouTube subscribers, videos posted on YouTube, and views.  For each of the firms selected for the study, the identified social media activity outcome measures available in a firm’s three social media platforms were captured and recorded.  The actual reported measures are described in Table 13-1.\n")
                } // Section 4
        //              .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Table 13-1: Social Media Activity Outcome Measures")) {
                    Image(uiImage: UIImage(named: "Table-13-1.jpg")!)
//                    Image(name: "Table-13-1.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale2)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale2, body: { (value, scale2, trans) in
                            scale2 = value.magnitude
                            })
                        )
                        .padding(.bottom, 30)
                Button("Click for ... Table 13-1: Social Media Activity Outcome Measures") {
                    self.showingTable131Sheet1.toggle()
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable131Sheet1) {
                        Table131View1()
                }
                    .padding(10)
                Text("Table 13-2 shows mean values for the fourteen social media activity outcome measures of the 207 Fortune 500 firms.  For the social networking platform activity outcome measures, firms show high Facebook-Likes, LinkedIn-Followers, and Google+-Followers.  For micro-blogs platform activity outcome measures, Twitter-Followers show high user activities.  For the content community platform activity outcome measures, YouTube-Views along with Pinterest-Followers and Instagram-Followers show high level of user activities.\n")
                }
        //                    .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Table 13-2: Social Media Activity Outcome Mean Values")) {
                    Image(uiImage: UIImage(named: "Table-13-2.jpg")!)
//                    Image(name: "Table-13-2.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .aspectRatio(contentMode: .fit)
                        // .frame(width: geo.size.width)
                        // .frame(width: UIScreen.main.bounds.width, height: 200)
                        .frame(width: 400, height: 200)
                        .scaleEffect(self.scale1)
                        .gesture(MagnificationGesture()
                        .updating(self.$scale1, body: { (value, scale1, trans) in
                            scale1 = value.magnitude
                            })
                        )
                        .padding(.bottom, 30)
                Button("Click for ... Table 13-2: Social Media Activity Outcome Mean Values") {
                    self.showingTable132Sheet1.toggle()
                }
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable132Sheet1) {
                        Table132View1()
                }
                    }
        //               .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                } // List - text
                .padding(30)
                .font(.system(size: 22))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
//                .background(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.4000)))
                .navigationBarTitle("13.3 Digital Sites User Engagement Analytics", displayMode: .inline)
            } // NavigationView
            .navigationViewStyle(StackNavigationViewStyle())
        } // VStack 2
        // ----------------------
        // End: Topic 2
        // ----------------------
    } // body
} // struct
// ------------------------------
// TABLE 13-1 VIEW
// ------------------------------
struct Table131View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 13-1: Social Media Activity Outcome Measures")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-13-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 13-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 13-2 VIEW
// ------------------------------
struct Table132View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 13-2: Social Media Activity Outcome Mean Values")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-13-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 13-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
