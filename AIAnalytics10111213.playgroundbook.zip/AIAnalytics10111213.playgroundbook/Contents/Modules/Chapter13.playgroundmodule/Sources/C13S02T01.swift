//
//  C13S02T01.swift
//  Chapter 13 Section 02: Topic 01: Digital Sites Management Task
//  Book_Sources
//
//  Created by SBAMBP on 04/17/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S02T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        
        // ------------------------------
        // SECTION 1: Start --- Digital Sites Management Task
        // ------------------------------
        VStack {
            NavigationView {
                List {
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("13.2.1 Digital Sites Management Task")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("Marketing managers evaluate the firm’s website and social media pages looking to understand the status of its online and social media presence.  To complete the online and social media interactive analysis, firms are required to perform various analysis routines for recommendations and enhancements to the online websites and social media sites.  To perform digital sites management task, marketing managers need to ask various analytic questions including how well the firm’s websites and e-commerce sites perform functionally relative to competition and whether the sites offer the consistent user experience to customers and stakeholders.  For social media sites, the analytic question can be whether the social media sites provide the right place for engagement and interaction.  To answer these questions, marketing managers need to generate the right analytics. The next section describes how marketing managers generate the desired type of analytics to answer these analytic questions and generate insights for better digital marketing decisions.\n")
                        .padding(.bottom, 380)
                    } // Section
  //                  .listRowBackground(Color(red: 0.4551, green: 0.9922, blue: 1.0000, opacity: 0.2000))
                } // List -- text
                .padding(30)
                .font(.system(size: 22))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
 //               .background(Color(red: 0.4551, green: 0.9922, blue: 1.0000, opacity: 0.4000))
                .navigationBarTitle("13.2 Digital Sites Rating Analytics", displayMode: .inline)
            } // NavigationView
            .navigationViewStyle(StackNavigationViewStyle())
        } // VStack - 1
        // ----------------------
        // End: Topic 1
        // ----------------------
    } // body
} // struct
