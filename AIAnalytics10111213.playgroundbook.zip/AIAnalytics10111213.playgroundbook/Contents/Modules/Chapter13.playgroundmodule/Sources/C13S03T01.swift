//
//  C13S03T01.swift
//  Chapter 13 Section 03: Topic 01: Digital Sites User Engagement Management Task
//  Book_Sources
//
//  Created by SBAMBP on 05/04/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S03T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ----------------------
        // Start: Topic 1 - Digital Sites User Engagement Management Task
        // ----------------------
        VStack {
            NavigationView {
                List {
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("13.3.1 Digital Sites User Engagement Management Task")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("Given the proliferation of social media sites, it is important to understand the key attributes to better understand satisfaction and engagement patterns as these sites have collectively transformed into a specialized information-sharing communication channel.  Engagement is defined as an estimate of the depth of visitor interaction against a clearly defined set of goals with visitor interaction being measured by demonstrated interaction.  As part of the firm’s social media strategy, customers are encouraged to share their experiences, opinions, preferences, and product reviews.  To implement this strategy, firms engage with online virtual communities, develop content creation processes, blog about educational information, and perform customer relationship management activities.  In fact, engaging with online virtual communities positively impacts customer satisfaction by increasing the firm’s credibility.\n")
                    } // Section
//                    .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("Information Sharing Channel")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("Social media has proliferated and transformed into a specialized information sharing communication channel.  In this evolving co-production communication channel, firms must focus on understanding how to engage with customers.  Given the growing importance of this uncontrolled communication channel, it is critical for the firm to understand the customers’ perception of social media sites and their impact on satisfaction and engagement.  With the increased competition for a customers’ attention, the firm must satisfy informational needs by offering the right kind and level of engagement instead of merely having a digital presence.\n")
                    } // Section 2
 //                   .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("Engagement Analytics")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("Marketing managers face this important task of generating engagement analytics.  In order to accomplish this task, marketing managers need to ask the critical question of how well a firm’s touchpoints such as a website or social media site are performing in engaging with customers.  The generated engagement analytics can help firms to change site content, improve click-through referrals, identify effective keywords, and recognize key prospects through triggered alerts signaling immediate purchase.\n")
                    } // Section 3
  //                  .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                    Section (header: HStack {
                      Image(systemName: "pencil")
                      Text("Analytic Questions")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    Text("The analytic questions marketing managers can ask include what social media structures can nourish the online conversation and engagement of users, which social media platform is ideal for user connection and experience sharing, how social media can be used for fostering relationships with customers, and what are the drivers that influence social media activity outcome such as the number of likes and the number of comments.  Marketing managers can generate digital sites user engagement analytics to answer these analytic questions.  The next section describes how marketing managers can generate, interpret, and apply the digital sites user engagement analytics.\n")
                    } // Section 4
  //                  .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))

                } // List -- text
                .padding(30)
                .font(.system(size: 22))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
//                .background(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.4000)))
                .navigationBarTitle("13.3 Digital Sites User Engagement Analytics", displayMode: .inline)

            } // NavigationView
            .navigationViewStyle(StackNavigationViewStyle())
        } // VStack - 1
        // ----------------------
        // End: Topic 1
        // ----------------------
    } // body
} // struct
