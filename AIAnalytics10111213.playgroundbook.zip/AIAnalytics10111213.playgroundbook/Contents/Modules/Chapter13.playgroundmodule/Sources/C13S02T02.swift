//
//  C13S02T02.swift
//  Chapter 13 Section 02: Topic 02: Digital Sites Analytics Generation, Interpretation, and Application
//  Book_Sources
//
//  Created by SBAMBP on 04/18/2020.
//
import SwiftUI
import UIKit
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage: #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
public struct C13S02T02: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    } // init
    
    public var body: some View {
        // ----------------------
        // Start: Topic 2 -
        // ----------------------
        VStack {
            NavigationView {
                List {
                // ----------------------
                Section (header: HStack {
                  Image(systemName: "pencil")
                  Text("13.2.2 Digital Sites Analytics Generation, Interpretation, and Application")
                    .font(.system(size: 20, weight: .heavy, design: .default))
                } )
                {
                    Text("Marketing managers can use site analysis tools provided by various external firms.  In generating the firm digital sites analytics, the input data is the web and social media website URL for the firm.  The analytics tools marketing managers can use are website and social media site grading tools.  There are many automated tools that can be used for website and social media page analysis.  In order to complete the firm’s website and social media page analysis, marketing managers can use several no-charge grader tools (e.g. marketing.grader.com from HubSpot, Nibbler.com, and Woorank.com).  These grader tools provide marketing managers detailed reports that can help the firm generate insights and understanding of its online and social media presence.  The next section describes various grader tools for marketing managers to use.\n")
                    Text("A tool that marketing managers can use is marketing.grader.com.  For this tool, marketing managers can input the firm’s or brand’s website address and the marketing manager’s email address (see Figure 13-3).  This tool provides a comprehensive report.\n")
                } // Section 1
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13.3: Marketing.Grader.com from HubSpot")) {
                    Image(uiImage: UIImage(named: "Figure-13-3.jpg")!)
//                    Image(name: "Figure-13-3.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("The first part of the marketing grader report (shown in Figure 13-4) focuses on overall grade of the whole website.  The grade ranges from 0 to 100.  The report also shows the four components labeled performance, mobile, SEO, and security.  Each component is given a score.  The sum of these four component scores becomes the overall score.\n")
                } // Section 2
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13.4: Marketing Grader Report – Part 1: Overview")) {
                    Image(uiImage: UIImage(named: "Figure-13-4.jpg")!)
//                    Image(name: "Figure-13-4.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.bottom, 30)
                    Text("In the second part of the report, in the example shown in Figure 13-5, the website grader tool evaluates page size, page requests, and page speed.  This part evaluates how well the firm’s websites functionally perform for the customers’ webpage requests.\n")
                } // Section 3
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13.5: Marketing Grader Report – Part 2: Performance")) {
                    Image(uiImage: UIImage(named: "Figure-13-5.jpg")!)
//                    Image(name: "Figure-13-5.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Part 3 focuses on mobile performance.  In Figure 13-6, details on how the site performs on a mobile device are reported.  The mobile score ranges from 0 to 30.  The elements on the checklist include response and viewport.  In addition, determining the use of a mobile cascading style sheet (CSS) and the meta viewport tag.  The mobile CSS is important to the organization so that the website is properly styled on the smartphone for the individual.  Given that 43% of all mobile phones are smartphones, and that 87% of individuals use their smartphones to access the internet, rendering and properly orienting the web page is important.\n")
                } // Section 4
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13.6: Marketing Grader Report – Part 2: Performance")) {
                    Image(uiImage: UIImage(named: "Figure-13-6.jpg")!)
//                    Image(name: "Figure-13-6.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Part 4 of the website grader report focuses search engine optimization assessment for the website (shown in Figure 13-7).  While the grader only looks for a few elements of SEO, it is important to realize that more must be done.  The grader assesses three main requirements that include page titles, meta description, headings, and sitemap.  These steps are whether Alt tags for images are being used, that page titles are set up properly, and that pages have unique descriptions.  The information professional is provided with statistics such as the number of inbound links identified and the MozRank of the site to assist in their investigation.  The SEO rating for the blog posts encompass title optimization, body optimization, image optimization, and meta optimization.  Title optimization focuses on the number of keywords in the title and the length of the title.  The body optimization focuses on the number of target keywords in the post, the number of internal links, call-to-action in the post, and ensuring keywords are not repeated too often.  For image optimization, the post is viewed to ensure at least one image is in the post and that the image has Alt text.  The meta optimization evaluates three things – the length of the meta description, the number of keywords in the URL, and the number of keywords in the meta description.\n")
                    Text("The analysis reports generated from these various tools (the marketing grader, the SEO reports, and the site analysis tools) provide the firm with an assessment of the website, its blog, and an overview of its current online and social media presence.  Marketing managers now can have an objective rating of their firm’s website, the blog, and social network sites as well as clear directions to enhance the firm’s digital marketing efforts.\n")
                } // Section 5
//                .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13.7: Marketing Grader Report – Part 2: Performance")) {
                    Image(uiImage: UIImage(named: "Figure-13-7.jpg")!)
//                    Image(name: "Figure-13-7.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Part 5 of the marketing grader report (shown in Figure 13-8) focuses on security and recommendation for improvement.  This assessment looks for security in terms of SSL certificate and specific improvement suggestions for better website experience for the users.\n")
                Text("Figure 13.8: Marketing Grader Report – Part 5: Security and What to Do Next")
                    Image(uiImage: UIImage(named: "Figure-13-8.jpg")!)
//                    Image(name: "Figure-13-8.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Nibbler.com is another free website grader tool available for marketing managers (see Figure 13-9).  Marketing managers can input the website address to get the report.\n")
                    } // Section 7
//                    .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                Section(header: Text("Figure 13-9: Nibbler.com Page")) {
                    Image(uiImage: UIImage(named: "Figure-13-9.jpg")!)
//                    Image(name: "Figure-13-9.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Nibbler reports on four main areas of websites that are accessibility, experience, marketing, and technology (see Figure 13-10).  For each of the four main areas, Nibbler provides sub component ratings that make up the four main areas.  Marketing managers can use this tool by visiting Nibbler’s home page and typing in the firm’s website address.  Nibbler marketing grader provides a score from 1 to 10 for each area and tests that make up an area.  This tool provides more specific information about what needs to be done and prioritize the areas that need improvement. \n")
                    Image(uiImage: UIImage(named: "Figure-13-10.jpg")!)
//                    Image(name: "Figure-13-10.jpg")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                        .padding(.top, 20)
                        .padding(.bottom, 30)
                    Text("Similar to Nibbler, Woorank also provides an overall grade ranging from 1 to 100 (see Figure 13-11).\n")
                        } // Section
//                    .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                // ----------------------
                     Section(header: Text("Figure 13-11: Woorank Report ")) {
                        Image(uiImage: UIImage(named: "Figure-13-11.jpg")!)
//                        Image(name: "Figure-13-11.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                        Text("Woorank also provides detailed information in the form of checklist of things needed to be done on each of the key areas of SEO, Mobile, Usability, and Technologies.  For example, Figure 13 -2 shows the detailed SEO report from Woorank.\n")
                        Image(uiImage: UIImage(named: "Figure-13-12.jpg")!)
//                        Image(name: "Figure-13-12.jpg")
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .padding(.top, 20)
                            .padding(.bottom, 30)
                            } // Section
//                        .listRowBackground(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.2000)))
                    // ----------------------
                } // List - text
            .padding(30)
                    .font(.system(size: 22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
//                    .background(Color(UIColor(red: 0.4551, green: 0.9922, blue: 1.0000, alpha: 0.4000)))
            .navigationBarTitle("13.2 Digital Sites Rating Analytics", displayMode: .inline)
            } // NavigationView
            .navigationViewStyle(StackNavigationViewStyle())
        } // VStack 2
        // ------------------------------
        // SECTION 2: End
        // ------------------------------
    } // body
} // struct
