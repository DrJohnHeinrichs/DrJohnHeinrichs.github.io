//
//  C06S02T04.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 4: Naïve Bayes Classifier
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S02T04: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure61Sheet1 = false
    @State private var showingTable61Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 4: Start --- Naïve Bayes Classifier
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.2.4 Naïve Bayes Classifier").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Probabilistic Classification")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The Naïve Bayesian classification is a probabilistic classification method.  It calculates the probabilities for each possible state of the input attribute given each state of the predictable attribute.  The Naïve Bayes algorithm builds data-mining models that can be used for classification and for prediction.  This data-mining algorithm supports only discrete attributes and it considers all input attributes to be independent.  The Naïve Bayes data-mining algorithm produces a simple mining model.  As such, this model is considered to be a starting point in the data-mining investigation process and can be coupled with other data-mining models.  The results from the data-mining model are returned to the marketing manager relatively quickly because most of the required calculations are already created in the cube processing.  Therefore, the Naïve Bayes data-mining model can be considered a relatively good option for exploring data and for discovering how various input attributes are distributed in the different states of the predicted attribute.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Classifier")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The Naïve Bayes Classifier is considered as an unrestricted version of the complete Bayesian classifier.  Both classifiers incorporate the concept of conditional probability that is the probability of event A given that event B has occurred.  This conditional probability is notes as P (A | B).  Using this conditional probability concept, the probability of record belonging to class Ci given with the predictor values of X1, X2, - - - , Xn can be computed as P (Ci | X1, X2, - - - , Xn).  To classify a record, the conditional probability of belonging to each of the classes is computed first.  Using these conditional probabilities, a record is classified to a class that has the highest probability or meets the cutoff probability.  Instead of restricting the probability calculation to those records that match the record to be classified done in complete Bayesian classifier, the Naïve Bayes method uses the entire dataset for the conditional probability calculation.  For class C1, the Naïve Bayes method estimates the individual conditional probabilities for each predictor P (Xi | C1) and then multiplies these probabilities with the proportion of records belonging to that class to generate the calculated probability for a class.  This process is repeated for all classes.  This method then calculates a probability for every class by dividing the calculated probability for each class with the sum of the calculated probabilities for all classes.  A new record is assigned to the class with the highest probability for the predictor variables of that record.  Marketing managers can also use a set cutoff level of probability to assign a new record to the class.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.2 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 4: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
