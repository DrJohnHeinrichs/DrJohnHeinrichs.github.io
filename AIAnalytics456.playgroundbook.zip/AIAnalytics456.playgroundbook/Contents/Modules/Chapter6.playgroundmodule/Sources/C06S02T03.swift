//
//  C06S02T03.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 3: Neural Nets
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S02T03: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure66Sheet1 = false
    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 3: Start --- Neural Nets
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.2.3 Neural Nets").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Neural Networks")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Neural networks are a data-mining approach that can be used in the high-end data-mining environment.  This technique utilizes various predictive algorithms.  As such, neural networks are a process of pattern recognition and error minimization.  They take in information and learning from each experience.  Then, they create models based upon evaluation of the data using trial-and-error techniques.  The neural network determines the answer or outcome of a defined problem then compares its answer to the actual outcome.  If the neural network data-mining model is incorrect, the neural network algorithm attempts to alter its rules to obtain a correct answer.  This process is repeated continually.  Neural networks are commonly used for classification and pattern recognition.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Nodes")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Neural networks are made up of nodes that are arranged in various layers.  Each node consists of inputs and their respective weights or probabilities, a processing layer with a summation and/or transformation function, and an output value.  The simple process is then to take data as input, process it according to various rules, and then guess at an answer.  The inputs may come from a variety of sources each with a specified weight representing that particular input’s current level of importance in the mining model.  The higher the value of the weight, the greater the importance that input has on the model.  These weights can be positive or negative.  The negative weights are to inhibit the input from affecting the algorithm.  If the input is deemed important enough, the input attribute is passed along to the next layer.  The processing layer potentially consists of a mathematical algorithm or other form of data transformation or summation function.  The results from the application of this function are sent to the output layer.  The output layer accepts this continuous value to determine the degree of weight to the answer.  Neural networks incorporate intensive program architectures or algorithms in attempting to identify linear, non-linear and patterned relationships in the firm’s data thus enabling the marketing manager to obtain generalized results from specific context.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Advantages / Disadvantages")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Neural networks offer a variety of advantages and disadvantages.  The advantage of utilizing neural networks typically is in their ability to pick up non-linear relationships presented in the data and flexibility in dealing with various types of data with high accuracy in making predictions.  The neural network mining model is designed to improve with use and adapt to the changing environment.  Additionally, the neural network can define a three-dimensional node structure, unlike the decision tree data-mining algorithm.  A disadvantage of neural networks is the tendency of the algorithm to over-fit the data.  The model can contain too many hidden layers enabling the algorithm to effectively memorize the various cases which would render the model ineffective for use in prediction of other, new cases.  Another disadvantage of neural networks is that they are hard to interpret as the system cannot explain its rationale; so, it is difficult for the marketing manager to explain.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Data-Driven Models")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Neural networks are flexible data-driven models for classification and prediction.  Neural networks combine the input data in a flexible way to capture complicated relationships among response and predictor variables.  Figure 6-6 shows one common type of neural network used for classification and prediction.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Layers")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Figure 6-6 depicts networks that are consisted of input, hidden, and output layers.  Input layer is consisted of nodes called neurons that accept the input values.  The outputs of nodes in each layer are inputs to nodes in the next layer.  Hidden layers are any layers between the input and output layers.  Output layer is the last layer in the networks.  The networks do not require specification of correct form of predictor and response variable relationships.  Linear regression and logistic regression are special cases of neural networks where there exist no hidden layers and only one output node with specified functional form of relationships between predictor and response variables.\n").padding(10)
                        } // Section 5
                        // ----------------------
                        // ----------------------
                        Section (header: Text("Figure 6-6: Neural Networks (where Wij are weights and Oij are node bias values)"))
                            {
                            Image(uiImage: UIImage(named: "Figure-6-6.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                // .frame(width: geo.size.width)
                                // .frame(width: UIScreen.main.bounds.width, height: 200)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 6-6: Neural Networks (where Wij are weights and Oij are node bias values)") {
                            self.showingFigure66Sheet1.toggle()
                        }
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure66Sheet1) {
                            Figure66View1()
                        }
                        .padding(10)
                        } // Section 5-1
                        // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Input Layer")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In neural networks, if there are n predictors, the input layer will have n nodes.  Figure 6-6 shows a two-predictor case showing two nodes.  For neural network estimation, input data pre-processing is needed.  Typically, all input variables are scaled to 0 and 1 before entering them into the network.  Continuous variables are normalized to scales of 0 and 1.  Categorical variables are converted to dummy variables.  In neural networks, the network estimates wij and Oij, and then uses the errors Oij to update the estimated weights wij iteratively to obtain the best predictive solutions.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.2 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 3: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 6-6 VIEW
// ------------------------------
struct Figure66View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-6: Neural Networks (where Wij are weights and Oij are node bias values)")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-6.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
