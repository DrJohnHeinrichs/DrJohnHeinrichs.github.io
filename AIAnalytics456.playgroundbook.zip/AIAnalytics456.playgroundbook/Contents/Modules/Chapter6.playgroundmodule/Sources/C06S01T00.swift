//
//  C06S01T00.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 1: Market Targeting Analytics Task
//
//  Created by SBAMBP on 04/08/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S01T00: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.1.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Identify Markets or Segments")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In market segmentation, targeting, and positioning decisions, it is important to identify specific product markets or segments showing exceptional growth or decline.  The important task of marketing managers is to select which segments the firm will indeed target.  A firm should choose an option that serves best to the structure of their firm.  Obviously, a small firm will not be able to cover the entire market or perhaps even provide several products.  However, a large firm, on the other hand, may be able to do whatever it wants.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Questions")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("To select the right target markets for the firm’s products, marketing managers may ask questions such as “Which market segment should we target for the new and existing products?” or “Who are those that belongs to the selected target markets?” or “How can we know a potential customer that follows the behavioral pattern or responses of different target market segments?” Marketing managers need to generate analytic solutions to these analytic questions.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Direct Marketing Activities")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers face the task of target marketing that involves directing marketing activities to those customers who are most likely to respond.  With the increased adoption of customer relationship management tools, firms are required to build and maintain customer databases.  These databases keep the detailed records of customers and can be combined with other relevant data to be used for targeting.  Targeting involves selecting customers who are worth pursuing and more valuable than others.  To resolve this targeting task, marketing managers need to ask analytic questions that are related to identification and selection of profitable customers.  Marketing managers want to know who are profitable customers and who are more likely to respond to their firm’s marketing efforts.  They are interested in classifying customers into classes such as most profitable to least profitable customers and predicting responses to marketing activities such as promotions.  Marketing managers also want to identify factors that determine the responses such as product purchases.  Targeting decisions are related to analytic questions of how to classify customers and predict the class category of new or potential customers who share similar response and behavior patterns.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.1 Market Targeting Analytics Task", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
