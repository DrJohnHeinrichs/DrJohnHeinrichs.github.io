//
//  C06S02T00.swift
//  Book_Sources
//
//  Chapter 6: Classification Tools for Market Targeting Analytics
//  Section 2: Classification and Prediction Analytic Solution Generation
//
//  Created by SBAMBP on 04/16/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C06S02T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure61Sheet1 = false
    @State private var showingTable61Sheet1 = false

    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("6.2.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Classification and Prediction Steps")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("To answer the analytic questions related to targeting decisions, marketing managers can select classification and prediction analytic tools from the analytics toolbox.  The classification and prediction analytic tools include several specific analytic procedures.  In applying these specific analytic procedures, marketing managers need to follow several steps.  Figure 6-1 shows these steps which are required to apply these analytic procedures to a firm’s databases.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    // ----------------------
                    Section (header: Text("Figure 6-1: Five Steps for Classification and Prediction Analytic Procedures"))
                        {
                        Image(uiImage: UIImage(named: "Figure-6-1.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Figure 6-1: Five Steps for Classification and Prediction Analytic Procedures") {
                        self.showingFigure61Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure61Sheet1) {
                        Figure61View1()
                    }
                    .padding(10)
                    } // Section 5-1
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Step 1: Method")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The first step is to select the appropriate classification and prediction method.  The selection depends on the analytic questions marketing manager are facing.  Marketing managers need to consider analytic purpose, type of responses, and type of predictor variables determining the responses.  Table 6-1 presents four most commonly used specific methods and when they can be selected by marketing managers.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    // ----------------------
                    Section (header: Text("Table 6-1: Four Most Commonly Used Classification and Prediction Method"))
                        {
                        Image(uiImage: UIImage(named: "Table-6-1.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Table 6-1: Four Most Commonly Used Classification and Prediction Method") {
                        self.showingTable61Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable61Sheet1) {
                        Table61View1()
                    }
                    .padding(10)
                    } // Section 5-1
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Response Variables")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The specific method selection decision should be made by considering the nature of input data, analytic purpose at hand, and availability of analytical tool in the firm.  As shown in Table 6-1, all four specific methods can be used for classification.  Other than Naïve Bayes, prediction can be made using the remaining three methods.  In applying these modeling techniques, marketing managers need to evaluate response and predictor variables.  Response variables are the outcome variables firms are pursuing with target marketing activities.  For example, response variables can be product purchase, clicking the banner ads, sales amount, sales volume, or customer lifetime value.  The response variable can be a continuous variable such as sales amount or a categorical variable such as purchase versus no purchase.  All four methods can take a categorical response variable.  Other than Naïve Bayes, the other three methods can also take a continuous response variable.  Predictor variables are variables that determine the response variables.  Predictor variables can be continuous or categorical.  Common predictor variables include demographics, behavioral variables, psychographics, and lifestyle variables that are typically stored in customer database by consumer product firms.  For business to business marketing firms, their customer database includes information such as size of the customer firm, industry type, geographic location, length of relationship, type of purchased product, and the past sales and support history.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Remaining Steps")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Step 2 in the process is to identify input data and split it into the training and validation datasets.  Typically, the training dataset includes about 60 to 70 percent of total data while the validation dataset includes the remaining data.  Step 3 and step 4 involves running the selected classification procedure to the training dataset and validation dataset.  Step 5 involves evaluating the obtained classification model and using it for classification and prediction.\n").padding(10)
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Methods")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Depending on the selected response and predictor variables and a firm’s database characteristics, the appropriate method can be selected by marketing managers.  These four methods have their own assumptions, advantages, and disadvantages in applying them to input data.  However, these four methods share the basic premise of classifying and/or predicting the response variable using the predictor variables.  These four methods differ in the way they classify and predict the response variables.  The next section describes each of these four methods.\n").padding(10)
                    } // Section 5
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("6.2 Classification and Prediction Analytic Solution Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 6-1 VIEW
// ------------------------------
struct Figure61View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 6-1: Five Steps for Classification and Prediction Analytic Procedures")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-6-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Figure 6-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// TABLE 6-1 VIEW
// ------------------------------
struct Table61View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 6-1: Four Most Commonly Used Classification and Prediction Method")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-6-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 6-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
