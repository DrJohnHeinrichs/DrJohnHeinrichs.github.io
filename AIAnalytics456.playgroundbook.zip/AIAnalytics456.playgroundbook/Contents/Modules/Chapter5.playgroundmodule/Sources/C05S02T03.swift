//
//  C05S02T03.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 2: Segment Clustering Analytics Generation
//
//  Created by SBAMBP on 04/14/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S02T03: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 3: Start --- Selected Clustering Procedures 
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The next decision marketing managers need to make in clustering analysis is choosing the clustering procedure.  Many alternative clustering procedures are available for forming the natural groups for customer or objects.  There exist three broad categories of procedures.  They are linkage procedures, nodal procedures, and factor procedures.  Among these, factor procedures are not often used due to its poor clustering performance.  The linkage and nodal procedures are introduced next.  The linkage procedures are considered as hierarchical clustering, while nodal procedures are known as iterative partitioning methods.  The most popular partitioning method is the k-means approach.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Text("Hierarchical Clustering Method").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("A hierarchical clustering method is driven by the linkage procedures.  It begins with treating each observation as its own cluster and then combines the two clusters most similar (least distance) into a single cluster.  Various methods are developed based on the criterion of allowing any member of a cluster to join a cluster.  The commonly used linkage methods include single linkage, complete linkage, average linkage, centroid linkage, median linkage, Ward’s method, and McQuitty’s method.  For example, single linkage method for a cluster based on a criterion that any member meets the pre-specified similarity level (distance) with any existing members of the cluster will be allowed to join the cluster.  In every iteration process, the pre-specified similarity level is changed to reduce the number of clusters.  In the complete linkage method, clustering is done using a criterion that a member must meet the pre-specified similarity level with every current member of the cluster to join that cluster.  Thus, different from the single linkage procedure, single bond (similarity) with just one current member of the cluster would not be sufficient for joining to that cluster.  Other procedures use average, centroid, median similarity level as a criterion for cluster membership.  The Ward’s method is used to minimize the loss of information between the individual observation and the cluster centroid.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Text("K-Means Clustering Method").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("K-means clustering is a type of non-hierarchical clustering algorithms.  This clustering method has been widely employed in marketing as it is more appropriate for large datasets that are common in marketing.  K-means clustering has the advantage of being more robust to different types of variables and less sensitive to outliers.  The weakness of this method is that the clustering performance depends on the accuracy of starting points used in the analysis.  In using k-means clustering, marketing managers must specify the number of clusters to be generated from the analysis.  The number of clusters can be determined based on the manager’s pre-conceived notion of market clusters or pure efficiency of clustering process.\n").padding(10)
                        Text("When marketing managers choose the number of clusters, k, as input to the analysis, the k-means algorithm assigns each observation (customer) to one of the k clusters and calculates the centroids (means) of each cluster.  A cluster centroid is the average of all the points in the cluster.  Using the calculated cluster centroid, all observations are reassigned to the nearest cluster centroid.  New cluster centroids are recomputed.  This process is repeated until there are no changes in clusters or a specified maximum number of iterations is reached.  As indicated earlier, the clustering performance depends on the initial assignment of cluster seeds.  To ensure the stability of clustering outcome, marketing managers can run the k-means clustering with different starting values.  They can also split the data into multiple subsets and evaluate whether the same sets of customers belong to the clusters.  It is necessary to estimate the reliability of a cluster solution across datasets.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.2 Segment Clustering Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
