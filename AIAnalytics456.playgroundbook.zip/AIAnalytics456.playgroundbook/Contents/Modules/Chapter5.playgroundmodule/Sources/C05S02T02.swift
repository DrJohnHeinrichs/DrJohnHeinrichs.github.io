//
//  C05S02T02.swift
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 2: Segment Clustering Analytics Generation
//
//  Created by SBAMBP on 04/14/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S02T02: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable51Sheet1 = false
    @State private var showingEquation51Sheet1 = false
    @State private var showingEquation52Sheet1 = false
    @State private var showingEquation53Sheet1 = false
    
    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0
    @GestureState var scale3: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 2: Start --- Compute Distance Estimates
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In computing distance estimates, marketing managers need to consider the measurement scale (e.g., nominal, ordinal, interval, and ratio scale) and measurement units of input variables.  When all input attributes are measured by interval or ratio scales, then distance function or a correlation coefficient can be used to estimate distances representing similarity.  When marketing managers decide to use a distance function, Euclidean distance is the most commonly used distance function as compared to the city-block distance or Mahalanobis distance.  While Euclidean distance is most popular, it is not scale invariant.  The Euclidean distance estimates may be influenced by the measurement scales of input variables.  To generate similarity coefficients that are less sensitive to the measurement units, standardized measures may be adopted for removing the sensitivity.  Standardization decisions should be made on a case-by-case basis.  If measurement units are roughly the same magnitude, standardization may not be needed.  Standardization can reduce the differences between groups on some variables that may well be the best discriminators.  However, if measurement units are widely different, standardization would be needed to reduce the dominating impact of variables measured in larger units on the cluster solution.  Standardization based on the range of each variable is preferred to converting the variables to z scores.  When dichotomous data are involved, some kind of matching coefficient or Jaccard’s coefficient can be used.  A matching coefficient typically represents the number of matches relative to the number of comparisons made between two objects or customers.  Jaccard’s coefficient does not count matching zero in similarity estimation and is used when matching zero does not mean similarity.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("In this section, the most commonly used distance measure, Euclidean distance, is presented.  The Euclidean distance between the observation u and v is calculated as follows:\n").padding(10)
                            Image("Equation-5-1.jpg")
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("For example, Table 5-1 shows sample data for cluster analysis.  The data shows the perceived importance score of three attributes measured by a seven-point rating scale.\n").padding(10)
                    // ----------------------
                    } // Section 3
                    // ----------------------
                    Section (header: Text("Table 5-1: Perceived Importance Score of Three Attributes"))
                        {
                        Image(uiImage: UIImage(named: "Table-5-1.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            // .frame(width: geo.size.width)
                            // .frame(width: UIScreen.main.bounds.width, height: 200)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Table 5-1: Perceived Importance Score of Three Attributes") {
                        self.showingTable51Sheet1.toggle()
                    }
                    .font(.caption)
                    .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable51Sheet1) {
                        Table51View1()
                    }
                    } // Section 5-1
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The Euclidean distance d between John and Sam would then be calculated as:\n").padding(10)
                            Image("Equation-5-2.jpg")
                    } // Section 4
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The first term in the Euclidean distance measure is the squared difference in perceived importance of outdoor activity between John and Sam.  Similarly, the second and third term is the squared difference in perceived importance of durability and price attribute between John and Sam.  The Euclidean distance, d, between John and Kathy and between Sam and Kathy would be calculated as:\n").padding(10)

                    GeometryReader { geo in
                        Image(uiImage: UIImage(named: "Equation-5-3.jpg")!)
                            .resizable()
                            .scaledToFill()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geo.size.width)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                                .updating(self.$scale2, body: { (value, scale2, trans) in
                                    scale2 = value.magnitude
                                })
                        )
                    } // Geometry Reader

//                        Image("Equation-5-3.jpg")
                    
                    GeometryReader { geo in
                        Image(uiImage: UIImage(named: "Equation-5-4.jpg")!)
                            .resizable()
                            .scaledToFill()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geo.size.width)
                            .scaleEffect(self.scale3)
                            .gesture(MagnificationGesture()
                                .updating(self.$scale3, body: { (value, scale3, trans) in
                                    scale3 = value.magnitude
                                })
                        )
                    } // Geometry Reader

//                        Image("Equation-5-4.jpg")
                    } // Section 5
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.2 Segment Clustering Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 5-1 VIEW
// ------------------------------
struct Table51View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 5-1: Perceived Importance Score of Three Attributes")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-5-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
                }
            // ----------------------
            Button("Finished: Table 5-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
