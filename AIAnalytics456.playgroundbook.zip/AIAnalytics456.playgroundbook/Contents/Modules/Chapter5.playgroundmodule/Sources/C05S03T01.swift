//
//  C05S03T01.swift
//  Book_Sources
//
//  Book_Sources
//
//  Chapter 5: Clustering Tools for Market Segment Analytics
//  Section 3: Clustering Analytics Interpretation and Application
//
//  Created by SBAMBP on 04/14/2020
//  Updated by SBAMBP on 04/15/2020
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C05S03T01: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure52Sheet1 = false
    @State private var showingFigure53Sheet1 = false
    
    @GestureState var scale1: CGFloat = 1.0
    @GestureState var scale2: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 1: Start --- Hierarchical Clustering Analytics Interpretation and Application
        // ------------------------------
        NavigationView {
            ScrollView {
            // ----------------------
            // ----------------------
            // ----------------------
                Section {
                // ----------------------
                    // ----------------------
                    // -- Section 01
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("To present the iterative aggregation process in the hierarchical clustering procedure, a dendrogram is generated as a typical part of the clustering solution.  A dendrogram summarizes the set of nested clusters resulting from iterations of the aggregation process.  A dendrogram is a tree diagram that indicates the groups of customers or objects forming at various similarity (distance) levels.  A dendrogram example of customers is shown in Figure 5-2.\n").padding(10)
                        } // End Section 01
                    // ----------------------
                    // ----------------------
                    // ----------------------
                    // ----Section Figure 5-2
                    Section (header: Text("Figure 5-2: Dendrogram Example of Customer Data Using Single Linkage"))
                            {
                            Image(uiImage: UIImage(named: "Figure-5-2.jpg")!)
                                .resizable()
                                .scaledToFit()
                                .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 400, height: 200)
                                .scaleEffect(self.scale1)
                                .gesture(MagnificationGesture()
                                .updating(self.$scale1, body: { (value, scale1, trans) in
                                    scale1 = value.magnitude
                                    })
                                )
                                .padding(.bottom, 30)
                        // ----------------------
                        Button("Click to highlight ... Figure 5-2: Dendrogram Example of Customer Data Using Single Linkage") {
                            self.showingFigure52Sheet1.toggle()
                            } // Button
                            .font(.caption)
                            .foregroundColor(.blue)
                        .sheet(isPresented: $showingFigure52Sheet1) {
                            Figure52View1()
                                } // sheet
                        } // Section Figure 5-2
                    // ----------------------
                    // ----------------------
                    
                    
                    
                    // ----------------------
                    // --------Section Text
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        Text("In Figure 5-2, customers A through J are shown on the horizontal axis and the vertical axis represents the distance level resulting from a merger of the two different groups of customers.  The levels at which groups join to form larger groups are shown in Figure 5-2.  To determine natural groups based on the Figure 5-2, marketing managers need to select the similarity level to be used.  For example,\n").padding(10)
                            Image("Group-5-1.jpg")
                        } // Section Text
                    // ----------------------
                    // ----------------------
                    
                    
                    // ----------------------
                    // ----------------------
                    // -------Section 3 Text
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Depending on the distance level used, the number of clusters is determined.  In deciding the number of clusters, a plot capturing the number of clusters against the fusion coefficients can be used.  The fusion coefficient represents the numerical values at which various customers merge to form clusters.  Figure 5-3 shows such a plot where y-axis shows the number of clusters and x-axis shows the fusion coefficient.  Using this plot, marketing managers can choose the number of clusters of customers in segmenting the market considering the fusion coefficient.\n").padding(10)
                        // ----------------------
                        Text("The hierarchical methods tend to have problems when the data contains an error.  In addition, the decisions made early in the clustering process can have large effects on the final outcome.  As all clustering process can have large effects on the final outcome.  As all clustering methods have common objective, these methods can be considered as complementary rather than exclusive.  For example, the output of the hierarchical clustering can be used to determine the starting points of node-based approach to be presented next.\n").padding(10)
                        } // Section 3 Text
                    // ----------------------
                    // ----------------------
                    // ----------------------


                    // ----------------------
                    // -------Section 4 Image
                    Section (header: Text("Figure 5-3: Plot of Number of Clusters and Fusion Coefficient"))
                        {
                        Image(uiImage: UIImage(named: "Figure-5-3.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale2)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale2, body: { (value, scale2, trans) in
                                scale2 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Figure 5-3: Plot of Number of Clusters and Fusion Coefficient") {
                        self.showingFigure53Sheet1.toggle()
                        } // Button
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingFigure53Sheet1) {
                        Figure53View1()
                        } // Sheet
                        } // Section 4 Image
                    // ----------------------
                    // ----------------------
                    .padding(10)
                    // ----------------------


                // ----------------------
                // ----------------------
                // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            // ----------------------
            // ----------------------
            // ----------------------
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("5.3 Clustering Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 5-2 VIEW
// ------------------------------
struct Figure52View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            
            
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 5-2: Dendrogram Example of Customer Data Using Single Linkage")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-5-2.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            } // Section
            // ----------------------
            Button("Finished: Figure 5-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 5-3 VIEW
// ------------------------------
struct Figure53View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 5-3: Plot of Number of Clusters and Fusion Coefficient")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Figure-5-3.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            } // Section
            // ----------------------
            Button("Finished: Figure 5-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
