//
//  C04S02T04.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 04: Trend Visualization Chart Type
//
//  Created by SBAMBP on 04/12/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T04: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 4: Start --- Trend Visualization Chart Type
        // ------------------------------
        NavigationView {
            List {
                Text("4.2.4 Trend Visualization Chart Type").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                Text("Two types of trend visualization chart types include both line charts and area charts.").padding(10)
                    // ----------------------
                    NavigationLink(destination: LineChart()){
                        Text("LineChart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: AreaChart()){
                        Text("AreaChart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 2: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: LINE CHART
// ------------------------------
public struct LineChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            ScrollView {
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Line Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Line charts are one of the most commonly used visualization charts for time series data with time as the x-axis.  Line charts show linear trend or non-linear relationships between two variables and provide time-dependent changes with the values of y-axis of interest.  A linear trendline is a straight line through the available data.  This type of trendline is appropriate, if upon visual inspection, the available data points appear to form a line.  A linear trendline is used by the marketing manager to demonstrate that the variable under investigation is increasing or decreasing at a steady rate.  Managers can track changes or trends over time.  Trendlines can be added to the graphical or data analysis to provide the manager with information that can be used for forecasting.  The trendline uses the statistical tool of regression to predict the values of the variable of interest in a future time period.  Regression analysis estimates the relationship among various variables and is used to predict another variable.\n").padding(10).fixedSize(horizontal: false, vertical: true)
                    Text("A logarithmic trendline is a curved line.  It is used by the marketing manager when the variable of interest produces a data pattern that shows a rate of change in that either increases or decreases rapidly and then levels out.  A polynomial trendline is also a curved line.  A polynomial trendline should be chosen when the marketing manager notices that the data pattern fluctuates.  The order option associated with the polynomial trendline can be changed.  The option can be increased or decreased based upon the number of fluctuations or changes in direction found in the dataset.  The fluctuations can be ascertained by examining how many bends appear in the curve produced by the data pattern.  A power trendline is a curved line that is used when the data points increase at a specific rate.  An exponential trendline is a curved line that is used when the data points appear to increase or decrease at increasingly higher rates.  A moving average trendline is used to smooth out the fluctuations in the data pattern.  It is used in forecasting to show the data trend more clearly.  The concept behind a moving average is that the algorithm uses a specific number of data points, then averages those data values, and then uses these averaged values as a point in the moving average trendline.  The moving average algorithm has a period option that can increase or decrease.  This option specifies how many data values are averaged.  For example, if the period option is set to three, the average of the first three data values is used as the initial point in the trendline.  Then, the second, third, and fourth data point are averaged and this value is used as the second point in the moving average trendline.\n").fixedSize(horizontal: false, vertical: true).padding(10)
                } // Section 1
            } // ScrollView - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: AREA CHART
// ------------------------------
public struct AreaChart: View {
    @Environment(\.presentationMode) var presentationMode
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Area Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Area charts are used to display quantitative data by emphasizing the area between axis and line with colors.  Area charts are used to compare two or more quantities representing cumulative totals using numbers or percentages over time.  Area charts can show trends over time among related variables.\n").padding(10).fixedSize(horizontal: false, vertical: true)
                } // Section 1
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
