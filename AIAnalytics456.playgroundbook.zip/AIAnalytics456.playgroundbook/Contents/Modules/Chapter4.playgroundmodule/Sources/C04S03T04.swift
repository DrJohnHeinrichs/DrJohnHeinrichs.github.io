//
//  C04S03T04.swift
//  Book_Sources
//
//  Chapter 04 Section 03: Topic 04: Trend Chart Application
//
//  Created by SBAMBP on 04/13/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S03T04: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure412Sheet1 = false
    @State private var showingFigure413Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 4: Start --- Trend Chart Application
        // ------------------------------
        NavigationView {
            ScrollView {
                    // ----------------------
                    Text("4.3.4 Trend Chart Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Trend Analysis")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers need to visualize the trend of relationship.  They are interested in visualizing the change, rise, increase, fluctuation, growth, decline, decrease, and trend of a measure over time.\n\nFigure 4-12 shows trend analysis for the gross sales of a firm’s products.  In this case, the target metric used for this chart is one revenue measures of sales.  The y-axis represents the sales amount.  The line color was used to represent the visual difference among customer types.  The x-axis shows the classification metric representing the time dimension of month.  The chart shows that gross sales through brokers are increasing at a high rate, while direct sales are increasing but at a much slower rate.  Interestingly, distributors’ sales are showing a downward trend.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-12: Trend Analysis of Distribution Channels") {
                            self.showingFigure412Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure412Sheet1) {
                            Figure412View1()
                        }
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Sales Growth")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Figure 4-13 shows the fastest growing firms in the industry.  In this chart, the target metric used is one revenue measure of gross sales.  The y-axis represents the gross sales amount.  The line color was used to represent the visual difference among competitors.  The x-axis shows the classification metric representing the time dimension of quarter.  The classification metric used is the time dimension of quarter.  The chart shows the top ten fastest growing firms in the U.S. market and their sales growth rate.  These firms can be evaluated for their product offerings and market areas for present and future competitive situations.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-13: Sales Growth Trend of Competitors") {
                            self.showingFigure413Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure413Sheet1) {
                            Figure413View1()
                        }
                    } // Section 2
                    // ----------------------
            } // ScrollView -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.3 Visualization Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 4: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 4-12 VIEW
// ------------------------------
struct Figure412View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-12: Trend Analysis of Distribution Channels")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-12.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-12 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-13 VIEW
// ------------------------------
struct Figure413View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-13: Sales Growth Trend of Competitors")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-13.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-13 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
