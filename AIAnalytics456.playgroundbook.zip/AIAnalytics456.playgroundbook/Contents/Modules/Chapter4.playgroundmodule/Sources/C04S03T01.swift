//
//  C04S03T01.swift
//  Book_Sources
//
//  Chapter 04 Section 03: Topic 01: Comparison Chart Application
//
//  Created by SBAMBP on 04/13/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S03T01: View {
    var topicTitle: String = "Topic Title"

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 1: Start --- Comparison Chart Application
        // ------------------------------
        NavigationView {
            List {
                    // ----------------------
                    Text("4.3.1 Comparison Chart Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Overview")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Comparison visualization can be made using various comparison patterns.  These patterns include part to whole, ranking, deviation, and distribution.  The next section shows how each pattern is typically applied and presents an illustrative example of each visualization analytics pattern.").padding(10)
                    } // Section 1
                    // ----------------------
                    NavigationLink(destination: PartToWholeChart()){
                        Text("Part to Whole Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: RankingChart()){
                        Text("Ranking Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
                    NavigationLink(destination: DeviationChart()){
                        Text("Deviation Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                    }
                    // ----------------------
                    NavigationLink(destination: DistributionChart()){
                        Text("Distribution Chart")
                        .italic()
                        .foregroundColor(.blue)
                        .font(.system(size: 18, weight: .heavy, design: .default))
                        .padding(10)
                        }
                    // ----------------------
            } // List -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.3 Visualization Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 1: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TOPIC: PART TO WHOLE CHART
// ------------------------------
public struct PartToWholeChart: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingFigure41Sheet1 = false
    @State private var showingFigure42Sheet1 = false
    @State private var showingFigure43Sheet1 = false

    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Part to Whole Chart - 1")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Marketing managers may want to visualize the pattern of part to whole.  They are interested in the rate of total of a measure, percent or percentage of total share of a measure, or which level or component of a measure account for another measure.  Commonly used charts for this pattern are stacked column, stacked area, or pie chart.").padding(10)
                    Text("Figure 4-1 shows a stacked column chart describing the sales force efficiency measures across different geographical market.  In this case, the target metrics used for this chart are one revenue measure of gross sales and one marketing expenditure measure of sales expense shown in Table 4-7.  The y-axis shows the gross sales and sales expense amount.  The x-axis shows the classification metrics representing the market regions of East, Midwest, South, West, and Key accounts.  The color and bar pattern fill were used to represent the visual difference between gross sales and sales force expenses.  The Figure 4-1 chart evaluates sales force cost as a percentage of total sales for different markets of the firm.  The bar chart shows that sales force cost ranges from 0.7 percent to 4.6 percent.  The Midwest region shows the highest sales expense of 4.6 percent while the Eastern region posts the lowest expense rate of 0.7 percent.  The South region shows 2.1 percent, followed by the West region with 1.3 percent and Key accounts of 1.1 percent.  Interestingly for this firm, the Midwest region generates the most sales revenue with the South region generating the second most sales.  Based on the sales expense ratio, this firm needs to reevaluate both the optimal sales force size and the optimal allocation of sales force effort across regions and key accounts.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-1: Stacked Bar Chart") {
                        self.showingFigure41Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure41Sheet1) {
                        Figure41View1()
                    }
                } // Section 2
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Part to Whole Chart - 2")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Figure 4-2 shows a pie chart that evaluates the proportion of the promotional budget expended for the four most heavily used tools for this company.  The target metric is promotional expense in dollars and the classification metric is the promotional tool type.  The color and pie pattern fill were used to provide the visual representation of the different promotional tools used.  With the given total promotional budget, firms are allocating their promotional budget over different promotional tools.  The Figure 4-2 pie chart visualizes that consumer promotion is most heavily used with 54.5 percent.  Sales force is the second most heavily used with 32.9 percent.  Advertising is 11.0 percent, followed by the free goods program with 1.6 percent.  This visualization analytics provides marketing managers a tool to assess promotional efficiency of various promotional tools in different market segments.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-2: Promotion Budget Pie Chart") {
                        self.showingFigure42Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure42Sheet1) {
                        Figure42View1()
                    }
                } // Section 3
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Part to Whole Chart - 3")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Figure 4-3 presents a pie chart that evaluates the profitability of each channel alternative.  In this case, the target metric used for this chart is one revenue measure of operating profit before overhead shown in Table 4 7.  The classification metric is the channel dimension measure representing channel members such as brokers, direct, distributors, and internet customers.  The color and pie pattern fill were used to provide the visual representation of the different channel members.  The chart shows that brokers generated $123.6 million in operating profits, followed by direct channels with $29.6 million.  Distributors generated $20.3 million in net profits with the Internet customers generating $9.6 million in operating profits.  The chart illustrates an application of the net profit model component to a real database.  The Figure 4-3 uncovers insights for the channel managers showing which channel alternatives generate operating profits and which channel operates efficiently compared to other channel choices.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-3: Operating Profit Pie Chart") {
                        self.showingFigure43Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure43Sheet1) {
                        Figure43View1()
                    }
                } // Section 4
                // ----------------------
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: RANKING CHART
// ------------------------------
public struct RankingChart: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingFigure44Sheet1 = false
    @State private var showingFigure45Sheet1 = false

    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Ranking Chart - 1")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Marketing managers may want to visualize the pattern of ranking.  They are interested in which is larger, smaller, equal to, greater than, or less than other levels or components of the same measure for another measure.  The commonly used chart type is sorted bar or column chart.").padding(10)
                    Text("Figure 4-4 presents a sorted column chart that shows how competitors are performing in the market.  In this case, the target metric used for this chart is sales growth measure calculated from previous sales measures of key competitors.  The y-axis shows the sales growth and the x-axis shows the classification metric representing the key competitors.  The chart shows the ten largest competitors in the U.S. market sorted by the size of gross sales.  The quarterly data shows how each major competitor fared in the market in terms of gross sales.  The two largest competitors, Colgate-Palmolive Company and Avon Products, are showing a moderate decline in gross sales growth while the third largest competitor, Estee Lauder Company Inc., showed a slight growth in gross sales.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-4: Sales Growth Bar Chart") {
                        self.showingFigure44Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure44Sheet1) {
                        Figure44View1()
                    }
                } // Section 2
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Ranking Chart - 2")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Figure 4-5 presents a bubble chart showing how market segment growth can be assessed.  The chart shows the cost of serving the market segment in the y-axis and market growth rate of the planning period in North America region in the x-axis.  The size of the market is represented by the size of the bubble.  The color of the bubble represents different market segment types.  According to the chart, single family replacement market offers the best potential for growth as well as the lowest cost to serve the market.  Therefore, marketing managers should pay special attention and develop a targeted marketing strategy for this most important segment.  Using this type of chart, marketing managers can generate insights and use them in making marketing decisions.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-5: Market Segment Growth Chart") {
                        self.showingFigure45Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure45Sheet1) {
                        Figure45View1()
                    }
                } // Section 3
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: DEVIATION CHART
// ------------------------------
public struct DeviationChart: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingFigure46Sheet1 = false
 
    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Deviation Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Marketing managers need to visualize the pattern of distribution.  They are interested in the frequency, distribution, range, or concentration of a measure.  The commonly used charts are the box plot or histogram.").padding(10)
                    Text("Figure 4-7 presents a bar chart showing the ten largest market segments in terms of gross sales.  In this case, the target metric used for this chart is one revenue measure of gross sales shown in Table 4-7.  The x-axis shows the gross sales amount.  The classification metrics is the distributors in each city that represents a market dimension.  The y-axis shows the classification metric representing the market city.  In market segmentation, targeting and positioning decisions, it is important to identify specific product markets or segments showing exceptional growth or decline.  Two Midwest cities, Cincinnati and Toledo, and a southern city, Tampa, represent a majority of the largest product market segments.  Similarly, the smallest product-market segments can also be identified").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-6: Sales Growth Comparison Bar Chart") {
                        self.showingFigure46Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure46Sheet1) {
                        Figure46View1()
                    }
                } // Section 2
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------
// TOPIC: DISTRIBUTION CHART
// ------------------------------
public struct DistributionChart: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showingFigure47Sheet1 = false

    public var body: some View {
            // ----------------------
            VStack{
                // ----------------------
                Section (header: HStack {
                    Image(systemName: "pencil")
                    Text("Distribution Chart")
                        .font(.system(size: 20, weight: .heavy, design: .default))
                    } )
                    {
                    // ----------------------
                    Text("Marketing managers need to visualize the pattern of distribution.  They are interested in the frequency, distribution, range, or concentration of a measure.  The commonly used charts are the box plot or histogram.").padding(10)
                    Text("Figure 4-7 presents a bar chart showing the ten largest market segments in terms of gross sales.  In this case, the target metric used for this chart is one revenue measure of gross sales shown in Table 4-7.  The x-axis shows the gross sales amount.  The classification metrics is the distributors in each city that represents a market dimension.  The y-axis shows the classification metric representing the market city.  In market segmentation, targeting and positioning decisions, it is important to identify specific product markets or segments showing exceptional growth or decline.  Two Midwest cities, Cincinnati and Toledo, and a southern city, Tampa, represent a majority of the largest product market segments.  Similarly, the smallest product-market segments can also be identified").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-7: Market Segment Sales Chart") {
                        self.showingFigure47Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure47Sheet1) {
                        Figure47View1()
                    }
                } // Section 2
            } // VStack - inner
            // ----------------------
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
// ------------------------------
// FIGURE 4-1 VIEW
// ------------------------------
struct Figure41View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-1: Stacked Bar Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-1.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-2 VIEW
// ------------------------------
struct Figure42View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-2: Promotion Budget Pie Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-2.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-2 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-3 VIEW
// ------------------------------
struct Figure43View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-3: Operating Profit Pie Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-3.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-3 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-4 VIEW
// ------------------------------
struct Figure44View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-4: Sales Growth Bar Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-4.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-4 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-5 VIEW
// ------------------------------
struct Figure45View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-5: Market Segment Growth Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-5.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-5 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-6 VIEW
// ------------------------------
struct Figure46View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-6: Sales Growth Comparison Bar Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-6.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-6 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-7 VIEW
// ------------------------------
struct Figure47View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-7: Market Segment Sales Chart")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-7.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-7 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
