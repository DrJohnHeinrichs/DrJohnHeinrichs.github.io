//
//  C04S02T00.swift
//  Book_Sources
//
//  Chapter 04 Section 02: Topic 00: Overview
//
//  Created by SBAMBP on 4/11/20.
//  Updated by SBAMBP on 4/14/20.
//
import UIKit
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg")
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S02T00: View {
    var topicTitle: String = "Topic Title"
    @State private var showingTable41Sheet1 = false
    
    @GestureState var scale1: CGFloat = 1.0

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // SECTION 0: Start --- Overview
        // ------------------------------
        NavigationView {
            ScrollView {
                Section {
                    // ----------------------
                    Text("4.2.0 Overview").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Analytic Tools")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("Marketing managers are facing the most common analytic questions and tasks related to understanding market trend, customer reactions relative to competition, and market performance.  For these analytic tasks, managers can choose various analytic tools from analytic toolbox.  The most commonly used analytic tool is data visualization for exploration.  Data visualization is the process of displaying the data in a manner such that marketing managers can interpret and understand the nature of data easily for better decision making.  Data visualization generates tables, charts, and reports to analyze and interpret data.  Data visualization facilitates marketing managers generate marketing insights to make analytics driven decision making.\n").padding(10)
                        Text("The marketing manager uses visual aid methodologies to analyze patterns and determine relationships in the data.  Numerical data can be combined and presented in a symbolic fashion using various charting techniques or the data may be contained in the image itself.  Visualization techniques are best used for monitoring a regular stream of incoming data.  The sequence of activities performed by the marketing manager in using data visualization techniques includes having the pattern “jump out” from the presented chart, determining what the axes of the chart represent, and determining what is the chart trying to say.  Therefore, it is important that the marketing manager uses the same chart format day in and day out.\n").padding(10)
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Key Goal")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("One of the key goals for data visualization is to capture elements of the application and display these elements to the marketing manager in a visual or image format.  Before discussing data visualization in great detail, it is important to classify the types of visualization.  The two broad categories of data visualization are analog visualization and symbolic visualization.  When trying to understand the analog visualization category, it is best to think of it as an image of the original object or a representation of that object; whereas the symbolic visualization category can be thought of as a chart or graph portraying numeric information in a predefined format.  For comparison purposes, maps can be thought of as a component in the analog visualization category and pie charts can be thought of as a component in the symbolic visualization category.\n").padding(10)
                    } // Section 2
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Symbolic Visualization")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("The symbolic visualization category uses charts or graphs to portray information.  There are a variety of different chart types which can be used for data visualization by the marketing manager.  These chart types include area charts, bar charts, and bubble charts.  Successful visualization using charting techniques requires a well-defined color scheme.  The most effective visualizations can be created using the basic charting capabilities.\n").padding(10)
                    } // Section 3
                    // ----------------------
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Visualization Objectives")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                            } )
                        {
                    // ----------------------
                    Text("Depending on the analytics questions identified, data visualization is performed for different objectives in mind.  There is no one simple way of visualizing a dataset.  How to explore and visualize data will be determined by focusing on the nature of analytic questions.  There are many different directions managers can take in exploring data.  Managers can aim to simply describe the pattern of data or highlight differences or relationships.  The objectives of data visualization can be classified into the following categories: comparison, relationship, tabulation, trend, and graphic display.  Depending on the analytic question, managers choose the appropriate visualization charts and tables.  Table 4-1 shows the specific chart and table types relevant for the various visualization objectives.  Some charts can answer certain type of questions better.  The next section describes each type of chart and table with examples that are commonly used in marketing analytics.\n").padding(10)
                    } // Section 5
                    
                    // ----------------------
                    Section (header: Text("Table 4-1: Visualization Charts and Tables"))
                        {
                        Image(uiImage: UIImage(named: "Table-4-1.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .shadow(color: .gray, radius: 10.1, x: 5.1, y: 15.1)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 200)
                            .scaleEffect(self.scale1)
                            .gesture(MagnificationGesture()
                            .updating(self.$scale1, body: { (value, scale1, trans) in
                                scale1 = value.magnitude
                                })
                            )
                            .padding(.bottom, 30)
                    // ----------------------
                    Button("Click to highlight ... Table 4-1: Visualization Charts and Tables") {
                        self.showingTable41Sheet1.toggle()
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    .sheet(isPresented: $showingTable41Sheet1) {
                        Table41View1()
                            }
                    } // Section 5-1
                    // ----------------------
                    
                    // ----------------------
                    // ----------------------
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("Chart versus Table")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("When marketing managers want to make a visual representation, they need to make two important decisions.  Those decisions are determining whether to use chart or table and which dimensions are to be included in visual representation.  The choice between a chart and table can be subjective.  The combination of table and chart can be also used.  The general rule for choosing a table over a chart is when marketing managers are interested in understanding precise, particular or individual values as well as a summary of measures.  In visual representation, marketing managers can use six dimensions in a chart.  These six dimensions include x-axis placement, y-axis placement, size, shape, color, and animation for interactive map typically associated with time.\n").padding(10)
                    } // Section 6
                    // ----------------------
                    .padding(10)
                    // ----------------------
                } // Section Main
                    .padding(.bottom, 20)
            } // ScrollView -- text
            .padding(20)
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.2 Visualization Analytics Generation", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // SECTION 0: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// TABLE 4-1 VIEW
// ------------------------------
struct Table41View1: View {
    @Environment(\.presentationMode) var presentationMode
    @GestureState var scale: CGFloat = 1.0

    var body: some View {
        VStack {
            // ----------------------
            Spacer()
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Table 4-1: Visualization Charts and Tables")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(uiImage: UIImage(named: "Table-4-1.jpg")!)
                        .resizable()
                        .scaledToFill()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                        .scaleEffect(self.scale)
                        .gesture(MagnificationGesture()
                            .updating(self.$scale, body: { (value, scale, trans) in
                                scale = value.magnitude
                            })
                    )
                } // Geometry Reader
            }
            // ----------------------
            Button("Finished: Table 4-1 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
            Spacer()
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
