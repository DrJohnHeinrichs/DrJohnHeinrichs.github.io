//
//  C04S03T03.swift
//  Book_Sources
//
//  Chapter 04 Section 03: Topic 04: Trend Chart Application
//
//  Created by SBAMBP on 04/13/2020.
//  Updated by SBAMBP on 04/14/2020.
//
import SwiftUI
// ---------------------
// ---------------------
//@available(iOS 13.0.0, *)
//public extension Image {
//    // usage: Image(name: "imageNameHere.jpg"
//    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
//    @available(iOS 13.0.0, *)
//    init(name: String){
//        self.init(uiImage:  #imageLiteral(resourceName: name))
//    } // Init
//} // extension - Image
// ----------------------
// ----------------------
@available(iOS 13.0.0, *)
public struct C04S03T03: View {
    var topicTitle: String = "Topic Title"
    @State private var showingFigure410Sheet1 = false
    @State private var showingFigure411Sheet1 = false

    public init(topicTitle: String) {
        self.topicTitle = topicTitle
    }
    
    public var body: some View {
        // ------------------------------
        // TOPIC 3: Start --- Tabulation Chart Application
        // ------------------------------
        NavigationView {
            ScrollView {
                    // ----------------------
                    Text("4.3.3 Tabulation Chart Application").fontWeight(.black).frame(maxWidth: .infinity, alignment: .center).padding(10)
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("PivotTable")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                        // ----------------------
                        Text("A PivotTable provides the marketing manager with the ability to perform analysis of the data by altering the various dimensions and levels being viewed.  A PivotTable is displayed in Figure 4-10.  This figure displays the count of sales for each month of the previous year for the four different marketing channels.  Row shows the month of the year and column shows the different channels used by the firm.  From the figure, the marketing manager can ascertain that the units sold each month over the past year are fairly consistent in each month with the sales count ranging from 1,676 units to 1,725 units.  The second month shows the highest sales count of 1,725 units.  The marketing managers can also choose a different field (variable or dimension) to display different table entry values in the pivot table.").padding(10)
                        // ----------------------
                        Button("Click to highlight ... Figure 4-10: Pivot Table of Count of Sales") {
                            self.showingFigure410Sheet1.toggle()
                        }
                        .sheet(isPresented: $showingFigure410Sheet1) {
                            Figure410View1()
                        }
                    } // Section 1
                    // ----------------------
                    Section (header: HStack {
                        Image(systemName: "pencil")
                        Text("PivotChart")
                            .font(.system(size: 20, weight: .heavy, design: .default))
                        } )
                        {
                    // ----------------------
                    Text("The marketing manager has a variety of predefined options.  The sales data was shown as “total counts”.  A number of other options are available as well. As the conditional formatting allows marketing managers to choose various colors for the various cell values, the pivot table can be more easily read.\n\nFigure 4-11 graphically displays the information about the sales count of each month for the different distributional channels.  Marketing managers have various options for displaying the data.  They can present the information in a variety of chart formats or can create a custom chart format.  Each data series, which represents various members of the dimension, is displayed with a different color or pattern.  The characteristics of the data being analyzed should help the marketing manager determine which type of chart to use.").padding(10)
                    // ----------------------
                    Button("Click to highlight ... Figure 4-11: Pivot Chart of Count of Sales") {
                        self.showingFigure411Sheet1.toggle()
                    }
                    .sheet(isPresented: $showingFigure411Sheet1) {
                        Figure411View1()
                    }
                } // Section 1
                // ----------------------
            } // ScrollView -- text
            .font(.system(size: 18))
            .font(.headline)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarTitle("4.3 Visualization Analytics Interpretation and Application", displayMode: .inline)
        } // NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        // ------------------------------
        // TOPIC 3: End
        // ------------------------------
    } // body
} // struct
// ------------------------------
// FIGURE 4-10 VIEW
// ------------------------------
struct Figure410View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-10: Pivot Table of Count of Sales")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-10.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-10 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------
// FIGURE 4-11 VIEW
// ------------------------------
struct Figure411View1: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            // ----------------------
            Section (header: HStack {
                Image(systemName: "pencil")
                Text("Figure 4-11: Pivot Chart of Count of Sales")
                    .font(.system(size: 18, weight: .heavy, design: .default))
                    } )
                {
                GeometryReader { geo in
                    Image(name: "Figure-4-11.jpg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geo.size.width)
                }
            }
            // ----------------------
            Button("Finished: Figure 4-11 View") {
                self.presentationMode.wrappedValue.dismiss()
            } // Button
        } // VStack
    } // body
} // struct
// ------------------------------------------
// ------------------------------------------
