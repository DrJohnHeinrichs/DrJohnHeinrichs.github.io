//#-hidden-code
//
//  ContentView.swift
//  SwiftUI -- Pie Charts

import Foundation
import SwiftUI
import UIKit
import PlaygroundSupport
import Combine

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

// ---------------------
@available(iOSApplicationExtension 13.0, *)
struct ContentView1: View {
    
    var body: some View {
        Text("Hi    ")
    } // body

    init() {
        UISegmentedControl.appearance().selectedSegmentTintColor = .darkGray
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
    } // init
} // struct - ContentView

// ---------------------
// ---------------------
//  extension Color {
//      static func random() -> Color {
//          return Color(red: .randomColorRGB(), green: .randomColorRGB(), blue: .randomColorRGB())
//      }
//  }
// ---------------------
// ---------------------

extension Double {
    static func randomColorRGB() -> Double {
        return Double(arc4random()) / Double(UInt32.max)
    }
}
// ---------------------
// ---------------------

class DataItem {
    var name: String! = ""
    var value: Double = 0.0
    var color = Color(red: .randomColorRGB(), green: .randomColorRGB(), blue: .randomColorRGB())
    
    var highlighted: Bool = false
    
    init(name: String, value: Double) {
        self.name = name
        self.value = value
        //if let color = color {
        //self.color = color
        //} else {
        //self.color = .blue
        //} // if-let
    } // init
} // class
// -------------------
  class SlideData: Identifiable, ObservableObject {
      let id: UUID = UUID()
      var data: DataItem!
      var startAngle: Angle! = .degrees(0)
      var endAngle: Angle! = .degrees(0)
    
    var annotation: String! = ""
    var annotationDeltaX: CGFloat! = 0.0
    var annotationDeltaY: CGFloat! = 0.0
    
    var deltaX: CGFloat! = 0.0
    var deltaY: CGFloat! = 0.0
    
    init() { }
    
    init(startAngle: Angle, endAngle: Angle) {
        self.data = DataItem(name: "", value: 0)
        self.startAngle = startAngle
        self.endAngle = endAngle
    }
    
    //var percentage = 1.1
    
  } // class SlideData
// ---------------------
// ---------------------
class PieChartData: ObservableObject {
    @Published private(set) var data: [SlideData] = []
    
    init(data: [Double]) {
        var currentAngle: Double = -90
        var slides: [SlideData] = []
        let total = data.reduce(0.0, +)
        
        for index in 0..<data.count {
            let slide = SlideData()
            let dataItem = DataItem(name: "Data name \(index + 1)", value: data[index])
            dataItem.highlighted = index == 3
            slide.data = dataItem
            
            let percentage = data[index] / total * 100
            slide.annotation = String(format: "%.1f%", percentage)
            
            slide.startAngle = .degrees(currentAngle)
            let angle = data[index] * 360 / total
            let alpha = currentAngle + angle / 2
            currentAngle += angle
            slide.endAngle = .degrees(currentAngle)
            
            let deltaX = CGFloat(cos(abs(alpha).truncatingRemainder(dividingBy: 90.0) * .pi / 180.0))
            let deltaY = CGFloat(sin(abs(alpha).truncatingRemainder(dividingBy: 90.0) * .pi / 180.0))
            var padding: CGFloat = 0.0
            var paddingX: CGFloat = 0.0
            var paddingY: CGFloat = 0.0
            if slide.data.highlighted {
                padding = 0.15
                paddingX = deltaX * 20.0
                paddingY = deltaY * 20.0
            }
            
            let annotationDeltaX = deltaX * (0.7 + padding)
            let annotationDeltaY = deltaY * (0.7 + padding)
            if -90 <= alpha && alpha < 0 {
                slide.deltaX = paddingX
                slide.deltaY = -paddingY
                slide.annotationDeltaX = annotationDeltaX
                slide.annotationDeltaY = -annotationDeltaY
            } else if 0 <= alpha && alpha < 90 {
                slide.deltaX = paddingX
                slide.deltaY = paddingY
                slide.annotationDeltaX = annotationDeltaX
                slide.annotationDeltaY = annotationDeltaY
            } else if 90 <= alpha && alpha < 180 {
                slide.deltaX = -paddingY
                slide.deltaY = paddingX
                slide.annotationDeltaX = -annotationDeltaY
                slide.annotationDeltaY = annotationDeltaX
            } else {
                slide.deltaX = -paddingX
                slide.deltaY = -paddingY
                slide.annotationDeltaX = -annotationDeltaX
                slide.annotationDeltaY = -annotationDeltaY
            }
            
            slides.append(slide)
        }
        self.data = slides
    }
    
    init(data: [SlideData]) {
        self.data = data
    }
}
// ---------------------
// ---------------------
        public struct PieChartSlide: View {
            @State private var show: Bool = false
            
            var geometry: GeometryProxy
            var slideData: SlideData
            var index: Int
            
            var path: Path {
                let chartSize = geometry.size.width
                let radius = chartSize / 2
                let centerX = radius + slideData.deltaX
                let centerY = radius + slideData.deltaY
                
                var path = Path()
                path.move(to: CGPoint(x: centerX, y: centerY))
                path.addArc(center: CGPoint(x: centerX, y: centerY),
                            radius: radius,
                            startAngle: slideData.startAngle,
                            endAngle: slideData.endAngle,
                            clockwise: false)
                return path
            }
            
            public var body: some View {
                path.fill()
                //path.fill(style: slideData.data!.color)
                //.overlay(path.stroke(Color.white, lineWidth: 1))
                //.scaleEffect(self.show ? 1 : 0)
                //.animation(
                //Animation.spring(response: 0.5, dampingFraction: 0.5, blendDuration: 0.3)
                //.delay(Double(self.index) * 0.03)
                //).onAppear() {
                //self.show = true
                //}
                }
        }
// ---------------------
// ---------------------
        struct PieChart: View {
            var pieChartData: PieChartData
            
            var body: some View {
                GeometryReader { geometry in
                    self.makePieChart(geometry, pieChartData: self.pieChartData.data)
                }
            }
            
            func makePieChart(_ geometry: GeometryProxy, pieChartData: [SlideData]) -> some View {
                let chartSize = min(geometry.size.width, geometry.size.height)
                let radius = chartSize / 2
                let centerX = geometry.size.width / 2
                let centerY = geometry.size.height / 2
                
                return ZStack {
                    ForEach(0..<pieChartData.count, id: \.self) { index in
                        PieChartSlide(geometry: geometry, slideData: pieChartData[index], index: index)
                    }
                    ForEach(pieChartData) { slideData in
                        Text("\(slideData.annotation)%")
                            .foregroundColor(Color.white)
                            .position(CGPoint(x: centerX + slideData.annotationDeltaX*radius,
                                              y: centerY + slideData.annotationDeltaY*radius))
                    }
                }
            }
        }
// ---------------------
// ---------------------
        struct ContentView: View {
            @ObservedObject var viewModel = ContentViewModel()
            
            var body: some View {
                GeometryReader { geometry in
                    VStack {
                        PieChart(pieChartData: self.viewModel.pieChartData)
                            .frame(width: geometry.size.width * 0.8,
                                   height: geometry.size.width * 0.8)
                            .padding(.top, 20)
                        Spacer()
                    }.onAppear {
                        self.viewModel.randomData()
                    }
                    .navigationBarTitle("Pie Chart", displayMode: .inline)
                    .navigationBarItems(trailing:
                        Button(action: {
                            self.viewModel.randomData()
                        }) {
                            Image(systemName: "arrow.clockwise")
                        }
                    )
                }.padding()
            }
        }
// ---------------------
// ---------------------
        class ContentViewModel: ObservableObject {
            @Published var pieChartData = PieChartData(data: [Double]())
            
            func randomData() {
                let number = Int.random(in: 3...7)
                var values: [Double] = []
                for _ in 0..<number {
                    values.append(Double.random(in: 10...50))
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.pieChartData = PieChartData(data: values)
                }
            }
        }
// ---------------------
// ---------------------
        
if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

// PlaygroundPage.current.assessmentStatus = .pass(message: "Great Job")
// PlaygroundPage.current.assessmentStatus = .fail(hints: ["Great Job"], solution: "This is the solution")
//
//#-end-hidden-code

/*:
 # Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart - Interactive](BarChart2)
 3. [Line Chart](LineChart)
 4. [Line Chart - Stock Price](LineChartStockAPI)
 5. **[Pie Chart](PieChart)**
 6. [Scatter Chart](ScatterChart)
 */

/*:
 # Interactive Playground
 * In this challenge, you'll practice your [Business Analytics](glossary://Business%20Analytics) - finding skills by finding and rearranging .
 */

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Pie Chart - GitHub]: https://github.com/kentwinder/SwiftUI-PieChart
 [Pie Chart - Description]: https://blog.nextzy.me/create-a-simple-pie-chart-with-swiftui-e39d75b4a740
 [Integrating SwiftUI]: https://developer.apple.com/videos/play/wwdc2019/231/
 [Reddit]: https://www.reddit.com/r/SwiftUI/
 [Statistics]: https://github.com/evgenyneu/SigmaSwiftStatistics
 
 ### **Additional Information**
 For more information regarding bar charts, view the following ...
 * [The Swift Programming Language]
 * [Pie Chart - GitHub]
 * [Pie Chart - Description]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//#-code-completion(everything, hide)
