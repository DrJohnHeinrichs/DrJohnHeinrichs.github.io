//#-hidden-code

import SwiftUI
import Combine
import UIKit
import PlaygroundSupport

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
}

// addArc, addCurve, addQuadCurve, addRect, and addEllipse
// -----------------------------
struct ContentView: View {
    
    @ObservedObject var stocks = Stocks()
    
    var body: some View {
        
        LineView(data: stocks.prices, title: "HubSpot", price: "\(stocks.currentPrice)")
            .padding()
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0)))
    } // body
} // struct - ContentView
// -----------------------------
//struct ContentView: View {
//    var body: some View {
//        // TRIANGLE
//        Path { path in
//        path.move(to: CGPoint(x: 100, y: 100))
//        path.addLine(to: CGPoint(x: 100, y: 300))
//        path.addLine(to: CGPoint(x: 300, y: 300))
//
//            // CIRCLE
//            path.move(to: CGPoint(x: 150, y: 500))
//            path.addArc(center: CGPoint(x: 150, y: 500), radius: 90, startAngle: .degrees(0), endAngle: .degrees(60), clockwise: true)
//        } // Path
//        .fill(Color.green)
//    } // body
//} // struct
// -----------------------------
struct StockPrice : Codable{
    let open: String
    let close: String
    let high: String
    let low: String
    let volume: String 
    
    private enum CodingKeys: String, CodingKey {
        case open = "1. open"
        case high = "2. high"
        case low = "3. low"
        case close = "4. close"
        case volume = "5. volume"
    }
} // struct - StockPrice
// -----------------------------
struct StocksDaily : Codable {
    let timeSeriesDaily: [String: StockPrice]?
    
    private enum CodingKeys: String, CodingKey {
        case timeSeriesDaily = "Time Series (Daily)"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        
        timeSeriesDaily = try (values.decodeIfPresent([String : StockPrice].self, forKey: .timeSeriesDaily))
    }
}
// -----------------------------
class Stocks : ObservableObject{
    
    @Published var prices = [Double]()
    @Published var currentPrice = "...."
    var urlBase = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=NYSE:HUBS&apikey=SG04PQEGNAUIMCO6&datatype=json&outputsize=compact"
//    var urlBase = "https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY&symbol=NYSE:HUBS&apikey=SG04PQEGNAUIMCO6&datatype=json"

    var cancellable : Set<AnyCancellable> = Set()
    
    init() {
        fetchStockPrice()
    } // init
    
    func fetchStockPrice(){
        
        URLSession.shared.dataTaskPublisher(for: URL(string: "\(urlBase)")!)
            .map{output in
                return output.data
        }
        .decode(type: StocksDaily.self, decoder: JSONDecoder())
        .sink(receiveCompletion: {_ in
            print("completed")
        }, receiveValue: { value in
            var stockPrices = [Double]()
            
            let orderedDates =  value.timeSeriesDaily?.sorted{
                guard let d1 = $0.key.stringDate, let d2 = $1.key.stringDate else { return false }
                return d1 < d2
            }
            
            guard let stockData = orderedDates else {return}
            
            for (_, stock) in stockData{
                if let stock = Double(stock.close){
                    if stock > 0.0{
                        stockPrices.append(stock)
                    }
                }
            }
            
            DispatchQueue.main.async{
                self.prices = stockPrices
                self.currentPrice = stockData.last?.value.close ?? "..."
            }
        })
            .store(in: &cancellable)
    } // func - fetchStockPrice
} // Class - Stocks
// -----------------------------
extension String {
    static let shortDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    var stringDate: Date? {
        return String.shortDate.date(from: self)
    }
} // extension -- String
// -----------------------------
struct LineView: View {
    var data: [(Double)]
    var title: String?
    var price: String?

    public init(data: [Double],
                title: String? = nil,
                price: String? = nil) {
        
        self.data = data
        self.title = title
        self.price = price
    } // init
    
    public var body: some View {
        GeometryReader{ geometry in
            VStack(alignment: .leading, spacing: 8) {
//            VStack {
                Group{
                    if (self.title != nil){
                        Text(self.title!)
                            .font(.title)
                    }
                    if (self.price != nil){
                        Text(self.price!)
                            .font(.body)
                            .offset(x: 5, y: 0)
                    }
                }.offset(x: 0, y: 0)
                ZStack{
                    GeometryReader{ reader in
                        Line(data: self.data,
                             frame: .constant(CGRect(x: 0, y: 0, width: reader.frame(in: .local).width, height: reader.frame(in: .local).height))
  //                           minDataValue: .constant(nil),
  //                           maxDataValue: .constant(nil)
                        )
                            .offset(x: 0, y: 0)
                    }
                    .frame(width: geometry.frame(in: .local).size.width, height: 200)
                    .offset(x: 0, y: -100)

                } // ZStack
                .frame(width: geometry.frame(in: .local).size.width, height: 200)
        
            } // VStack
        } // GeometryReader
    } // body
} // struct - LineView
// -----------------------------
struct Line: View {
    var data: [(Double)]
    @Binding var frame: CGRect

    let padding:CGFloat = 30
    
    var stepWidth: CGFloat {
        if data.count < 2 {
            return 0
        }
        return frame.size.width / CGFloat(data.count-1)
    } // stepWidth
    
    var stepHeight: CGFloat {
        var min: Double?
        var max: Double?
        let points = self.data
        if let minPoint = points.min(), let maxPoint = points.max(), minPoint != maxPoint {
            min = minPoint
            max = maxPoint
        }else {
            return 0
        }
        if let min = min, let max = max, min != max {
            if (min <= 0){
                return (frame.size.height-padding) / CGFloat(max - min)
            } else {
                return (frame.size.height-padding) / CGFloat(max + min)
            }
        }
        return 0
    } // setpHeight
    
    var path: Path {
        let points = self.data
        return Path.lineChart(points: points, step: CGPoint(x: stepWidth, y: stepHeight))
    } // path
    
    public var body: some View {
        ZStack {
            self.path
                .stroke(Color.blue ,style: StrokeStyle(lineWidth: 5, lineJoin: .round))
                .rotationEffect(.degrees(180), anchor: .center)
                .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                .drawingGroup()
        } // ZStack
    } // body
} // struct - Line
// -----------------------------
extension Path {
    
    static func lineChart(points:[Double], step:CGPoint) -> Path {
        var path = Path()
        if (points.count < 2){
            return path
        }
        guard let offset = points.min() else { return path }
        let p1 = CGPoint(x: 0, y: CGFloat(points[0] - offset) * step.y)
        path.move(to: p1)
        for pointIndex in 1..<points.count {
            let p2 = CGPoint(x: step.x * CGFloat(pointIndex), y: step.y * CGFloat(points[pointIndex] - offset))
            path.addLine(to: p2)
        }
        return path
    }
} // extension - Path
// -----------------------------

if #available(iOSApplicationExtension 13.0.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
    PlaygroundPage.current.needsIndefiniteExecution = true
} else {
    // Fallback on earlier versions
}

 
// -----------------------------

//#-end-hidden-code

/*:
 # Visualization Tools for Marketing Enviroment Analytics
### Table of Contents - _Chapter 4_
 1. [Section 1: Market Environment Analytics Task](Ch04-Pg01)
 2. [Section 2: Visualization Analytics Generation](Ch04-Pg02)
 3. [Section 3: Visualization Analytics Interpretation and Application](Ch04-Pg03)
 4. [Section 4: AI Powered Visualization Analytics](Ch04-Pg04)
 */

/*:
 * Callout(Examples): Enhance your knowledge of visualization tools
by completing these interactive exercises.
 1. [Bar Chart](BarChart)
 2. [Bar Chart2](BarChart2)
 3. **[Line Chart](LineChart)**
 4. **[Line Chart - Stock Price](LineChartStockAPI)**
 5. [Scatter Chart](ScatterChart)
 */

/*:
 # Interactive Playground
 * In this challenge, you'll practice your [Chart Dimensions](glossary://Chart%20Dimensions) - finding skills by creating, developing, and rearranging lines on a chart.
 */

// **************************************

// Welcome to Alpha Vantage!
// Your dedicated access key is: SG04PQEGNAUIMCO6.
// Please record this API key for future access to Alpha Vantage.

// **************************************

/*: Setup and use a link reference.
 [The Swift Programming Language]: http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/
 [Discussion on Editable Regions]: https://developer.apple.com/documentation/swift_playgrounds/specifying_editable_regions_in_a_playground_page
 [Line Chart for Stocks Using Paths]: https://medium.com/better-programming/create-a-line-chart-in-swiftui-using-paths-183d0ddd4578
 [Line Chart - Gesturer Repo]: https://github.com/AppPear/ChartView
 [Alpha Advantage]: https://www.alphavantage.co/#about
 [Blog from iowncode]: https://www.iowncode.com/
 
 ### **Additional Information**
 For more information regarding line charts, view the following ...
 * [Discussion on Editable Regions]
 * [Line Chart for Stocks Using Paths]
 * [Line Chart - Gesturer Repo]
 * [Alpha Advantage]
 * [Blog from iowncode]
 */

//: [Previous Page](@previous)          --          [Next Page](@next)
//  #  -  code  -  completion(everything, hide)

