//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//
//  Chapter 4: Visualization Tools for Marketing Environment Analytics
//  Section x: Line Chart
//
import SwiftUI
import UIKit
import PlaygroundSupport
import Chapter4
// import PlaygroundAPI
// import PlaygroundInternal

public enum AssessmentResults {
    case pass(message: String)
    case fail(hints: [String], solution: String?)
} // enum - AssessmentResults
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
public extension Image {
    // usage: Image(name: "imageNameHere.jpg"
    // code is: self.init(uiImage: #imageLiteral(resourceName: name))
    @available(iOS 13.0.0, *)
    public init(name: String){
        self.init(uiImage:  #imageLiteral(resourceName: name))
    } // Init
} // extension - Image
// ---------------------
// ---------------------
@available(iOS 13.0.0, *)
// -----------------------
struct ContentView: View {
    let letters = Array("Visualization Tools for Marketing Environment Analytics")
    @State private var enabled = true
    @State private var dragAmount = CGSize.zero

    var body: some View {
            VStack{
                HStack(spacing: 0){
                    ForEach(0 ..< letters.count) { num in
                        Text(String(self.letters[num]))
                        .padding(1)
                        .font(.title)
                        .background(self.enabled ? Color.blue : Color.red)
                        .offset(self.dragAmount)
                        .animation(Animation.default.delay(Double(num) / 20))
                    } // ForEach
                } // HStack
                .gesture(
                    DragGesture()
                    .onChanged { self.dragAmount = $0.translation }
                    .onEnded { _ in
                        self.dragAmount = .zero
                        self.enabled.toggle()
                    }
                )
                Spacer()
                VStack{
                    Text("Hi Scatter Chart ")
                } // VStack
                .frame(width: 400, height: 400)
                C04S01T01Instructions()
                .padding(20)
            } // VStack
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor(red: 0.5686, green: 0.5686, blue: 0.5686, alpha: 1.0000)))
    } // body
} // struct
// ---------------------
// ---------------------
if #available(iOSApplicationExtension 13.0, *) {
    let view = ContentView()
    let vcC04S16 = UIHostingController(rootView: view)
    PlaygroundPage.current.liveView = vcC04S16
    PlaygroundPage.current.assessmentStatus = .pass(message: "Welcome!\n\nYou are taking the 'Scatter Chart Task' section.")

} else {
    // Fallback on earlier versions
} // if - else
// ---------------------
// ---------------------
